import type { NextConfig } from "next";

// Site 100 % statique : aucune base de données, aucun serveur.
// NEXT_PUBLIC_BASE_PATH est utilisé pour GitHub Pages (ex. "/mon-depot").
const basePath = process.env.NEXT_PUBLIC_BASE_PATH ?? "";

const nextConfig: NextConfig = {
  output: "export",
  trailingSlash: true,
  images: { unoptimized: true },
  ...(basePath ? { basePath } : {}),
};

export default nextConfig;
