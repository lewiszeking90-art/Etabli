// Détection de la langue PAR PASSAGE : un mot isolé dans une autre langue ne change pas la
// langue de la phrase, mais un groupe de mots ou un autre alphabet crée un nouveau passage.

export interface LangRun {
  lang: string;
  text: string;
}

const WORDS: Record<string, string> = {
  fr: "le la les un une des du et est que qui dans pour pas sur avec ce cette ces mais où je tu il elle nous vous ils elles suis sont être avoir avons avez dit dire puis encore toujours jamais rien tous toute car sommes êtes ainsi chaque autre même très plus bien comme tout aussi donc alors cela ça mon ma mes ton ta tes son sa ses notre votre leur leurs au aux par été fait faire peut oui non merci bonjour salut comment aujourd'hui ne se sans chez entre depuis quand pourquoi c'est j'ai l'on qu'il n'est",
  en: "the and is are was were be been have has had do does did not you your he she it we they them this that these those with for from but or if what when where why how who which will would can could should my our their his her its of on at by to very more also just all any some there here yes thank hello please then today speak english about because every other same being i'm it's don't i've what's",
  es: "el los las un una unos unas y es son está están ser estar tengo tiene tienen para por con sin sobre pero como más muy también ya yo tú él ella nosotros ustedes ellos ellas mi mis tu tus su sus nuestro este esta estos estas ese esa eso qué quién cuándo dónde cómo porque gracias hola buenos días sí hay fue ha han hacer",
  de: "der die das ein eine einen einem einer und ist sind war waren sein haben hat hatte nicht ich du er sie es wir ihr mit für von aber oder wenn was wann wo warum wie wer wird werden kann können soll mein dein unser auch sehr noch schon nur dass diese dieser dieses ja nein danke hallo bitte guten tag zu auf bei nach aus im am zum zur",
  it: "il lo gli le un uno una è sono era erano essere avere ho ha hanno non io tu lui lei noi voi loro con per da di ma se che cosa quando dove perché come chi sarà può posso mio tuo suo nostro anche molto più già solo questo questa questi queste sì grazie ciao prego buongiorno",
  pt: "o os as um uma uns umas é são era eram ser estar ter tenho tem têm não eu ele ela nós vocês eles elas com para por de mas ou se que quando onde porque como quem será pode posso meu teu seu nosso também muito mais já só este esta estes estas sim obrigado obrigada olá bom dia",
  nl: "de het een en is zijn was waren hebben heeft had niet ik jij je hij zij ze wij we jullie met voor van maar of als wat wanneer waar waarom hoe wie wordt kan mijn jouw ons ook zeer erg nog al alleen dit dat deze die ja nee dank hallo alstublieft goedendag",
  tr: "ve bir bu şu o ben sen biz siz onlar değil için ile ama veya eğer ne zaman nerede neden nasıl kim olarak çok daha de da mi mı mu mü evet hayır teşekkürler merhaba lütfen günaydın ki gibi kadar",
  sw: "na ya wa kwa ni katika la za hii huu hiki kuwa sana pia lakini au kama hapa pale yeye mimi wewe sisi nyinyi wao asante karibu jambo habari",
};

// mot -> langues qui le partagent (un mot ambigu compte pour chacune, à poids réduit)
const WORDMAP: Map<string, string[]> = (() => {
  const map = new Map<string, string[]>();
  for (const [lang, list] of Object.entries(WORDS)) {
    for (const w of list.split(/\s+/)) {
      const cur = map.get(w);
      if (cur) cur.push(lang);
      else map.set(w, [lang]);
    }
  }
  return map;
})();

const SCRIPTS: [RegExp, string][] = [
  [/\p{Script=Han}/u, "zh"],
  [/[\p{Script=Hiragana}\p{Script=Katakana}ー]/u, "ja"],
  [/\p{Script=Hangul}/u, "ko"],
  [/\p{Script=Cyrillic}/u, "ru"],
  [/\p{Script=Arabic}/u, "ar"],
  [/\p{Script=Hebrew}/u, "he"],
  [/\p{Script=Thai}/u, "th"],
  [/\p{Script=Greek}/u, "el"],
  [/\p{Script=Devanagari}/u, "hi"],
];

/** Codes BCP-47 pour la synthèse vocale. */
export const SPEECH_CODES: Record<string, string> = {
  fr: "fr-FR", en: "en-US", es: "es-ES", de: "de-DE", it: "it-IT", pt: "pt-BR", nl: "nl-NL",
  tr: "tr-TR", ru: "ru-RU", ar: "ar-SA", zh: "zh-CN", ja: "ja-JP", ko: "ko-KR", he: "he-IL",
  th: "th-TH", el: "el-GR", hi: "hi-IN", sw: "sw-KE",
};

interface Token {
  s: string;
  tags: string[] | null;
  w: number;
}

function tokenize(text: string): Token[] {
  const out: Token[] = [];
  const re = /[\p{Script=Han}]|[\p{Script=Hiragana}\p{Script=Katakana}ー]+|[\p{Script=Hangul}]+|[\p{L}\p{M}'’]+|[^\p{L}\p{M}]+/gu;
  const hasKana = /[\p{Script=Hiragana}\p{Script=Katakana}]/u.test(text);
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    const s = m[0];
    let tags: string[] | null = null;
    let w = 0;
    for (const [rx, code] of SCRIPTS) {
      if (rx.test(s)) {
        tags = [code === "zh" && hasKana ? "ja" : code];
        w = 2;
        break;
      }
    }
    if (!tags && /^[\p{L}\p{M}'’]+$/u.test(s)) {
      const k = s.toLowerCase().replace(/’/g, "'");
      tags = WORDMAP.get(k) ?? null;
      w = tags ? 1 : 0;
      if (!tags && /[ğşı]/i.test(k)) {
        tags = ["tr"];
        w = 1;
      }
    }
    out.push({ s, tags, w });
  }
  return out;
}

const gain = (k: Token, lang: string) => (k.tags && k.tags.includes(lang) ? k.w / k.tags.length : 0);

/** Découpe un texte en passages [{lang, text}]. `fallback` sert quand aucun indice n'existe. */
export function detectRuns(text: string, fallback = "und"): LangRun[] {
  const toks = tokenize(text);
  if (!toks.length) return [];
  const score: Record<string, number> = {};
  for (const k of toks) {
    if (k.tags) for (const g of k.tags) score[g] = (score[g] ?? 0) + k.w / k.tags.length;
  }
  const langs = Object.keys(score);
  if (!langs.length) return [{ lang: fallback, text }];

  const PEN = 1.4;
  const n = toks.length;
  const L = langs.length;
  const best: Float64Array[] = Array.from({ length: n }, () => new Float64Array(L));
  const from: Int8Array[] = Array.from({ length: n }, () => new Int8Array(L));
  for (let j = 0; j < L; j++) best[0][j] = gain(toks[0], langs[j]);
  for (let i = 1; i < n; i++) {
    for (let j = 0; j < L; j++) {
      let bs = -1e9;
      let bf = j;
      for (let k = 0; k < L; k++) {
        const v = best[i - 1][k] - (k === j ? 0 : PEN);
        if (v > bs) { bs = v; bf = k; }
      }
      best[i][j] = bs + gain(toks[i], langs[j]);
      from[i][j] = bf;
    }
  }
  let j = 0;
  for (let k = 1; k < L; k++) if (best[n - 1][k] > best[n - 1][j]) j = k;
  const path: number[] = new Array(n);
  for (let i = n - 1; i >= 0; i--) { path[i] = j; j = from[i][j]; }

  const runs: LangRun[] = [];
  toks.forEach((k, i) => {
    const lang = langs[path[i]];
    const last = runs[runs.length - 1];
    if (last && last.lang === lang) last.text += k.s;
    else runs.push({ lang, text: k.s });
  });
  return runs.filter((r) => r.text.trim());
}

/** Langue dominante d'un texte (« und » si aucun indice). */
export function dominantLang(text: string): string {
  const counts: Record<string, number> = {};
  for (const r of detectRuns(text)) counts[r.lang] = (counts[r.lang] ?? 0) + r.text.length;
  const top = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
  return top ? top[0] : "und";
}
