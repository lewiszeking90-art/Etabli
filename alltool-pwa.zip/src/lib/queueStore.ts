"use client";

import { useSyncExternalStore } from "react";

export type QueueStatus = "pending" | "running" | "done" | "error" | "canceled";

export interface QueueTask {
  id: string;
  toolId: string;
  label: string;
  status: QueueStatus;
  progress: number; // 0-100
  message?: string;
  createdAt: number;
  onCancel?: () => void;
}

type Listener = () => void;

class QueueStore {
  private tasks: QueueTask[] = [];
  private listeners = new Set<Listener>();

  subscribe = (listener: Listener) => {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  };

  getSnapshot = () => this.tasks;

  private emit() {
    this.tasks = [...this.tasks];
    this.listeners.forEach((l) => l());
  }

  add(task: Omit<QueueTask, "createdAt" | "status" | "progress"> & { progress?: number }) {
    this.tasks.push({
      ...task,
      status: "pending",
      progress: task.progress ?? 0,
      createdAt: Date.now(),
    });
    this.emit();
    return task.id;
  }

  update(id: string, patch: Partial<QueueTask>) {
    const idx = this.tasks.findIndex((t) => t.id === id);
    if (idx === -1) return;
    this.tasks[idx] = { ...this.tasks[idx], ...patch };
    this.emit();
  }

  cancel(id: string) {
    const task = this.tasks.find((t) => t.id === id);
    if (task?.onCancel) task.onCancel();
    this.update(id, { status: "canceled" });
  }

  remove(id: string) {
    this.tasks = this.tasks.filter((t) => t.id !== id);
    this.emit();
  }

  clearFinished() {
    this.tasks = this.tasks.filter((t) => t.status === "pending" || t.status === "running");
    this.emit();
  }
}

export const queueStore = new QueueStore();

export function useQueue() {
  return useSyncExternalStore(queueStore.subscribe, queueStore.getSnapshot, () => []);
}
