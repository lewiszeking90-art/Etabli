"use client";

import { announceSaved, isNativeApp, saveBlobNative } from "@/lib/native";

export function loadImageFromFile(file: File): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("unsupported_image"));
    };
    img.src = url;
  });
}

export function rotateImageToCanvas(img: HTMLImageElement, rotationDeg: 0 | 90 | 180 | 270): HTMLCanvasElement {
  const canvas = document.createElement("canvas");
  const swap = rotationDeg === 90 || rotationDeg === 270;
  canvas.width = swap ? img.naturalHeight : img.naturalWidth;
  canvas.height = swap ? img.naturalWidth : img.naturalHeight;
  const ctx = canvas.getContext("2d")!;
  ctx.translate(canvas.width / 2, canvas.height / 2);
  ctx.rotate((rotationDeg * Math.PI) / 180);
  ctx.drawImage(img, -img.naturalWidth / 2, -img.naturalHeight / 2);
  return canvas;
}

export function canvasToBlob(canvas: HTMLCanvasElement, type: string, quality?: number): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (blob) resolve(blob);
        else reject(new Error("canvas_export_failed"));
      },
      type,
      quality,
    );
  });
}

export async function blobToBytes(blob: Blob): Promise<Uint8Array> {
  return new Uint8Array(await blob.arrayBuffer());
}

export async function downloadBlob(blob: Blob, filename: string): Promise<void> {
  if (isNativeApp()) {
    try {
      const where = await saveBlobNative(blob, filename);
      announceSaved({ name: filename, where });
    } catch (e) {
      announceSaved({ name: filename, error: e instanceof Error ? e.message : "erreur" });
    }
    return;
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  announceSaved({ name: filename });
}

export async function shareOrDownload(blob: Blob, filename: string, title?: string) {
  const file = new File([blob], filename, { type: blob.type });
  const nav = navigator as Navigator & { canShare?: (data: unknown) => boolean };
  if (nav.canShare && nav.canShare({ files: [file] }) && navigator.share) {
    try {
      await navigator.share({ files: [file], title: title ?? filename });
      return;
    } catch {
      // l'utilisateur a annulé ou le partage a échoué : on retombe sur le téléchargement
    }
  }
  downloadBlob(blob, filename);
}
