"use client";

// Favoris et historique : stockés sur l'appareil (localStorage). Aucun compte, aucun serveur.
import { useSyncExternalStore } from "react";

export interface HistoryItem {
  id: string;
  toolId: string;
  label: string;
  createdAt: string;
}

const FAV_KEY = "alltool.favorites";
const HIST_KEY = "alltool.history";
const EVENT = "alltool:storage";
const MAX_HISTORY = 100;

function read<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write(key: string, value: unknown) {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // stockage plein ou désactivé : on ignore
  }
  window.dispatchEvent(new Event(EVENT));
}

export function getFavorites(): string[] {
  return read<string[]>(FAV_KEY, []);
}

export function getHistory(): HistoryItem[] {
  return read<HistoryItem[]>(HIST_KEY, []);
}

export function recordToolUsage(toolId: string, label: string) {
  const item: HistoryItem = {
    id: `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`,
    toolId,
    label,
    createdAt: new Date().toISOString(),
  };
  write(HIST_KEY, [item, ...getHistory()].slice(0, MAX_HISTORY));
}

/** `isFavorite` = état actuel (avant le clic). */
export function toggleFavorite(toolId: string, isFavorite: boolean) {
  const current = getFavorites().filter((id) => id !== toolId);
  write(FAV_KEY, isFavorite ? current : [...current, toolId]);
}

export function clearHistory() {
  write(HIST_KEY, []);
}

export function clearFavorites() {
  write(FAV_KEY, []);
}

function subscribe(listener: () => void) {
  window.addEventListener(EVENT, listener);
  window.addEventListener("storage", listener);
  return () => {
    window.removeEventListener(EVENT, listener);
    window.removeEventListener("storage", listener);
  };
}

// useSyncExternalStore exige un instantané stable : on compare la chaîne brute.
function useStored<T>(key: string, empty: T): T {
  const raw = useSyncExternalStore(
    subscribe,
    () => window.localStorage.getItem(key) ?? "",
    () => "",
  );
  if (!raw) return empty;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return empty;
  }
}

const EMPTY_IDS: string[] = [];
const EMPTY_HISTORY: HistoryItem[] = [];

export function useFavoriteIds(): string[] {
  return useStored<string[]>(FAV_KEY, EMPTY_IDS);
}

export function useHistoryItems(): HistoryItem[] {
  return useStored<HistoryItem[]>(HIST_KEY, EMPTY_HISTORY);
}
