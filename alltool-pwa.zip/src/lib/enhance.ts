// Amélioration d'image 100 % locale (canvas) : netteté, réduction du bruit, couleurs, agrandissement.
export interface EnhanceOptions {
  sharpen: number; // 0–100
  denoise: number; // 0–100
  contrast: number; // -50–50
  brightness: number; // -50–50
  saturation: number; // -50–50
  scale: number; // 1–3
}

export const DEFAULT_ENHANCE: EnhanceOptions = { sharpen: 40, denoise: 20, contrast: 8, brightness: 0, saturation: 8, scale: 2 };

export function enhanceCanvas(src: CanvasImageSource & { width: number; height: number }, o: EnhanceOptions): HTMLCanvasElement {
  const w = Math.round(src.width * o.scale);
  const h = Math.round(src.height * o.scale);
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const g = canvas.getContext("2d", { willReadFrequently: true });
  if (!g) throw new Error("canvas_unavailable");
  g.imageSmoothingEnabled = true;
  g.imageSmoothingQuality = "high";
  g.filter = `brightness(${1 + o.brightness / 100}) contrast(${1 + o.contrast / 100}) saturate(${1 + o.saturation / 100})`;
  g.drawImage(src, 0, 0, w, h);
  g.filter = "none";
  const image = g.getImageData(0, 0, w, h);
  const d = image.data;

  if (o.denoise > 0) { // flou doux, atténué sur les contours
    const copy = new Uint8ClampedArray(d);
    const a = o.denoise / 100;
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const i = (y * w + x) * 4;
        for (let c = 0; c < 3; c++) {
          const avg = (copy[i + c - 4] + copy[i + c + 4] + copy[i + c - w * 4] + copy[i + c + w * 4] + copy[i + c] * 4) / 8;
          const keep = Math.abs(avg - copy[i + c]) > 28 ? 0.2 : 1;
          d[i + c] = copy[i + c] + (avg - copy[i + c]) * a * keep;
        }
      }
    }
  }
  if (o.sharpen > 0) { // masque flou (unsharp mask)
    const copy = new Uint8ClampedArray(d);
    const a = (o.sharpen / 100) * 1.6;
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const i = (y * w + x) * 4;
        for (let c = 0; c < 3; c++) {
          const blur = (copy[i + c - 4] + copy[i + c + 4] + copy[i + c - w * 4] + copy[i + c + w * 4] + copy[i + c]) / 5;
          d[i + c] = copy[i + c] + (copy[i + c] - blur) * a * 2;
        }
      }
    }
  }
  g.putImageData(image, 0, 0);
  return canvas;
}
