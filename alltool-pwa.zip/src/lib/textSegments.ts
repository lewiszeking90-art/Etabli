import { franc } from "franc-min";
import { FRANC_TO_BCP47 } from "./langMap";
import { detectRuns, SPEECH_CODES } from "./langDetect";

export interface TextSegment {
  text: string;
  lang: string; // BCP-47
}

/**
 * Découpe un texte en segments homogènes du point de vue de la langue, afin
 * que la synthèse vocale (ou tout autre traitement) n'enchaîne jamais deux
 * langues différentes avec la mauvaise voix. On analyse le texte phrase par
 * phrase (découpage sur la ponctuation forte), on détecte la langue de
 * chaque phrase, puis on fusionne les phrases consécutives de même langue.
 */
function segmentBySentence(text: string, fallbackLang: string): TextSegment[] {
  const sentences = text
    .split(/(?<=[.!?。！？\n])\s+/)
    .map((s) => s.trim())
    .filter(Boolean);

  if (sentences.length === 0) return [];

  const detected = sentences.map((sentence) => {
    if (sentence.length < 4) return null; // trop court pour être fiable
    const code = franc(sentence, { minLength: 3 });
    return code !== "und" ? FRANC_TO_BCP47[code] ?? null : null;
  });

  // Comble les langues indéterminées avec la dernière langue connue.
  let lastKnown = fallbackLang;
  const langs = detected.map((lang) => {
    if (lang) {
      lastKnown = lang;
      return lang;
    }
    return lastKnown;
  });

  const segments: TextSegment[] = [];
  for (let i = 0; i < sentences.length; i++) {
    const lang = langs[i];
    if (segments.length > 0 && segments[segments.length - 1].lang === lang) {
      segments[segments.length - 1].text += " " + sentences[i];
    } else {
      segments.push({ text: sentences[i], lang });
    }
  }
  return segments;
}

/**
 * Analyse le texte EN ENTIER avant lecture : détection par passage (mot par mot, avec lissage),
 * donc un groupe de mots en anglais au milieu d'une phrase française devient son propre passage,
 * alors qu'un mot isolé reste dans la langue de la phrase. Si le texte ne donne aucun indice
 * (très court, noms propres…), on retombe sur la détection phrase par phrase.
 */
export function segmentTextByLanguage(text: string, fallbackLang = "fr-FR"): TextSegment[] {
  const trimmed = text.trim();
  if (!trimmed) return [];
  const runs = detectRuns(trimmed, "und");
  if (runs.length === 1 && runs[0].lang === "und") return segmentBySentence(text, fallbackLang);

  const segments: TextSegment[] = [];
  for (const run of runs) {
    const body = run.text.trim();
    if (!body) continue;
    const lang = SPEECH_CODES[run.lang] ?? fallbackLang;
    const last = segments[segments.length - 1];
    if (last && last.lang === lang) last.text += " " + body;
    else segments.push({ text: body, lang });
  }
  return segments;
}
