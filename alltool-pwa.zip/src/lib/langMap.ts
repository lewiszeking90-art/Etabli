// Correspondance entre les codes ISO 639-3 renvoyés par la détection de
// langue (franc) et les codes BCP-47 utilisés par les API navigateur
// (SpeechSynthesis) ainsi que les codes de langue Tesseract.js (OCR).
export const FRANC_TO_BCP47: Record<string, string> = {
  fra: "fr-FR",
  eng: "en-US",
  spa: "es-ES",
  deu: "de-DE",
  por: "pt-PT",
  ita: "it-IT",
  arb: "ar-SA",
  cmn: "zh-CN",
  swh: "sw-KE",
  nld: "nl-NL",
  rus: "ru-RU",
};

export const FRANC_TO_TESSERACT: Record<string, string> = {
  fra: "fra",
  eng: "eng",
  spa: "spa",
  deu: "deu",
  por: "por",
  ita: "ita",
  arb: "ara",
  cmn: "chi_sim",
  swh: "swa",
  nld: "nld",
  rus: "rus",
};

export const SUPPORTED_SPEECH_LANGS = [
  { code: "fr-FR", label: "Français" },
  { code: "en-US", label: "English" },
  { code: "es-ES", label: "Español" },
  { code: "de-DE", label: "Deutsch" },
  { code: "pt-PT", label: "Português" },
  { code: "it-IT", label: "Italiano" },
  { code: "ar-SA", label: "العربية" },
  { code: "zh-CN", label: "中文" },
  { code: "sw-KE", label: "Kiswahili" },
  { code: "nl-NL", label: "Nederlands" },
  { code: "ru-RU", label: "Русский" },
];

export const OCR_LANGUAGES = [
  { code: "fra", label: "Français" },
  { code: "eng", label: "English" },
  { code: "spa", label: "Español" },
  { code: "deu", label: "Deutsch" },
  { code: "por", label: "Português" },
  { code: "ita", label: "Italiano" },
  { code: "ara", label: "العربية" },
  { code: "chi_sim", label: "中文(简体)" },
  { code: "swa", label: "Kiswahili" },
  { code: "nld", label: "Nederlands" },
  { code: "rus", label: "Русский" },
];

/** Codes reconnus par le moteur de transcription (Whisper) — utilisés pour
 * informer l'utilisateur des langues prises en charge par la transcription
 * intelligente multilingue (détection + changement automatique de langue). */
export const TRANSCRIBE_LANGUAGES = [
  "Français",
  "English",
  "Español",
  "Deutsch",
  "中文 (Chinese)",
  "Kiswahili",
  "Português",
  "Italiano",
  "العربية",
  "+ 90 autres langues (moteur Whisper)",
];
