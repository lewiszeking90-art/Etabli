// Téléchargeur de vidéos : le lien est collé, la vidéo est retrouvée puis enregistrée sur l'appareil.
import { isSafePublicUrl } from "./urlSafety";

export type VideoErrorCode = "invalid" | "unsupported" | "facebook" | "network" | "notFound";

export class VideoError extends Error {
  constructor(public code: VideoErrorCode) {
    super(code);
  }
}

export interface FoundVideo {
  url: string;
  title: string;
  cover?: string;
}

const DIRECT_EXT = /\.(mp4|webm|mov|m4v)(\?.*)?$/i;
const TIKWM = "https://www.tikwm.com";

function normalize(raw: string): URL {
  const trimmed = raw.trim();
  if (!trimmed) throw new VideoError("invalid");
  const check = isSafePublicUrl(/^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`);
  if (!check.ok || !check.url) throw new VideoError("invalid");
  return check.url;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

interface TikwmResponse {
  code?: number;
  msg?: string;
  data?: { title?: string; play?: string; hdplay?: string; cover?: string };
}

async function findTikTok(url: URL): Promise<FoundVideo> {
  const candidates = [url.toString()];
  // Liens courts « tt.site/t/CODE » : on essaie aussi leurs formes TikTok officielles.
  const short = /^\/t\/([A-Za-z0-9]+)\/?$/.exec(url.pathname);
  if (/(^|\.)tt\.site$/.test(url.hostname) && short) {
    candidates.push(`https://www.tiktok.com/t/${short[1]}/`, `https://vm.tiktok.com/${short[1]}/`);
  }
  let reached = false;
  const abs = (u?: string) => (u ? (u.startsWith("http") ? u : TIKWM + u) : undefined);
  for (let i = 0; i < candidates.length; i++) {
    if (i > 0) await sleep(1200); // le service limite le nombre de requêtes par seconde
    try {
      const res = await fetch(`${TIKWM}/api/?url=${encodeURIComponent(candidates[i])}&hd=1`);
      const json = (await res.json()) as TikwmResponse;
      reached = true;
      const d = json.data;
      if (json.code === 0 && d) {
        const video = abs(d.hdplay) ?? abs(d.play);
        if (video) return { url: video, title: (d.title ?? "").slice(0, 80), cover: abs(d.cover) };
      }
    } catch {
      // essai suivant
    }
  }
  throw new VideoError(reached ? "notFound" : "network");
}

export async function findVideo(raw: string): Promise<FoundVideo> {
  const url = normalize(raw);
  const host = url.hostname.toLowerCase();
  if (/(^|\.)(tiktok\.com|tt\.site)$/.test(host)) return findTikTok(url);
  if (/(^|\.)(facebook\.com|fb\.watch|fb\.com)$/.test(host)) throw new VideoError("facebook");
  if (DIRECT_EXT.test(url.pathname + url.search)) {
    return { url: url.toString(), title: decodeURIComponent(url.pathname.split("/").pop() ?? "video") };
  }
  throw new VideoError("unsupported");
}

export function safeFileName(title: string, fallback = "video"): string {
  const base = title
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40);
  return (base || fallback).replace(/\.(mp4|webm|mov|m4v)$/i, "") + ".mp4";
}

/** Enregistre la vidéo sur l'appareil. Renvoie « opened » si le navigateur impose l'ouverture dans un onglet. */
export async function downloadVideo(
  url: string,
  fileName: string,
  onProgress?: (ratio: number) => void,
): Promise<"saved" | "opened"> {
  try {
    const res = await fetch(url);
    if (!res.ok || !res.body) throw new Error("fetch_failed");
    const total = Number(res.headers.get("content-length") ?? 0);
    const reader = res.body.getReader();
    const chunks: Uint8Array[] = [];
    let received = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      if (value) {
        chunks.push(value);
        received += value.length;
        if (total && onProgress) onProgress(Math.min(1, received / total));
      }
    }
    if (!received) throw new Error("empty");
    const blob = new Blob(chunks as BlobPart[], { type: "video/mp4" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(link.href), 4000);
    onProgress?.(1);
    return "saved";
  } catch {
    window.open(url, "_blank", "noopener");
    return "opened";
  }
}
