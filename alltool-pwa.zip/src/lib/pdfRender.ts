"use client";

// Rendu de pages PDF vers des canvas HTML, utilisé par l'outil OCR pour
// extraire le texte de documents PDF multi-pages. pdfjs-dist tourne
// entièrement dans le navigateur (aucun envoi du fichier à un serveur).
import { assetExists, withBase } from "./base";

export async function getPdfPageCount(file: File): Promise<number> {
  const pdfjsLib = await loadPdfJs();
  const buffer = await file.arrayBuffer();
  const doc = await pdfjsLib.getDocument({ data: buffer }).promise;
  const count = doc.numPages;
  return count;
}

export async function renderPdfPageToCanvas(file: File, pageNumber: number, scale = 2): Promise<HTMLCanvasElement> {
  const pdfjsLib = await loadPdfJs();
  const buffer = await file.arrayBuffer();
  const doc = await pdfjsLib.getDocument({ data: buffer }).promise;
  const page = await doc.getPage(pageNumber);
  const viewport = page.getViewport({ scale });
  const canvas = document.createElement("canvas");
  canvas.width = viewport.width;
  canvas.height = viewport.height;
  const ctx = canvas.getContext("2d")!;
  await page.render({ canvasContext: ctx, viewport, canvas }).promise;
  return canvas;
}

let pdfjsPromise: Promise<typeof import("pdfjs-dist")> | null = null;

async function loadPdfJs() {
  if (!pdfjsPromise) {
    pdfjsPromise = import("pdfjs-dist").then(async (lib) => {
      // Lecteur PDF intégré à l'application ; CDN public seulement en dernier recours.
      lib.GlobalWorkerOptions.workerSrc = (await assetExists("/vendor/pdf/pdf.worker.min.mjs"))
        ? withBase("/vendor/pdf/pdf.worker.min.mjs")
        : `https://unpkg.com/pdfjs-dist@${lib.version}/build/pdf.worker.min.mjs`;
      return lib;
    });
  }
  return pdfjsPromise;
}
