import type { TranslationKey } from "@/i18n/dictionary";

export type CategoryId = "browser" | "video" | "audio" | "images" | "pdf" | "text";

export type ToolBadge = "local" | "internet" | "apikey";

export interface ToolDef {
  id: string;
  category: CategoryId;
  href: string;
  nameKey: TranslationKey;
  descKey: TranslationKey;
  icon: string; // lucide-react icon name
  badges: ToolBadge[];
}

export const CATEGORIES: { id: CategoryId; titleKey: TranslationKey; descKey: TranslationKey; icon: string }[] = [
  { id: "browser", titleKey: "category.browser.title", descKey: "category.browser.desc", icon: "Compass" },
  { id: "video", titleKey: "category.video.title", descKey: "category.video.desc", icon: "Video" },
  { id: "audio", titleKey: "category.audio.title", descKey: "category.audio.desc", icon: "AudioLines" },
  { id: "images", titleKey: "category.images.title", descKey: "category.images.desc", icon: "Images" },
  { id: "pdf", titleKey: "category.pdf.title", descKey: "category.pdf.desc", icon: "FileText" },
  { id: "text", titleKey: "category.text.title", descKey: "category.text.desc", icon: "Type" },
];

export const TOOLS: ToolDef[] = [
  {
    id: "browser",
    category: "browser",
    href: "/browser",
    nameKey: "tool.browser.name",
    descKey: "tool.browser.desc",
    icon: "Compass",
    badges: ["internet"],
  },
  {
    id: "video-download",
    category: "video",
    href: "/outils/video/telecharger",
    nameKey: "tool.videoDownload.name",
    descKey: "tool.videoDownload.desc",
    icon: "Download",
    badges: ["internet"],
  },
  {
    id: "video-compress",
    category: "video",
    href: "/outils/video/compresser",
    nameKey: "tool.videoCompress.name",
    descKey: "tool.videoCompress.desc",
    icon: "Shrink",
    badges: ["local"],
  },
  {
    id: "video-extract-audio",
    category: "video",
    href: "/outils/video/extraire-audio",
    nameKey: "tool.videoExtractAudio.name",
    descKey: "tool.videoExtractAudio.desc",
    icon: "AudioWaveform",
    badges: ["local"],
  },
  {
    id: "video-merge",
    category: "video",
    href: "/outils/video/fusionner",
    nameKey: "tool.videoMerge.name",
    descKey: "tool.videoMerge.desc",
    icon: "Combine",
    badges: ["local"],
  },
  {
    id: "audio-merge",
    category: "audio",
    href: "/outils/audio/fusionner",
    nameKey: "tool.audioMerge.name",
    descKey: "tool.audioMerge.desc",
    icon: "ListMusic",
    badges: ["local"],
  },
  {
    id: "tts",
    category: "audio",
    href: "/outils/audio/voix",
    nameKey: "tool.tts.name",
    descKey: "tool.tts.desc",
    icon: "Volume2",
    badges: ["local"],
  },
  {
    id: "transcribe",
    category: "audio",
    href: "/outils/audio/transcription",
    nameKey: "tool.transcribe.name",
    descKey: "tool.transcribe.desc",
    icon: "Captions",
    badges: ["local"],
  },
  {
    id: "images-to-pdf",
    category: "pdf",
    href: "/outils/images/vers-pdf",
    nameKey: "tool.imagesToPdf.name",
    descKey: "tool.imagesToPdf.desc",
    icon: "FileImage",
    badges: ["local"],
  },
  {
    id: "images-combine",
    category: "images",
    href: "/outils/images/combiner",
    nameKey: "tool.imagesCombine.name",
    descKey: "tool.imagesCombine.desc",
    icon: "GalleryHorizontalEnd",
    badges: ["local"],
  },
  {
    id: "image-enhance",
    category: "images",
    href: "/outils/images/ameliorer",
    nameKey: "tool.imageEnhance.name",
    descKey: "tool.imageEnhance.desc",
    icon: "Sparkles",
    badges: ["local"],
  },
  {
    id: "ocr",
    category: "pdf",
    href: "/outils/pdf/ocr",
    nameKey: "tool.ocr.name",
    descKey: "tool.ocr.desc",
    icon: "ScanText",
    badges: ["local"],
  },
  {
    id: "text-to-pages",
    category: "pdf",
    href: "/outils/pdf/texte-vers-pages",
    nameKey: "tool.textToPages.name",
    descKey: "tool.textToPages.desc",
    icon: "FileOutput",
    badges: ["local"],
  },
  {
    id: "handwriting",
    category: "pdf",
    href: "/outils/pdf/manuscrit",
    nameKey: "tool.handwriting.name",
    descKey: "tool.handwriting.desc",
    icon: "PenLine",
    badges: ["local"],
  },
  {
    id: "translate",
    category: "text",
    href: "/outils/texte/traduire",
    nameKey: "tool.translate.name",
    descKey: "tool.translate.desc",
    icon: "Languages",
    badges: ["internet"],
  },
];

export function getToolById(id: string) {
  return TOOLS.find((tool) => tool.id === id);
}
