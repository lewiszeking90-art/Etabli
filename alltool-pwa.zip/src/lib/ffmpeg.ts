"use client";

// Chargeur paresseux et singleton pour ffmpeg.wasm (traitement vidéo/audio
// 100% local, dans le navigateur). Le coeur WebAssembly (~25 Mo) est
// intégré à l'application (aucun téléchargement à l'usage).
import type { FFmpeg } from "@ffmpeg/ffmpeg";
import { assetExists, withBase } from "./base";

let ffmpegInstance: FFmpeg | null = null;
let loadingPromise: Promise<FFmpeg> | null = null;

// Le moteur est intégré à l'application (public/vendor/ffmpeg). Si le fichier manque
// (build incomplet), on retombe sur le CDN public.
const LOCAL_CORE = withBase("/vendor/ffmpeg");
const CDN_CORE = "https://unpkg.com/@ffmpeg/core@0.12.6/dist/esm";

async function resolveCoreBase(): Promise<string> {
  return (await assetExists("/vendor/ffmpeg/ffmpeg-core.wasm")) ? LOCAL_CORE : CDN_CORE;
}

export async function getFFmpeg(onLog?: (message: string) => void): Promise<FFmpeg> {
  if (ffmpegInstance && ffmpegInstance.loaded) return ffmpegInstance;
  if (loadingPromise) return loadingPromise;

  loadingPromise = (async () => {
    const { FFmpeg } = await import("@ffmpeg/ffmpeg");
    const { toBlobURL } = await import("@ffmpeg/util");
    const instance = new FFmpeg();
    if (onLog) {
      instance.on("log", ({ message }) => onLog(message));
    }
    const base = await resolveCoreBase();
    const [coreURL, wasmURL] = await Promise.all([
      toBlobURL(`${base}/ffmpeg-core.js`, "text/javascript"),
      toBlobURL(`${base}/ffmpeg-core.wasm`, "application/wasm"),
    ]);
    await instance.load({ coreURL, wasmURL });
    ffmpegInstance = instance;
    return instance;
  })();

  try {
    return await loadingPromise;
  } finally {
    loadingPromise = null;
  }
}

export interface FFmpegJobInput {
  name: string;
  data: Uint8Array;
}

export interface RunFFmpegJobOptions {
  inputs: FFmpegJobInput[];
  args: string[];
  outputName: string;
  onProgress?: (ratio: number) => void;
  signal?: AbortSignal;
  onLog?: (message: string) => void;
}

/** Exécute une commande ffmpeg "jetable" : écrit les fichiers d'entrée dans le
 * système de fichiers virtuel, exécute la commande, lit le résultat puis
 * nettoie tout (mémoire limitée). */
export async function runFFmpegJob(options: RunFFmpegJobOptions): Promise<Uint8Array> {
  const ffmpeg = await getFFmpeg(options.onLog);

  const progressHandler = ({ progress }: { progress: number }) => {
    if (options.onProgress) options.onProgress(Math.min(1, Math.max(0, progress)));
  };
  ffmpeg.on("progress", progressHandler);

  try {
    for (const input of options.inputs) {
      await ffmpeg.writeFile(input.name, input.data);
    }
    await ffmpeg.exec(options.args, undefined, { signal: options.signal });
    const output = await ffmpeg.readFile(options.outputName);
    return output as Uint8Array;
  } finally {
    ffmpeg.off("progress", progressHandler);
    for (const input of options.inputs) {
      try {
        await ffmpeg.deleteFile(input.name);
      } catch {
        // ignore
      }
    }
    try {
      await ffmpeg.deleteFile(options.outputName);
    } catch {
      // ignore
    }
  }
}

export function bytesToSize(bytes: number): string {
  if (!bytes) return "0 o";
  const units = ["o", "Ko", "Mo", "Go"];
  const i = Math.min(units.length - 1, Math.floor(Math.log(bytes) / Math.log(1024)));
  return `${(bytes / 1024 ** i).toFixed(i === 0 ? 0 : 1)} ${units[i]}`;
}
