// Pont avec la version Android (APK). Sur le site web, rien de tout ça n'est utilisé.
import { Capacitor, registerPlugin } from "@capacitor/core";

interface VideoBrowserPlugin {
  open(options: { url: string }): Promise<void>;
}

const VideoBrowser = registerPlugin<VideoBrowserPlugin>("VideoBrowser");

interface FileSaverPlugin {
  begin(o: { name: string; mime: string }): Promise<{ id: string }>;
  append(o: { id: string; data: string }): Promise<void>;
  finish(o: { id: string }): Promise<{ where: string }>;
  abort(o: { id: string }): Promise<void>;
}
const FileSaver = registerPlugin<FileSaverPlugin>("FileSaver");

function toBase64(bytes: Uint8Array): string {
  let s = "";
  const step = 8192;
  for (let i = 0; i < bytes.length; i += step) s += String.fromCharCode(...bytes.subarray(i, i + step));
  return btoa(s);
}

/** Enregistre un fichier dans Téléchargements/AllTool (APK). Renvoie l'emplacement. */
export async function saveBlobNative(blob: Blob, name: string): Promise<string> {
  const { id } = await FileSaver.begin({ name, mime: blob.type || "application/octet-stream" });
  try {
    const CHUNK = 768 * 1024; // multiple de 3 : le base64 se colle sans erreur
    for (let off = 0; off < blob.size; off += CHUNK) {
      const bytes = new Uint8Array(await blob.slice(off, off + CHUNK).arrayBuffer());
      await FileSaver.append({ id, data: toBase64(bytes) });
    }
    const r = await FileSaver.finish({ id });
    return r.where;
  } catch (e) {
    try { await FileSaver.abort({ id }); } catch { /* ignoré */ }
    throw e;
  }
}

export interface SavedDetail { name: string; where?: string; error?: string }

/** Prévient l'écran qu'un enregistrement est terminé (fenêtre « Terminé »). */
export function announceSaved(detail: SavedDetail): void {
  window.dispatchEvent(new CustomEvent("alltool:saved", { detail }));
}

/** Vrai quand l'application tourne dans l'APK (pas dans un navigateur). */
export function isNativeApp(): boolean {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
}

/** Ouvre le navigateur natif plein écran : il détecte la vidéo et propose « Télécharger ». */
export async function openVideoBrowser(url: string): Promise<void> {
  await VideoBrowser.open({ url });
}

const TEXT = {
  fr: {
    browserNote: "Le navigateur s'ouvre en plein écran. Quand une vidéo est détectée, le bouton « Télécharger la vidéo » apparaît en bas.",
    downloadNote: "Collez le lien : la page s'ouvre, puis le bouton « Télécharger la vidéo » apparaît dès que la vidéo est trouvée.",
    doneTitle: "Terminé",
    savedIn: "Enregistré dans :",
    started: "Téléchargement lancé :",
    failed: "L'enregistrement a échoué.",
    ok: "OK",
  },
  en: {
    browserNote: "The browser opens full screen. When a video is detected, a “Download video” button appears at the bottom.",
    downloadNote: "Paste the link: the page opens, then a “Download video” button appears as soon as the video is found.",
    doneTitle: "Done",
    savedIn: "Saved in:",
    started: "Download started:",
    failed: "Saving failed.",
    ok: "OK",
  },
};

export function nativeText(locale: string) {
  return locale === "fr" ? TEXT.fr : TEXT.en;
}
