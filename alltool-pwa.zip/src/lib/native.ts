// Pont avec la version Android (APK). Sur le site web, rien de tout ça n'est utilisé.
import { Capacitor, registerPlugin } from "@capacitor/core";

interface VideoBrowserPlugin {
  open(options: { url: string }): Promise<void>;
}

const VideoBrowser = registerPlugin<VideoBrowserPlugin>("VideoBrowser");

/** Vrai quand l'application tourne dans l'APK (pas dans un navigateur). */
export function isNativeApp(): boolean {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
}

/** Ouvre le navigateur natif plein écran : il détecte la vidéo et propose « Télécharger ». */
export async function openVideoBrowser(url: string): Promise<void> {
  await VideoBrowser.open({ url });
}

const TEXT = {
  fr: {
    browserNote: "Le navigateur s'ouvre en plein écran. Quand une vidéo est détectée, le bouton « Télécharger la vidéo » apparaît en bas.",
    downloadNote: "Collez le lien : la page s'ouvre, puis le bouton « Télécharger la vidéo » apparaît dès que la vidéo est trouvée.",
  },
  en: {
    browserNote: "The browser opens full screen. When a video is detected, a “Download video” button appears at the bottom.",
    downloadNote: "Paste the link: the page opens, then a “Download video” button appears as soon as the video is found.",
  },
};

export function nativeText(locale: string) {
  return locale === "fr" ? TEXT.fr : TEXT.en;
}
