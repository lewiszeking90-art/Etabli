export interface CombineOptions {
  direction: "horizontal" | "vertical";
  spacing: number;
  background: string;
}

export function combineImagesToCanvas(images: HTMLImageElement[], options: CombineOptions): HTMLCanvasElement {
  const { direction, spacing, background } = options;
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d")!;

  if (direction === "horizontal") {
    const targetHeight = Math.min(...images.map((i) => i.naturalHeight));
    const scaled = images.map((img) => ({
      img,
      w: (img.naturalWidth * targetHeight) / img.naturalHeight,
      h: targetHeight,
    }));
    const totalWidth = scaled.reduce((sum, s) => sum + s.w, 0) + spacing * (images.length - 1);
    canvas.width = Math.round(totalWidth);
    canvas.height = Math.round(targetHeight);
    ctx.fillStyle = background;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    let x = 0;
    for (const s of scaled) {
      ctx.drawImage(s.img, x, 0, s.w, s.h);
      x += s.w + spacing;
    }
  } else {
    const targetWidth = Math.min(...images.map((i) => i.naturalWidth));
    const scaled = images.map((img) => ({
      img,
      w: targetWidth,
      h: (img.naturalHeight * targetWidth) / img.naturalWidth,
    }));
    const totalHeight = scaled.reduce((sum, s) => sum + s.h, 0) + spacing * (images.length - 1);
    canvas.width = Math.round(targetWidth);
    canvas.height = Math.round(totalHeight);
    ctx.fillStyle = background;
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    let y = 0;
    for (const s of scaled) {
      ctx.drawImage(s.img, 0, y, s.w, s.h);
      y += s.h + spacing;
    }
  }

  return canvas;
}
