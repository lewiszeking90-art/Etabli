// Traduction sans clé API : traducteur intégré au navigateur s'il existe (hors ligne),
// sinon le service gratuit MyMemory (le texte lui est transmis).
import { dominantLang } from "./langDetect";

export const TRANSLATE_LANGUAGES: [string, string][] = [
  ["ar", "العربية"], ["bg", "Български"], ["ca", "Català"], ["zh", "中文"], ["cs", "Čeština"], ["da", "Dansk"],
  ["nl", "Nederlands"], ["en", "English"], ["et", "Eesti"], ["fi", "Suomi"], ["fr", "Français"], ["de", "Deutsch"],
  ["el", "Ελληνικά"], ["he", "עברית"], ["hi", "हिन्दी"], ["hu", "Magyar"], ["id", "Bahasa Indonesia"], ["it", "Italiano"],
  ["ja", "日本語"], ["ko", "한국어"], ["lv", "Latviešu"], ["lt", "Lietuvių"], ["ms", "Bahasa Melayu"], ["no", "Norsk"],
  ["fa", "فارسی"], ["pl", "Polski"], ["pt", "Português"], ["ro", "Română"], ["ru", "Русский"], ["sr", "Српски"],
  ["sk", "Slovenčina"], ["sl", "Slovenščina"], ["es", "Español"], ["sw", "Kiswahili"], ["sv", "Svenska"], ["th", "ไทย"],
  ["tr", "Türkçe"], ["uk", "Українська"], ["ur", "اردو"], ["vi", "Tiếng Việt"], ["ln", "Lingála"],
];

export class TranslateError extends Error {
  constructor(public code: "same" | "service") {
    super(code);
  }
}

interface BrowserTranslator { translate: (text: string) => Promise<string> }
interface TranslatorApi {
  availability: (o: { sourceLanguage: string; targetLanguage: string }) => Promise<string>;
  create: (o: { sourceLanguage: string; targetLanguage: string }) => Promise<BrowserTranslator>;
}

export function chunkText(text: string, max = 450): string[] {
  const parts = text.match(/[^.!?。！？\n]+[.!?。！？]*\s*|\n+/g) ?? [text];
  const out: string[] = [];
  let cur = "";
  for (const p of parts) {
    if ((cur + p).length > max && cur) { out.push(cur); cur = ""; }
    if (p.length > max) {
      for (let i = 0; i < p.length; i += max) out.push(p.slice(i, i + max));
    } else cur += p;
  }
  if (cur) out.push(cur);
  return out;
}

const mm = (code: string) => (code === "zh" ? "zh-CN" : code);

export async function translateText(
  text: string,
  source: string, // "auto" ou code
  target: string,
  onProgress?: (done: number, total: number) => void,
): Promise<string> {
  let src = source === "auto" ? dominantLang(text) : source;
  if (src === "und") src = "auto";
  if (src === target) throw new TranslateError("same");

  const api = (self as unknown as { Translator?: TranslatorApi }).Translator;
  let local: BrowserTranslator | null = null;
  if (api && src !== "auto") {
    try {
      if ((await api.availability({ sourceLanguage: src, targetLanguage: target })) !== "unavailable") {
        local = await api.create({ sourceLanguage: src, targetLanguage: target });
      }
    } catch {
      local = null;
    }
  }

  const parts = chunkText(text);
  const out: string[] = [];
  for (let i = 0; i < parts.length; i++) {
    onProgress?.(i, parts.length);
    const p = parts[i];
    if (!p.trim()) { out.push(p); continue; }
    if (local) {
      out.push(await local.translate(p));
      continue;
    }
    try {
      const pair = `${src === "auto" ? "Autodetect" : mm(src)}|${mm(target)}`;
      const res = await fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(p)}&langpair=${encodeURIComponent(pair)}`);
      const json = (await res.json()) as { responseStatus?: number; responseData?: { translatedText?: string } };
      if (json.responseStatus !== 200 || !json.responseData?.translatedText) throw new Error("bad_response");
      out.push(json.responseData.translatedText);
    } catch {
      throw new TranslateError("service");
    }
    if (i < parts.length - 1) await new Promise((r) => setTimeout(r, 350));
  }
  onProgress?.(parts.length, parts.length);
  return out.join("");
}
