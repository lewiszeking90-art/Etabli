"use client";

// Transcription INTELLIGENTE, 100 % sur l'appareil, sans clé API ni compte :
// 1) l'audio est décodé et analysé en entier ; 2) il est découpé aux silences ;
// 3) chaque segment est transcrit par Whisper (modèle multilingue qui devine la langue du segment) ;
// 4) la langue de chaque segment est affichée et le tout est assemblé avec les horodatages.
import { assetExists, withBase } from "./base";
import { dominantLang } from "./langDetect";

export interface TranscriptItem {
  start: number;
  end: number;
  text: string;
  lang: string;
}

export type Status =
  | { kind: "analyzing" }
  | { kind: "loading" }
  | { kind: "segment"; i: number; n: number };

export class SpeechError extends Error {
  constructor(public code: "noSpeech" | "tooLong" | "decode", message?: string) {
    super(message ?? code);
  }
}

const MODEL = "onnx-community/whisper-base";
const MAX_SECONDS = 20 * 60;
const SR = 16000;
const CDN = "https://cdn.jsdelivr.net/npm/@huggingface/transformers@3/+esm";

interface TransformersEnv {
  allowLocalModels: boolean;
  allowRemoteModels: boolean;
  localModelPath: string;
  useBrowserCache: boolean;
  backends: { onnx: { wasm: { wasmPaths?: string; numThreads?: number } } };
}
interface TransformersModule {
  env: TransformersEnv;
  pipeline: (task: string, model: string, options?: Record<string, unknown>) => Promise<unknown>;
}
type Recognizer = (audio: Float32Array, options?: Record<string, unknown>) => Promise<{ text?: string }>;

let transformersPromise: Promise<TransformersModule> | null = null;
let recognizerPromise: Promise<Recognizer> | null = null;

async function loadTransformers(): Promise<TransformersModule> {
  if (!transformersPromise) {
    transformersPromise = (async () => {
      const sources: string[] = [];
      if (await assetExists("/vendor/transformers/transformers.min.js")) sources.push(withBase("/vendor/transformers/transformers.min.js"));
      sources.push(CDN);
      let lastError: unknown = null;
      for (const url of sources) {
        try {
          const mod = (await import(/* webpackIgnore: true */ /* turbopackIgnore: true */ url)) as TransformersModule;
          return mod;
        } catch (e) {
          lastError = e;
        }
      }
      throw lastError instanceof Error ? lastError : new Error("transformers_unavailable");
    })();
    transformersPromise.catch(() => { transformersPromise = null; });
  }
  return transformersPromise;
}

async function getRecognizer(onProgress?: (ratio: number) => void): Promise<Recognizer> {
  if (!recognizerPromise) {
    recognizerPromise = (async () => {
      const tf = await loadTransformers();
      tf.env.useBrowserCache = true;
      tf.env.backends.onnx.wasm.numThreads = 1; // pas besoin d'isolation cross-origin
      if (await assetExists("/vendor/ort/ort-wasm-simd-threaded.wasm")) tf.env.backends.onnx.wasm.wasmPaths = withBase("/vendor/ort/");
      const opts = {
        dtype: "q8",
        device: "wasm",
        progress_callback: (p: { status?: string; progress?: number }) => {
          if (p.status === "progress" && typeof p.progress === "number" && onProgress) onProgress(p.progress / 100);
        },
      };
      // 1) modèle intégré à l'application ; 2) à défaut, Hugging Face (téléchargement une fois, mis en cache)
      const hasLocal = await assetExists(`/models/${MODEL}/config.json`);
      tf.env.allowLocalModels = true;
      tf.env.localModelPath = withBase("/models/");
      tf.env.allowRemoteModels = !hasLocal;
      try {
        return (await tf.pipeline("automatic-speech-recognition", MODEL, opts)) as Recognizer;
      } catch (e) {
        if (!hasLocal) throw e;
        tf.env.allowRemoteModels = true;
        return (await tf.pipeline("automatic-speech-recognition", MODEL, opts)) as Recognizer;
      }
    })();
    recognizerPromise.catch(() => { recognizerPromise = null; });
  }
  return recognizerPromise;
}

/** Décode n'importe quel fichier audio/vidéo en mono 16 kHz. */
export async function decodeMono16k(blob: Blob): Promise<{ data: Float32Array; duration: number }> {
  const w = window as unknown as { AudioContext?: typeof AudioContext; webkitAudioContext?: typeof AudioContext };
  const AC = w.AudioContext ?? w.webkitAudioContext;
  if (!AC) throw new SpeechError("decode");
  const ctx = new AC();
  let buffer: AudioBuffer;
  try {
    buffer = await ctx.decodeAudioData(await blob.arrayBuffer());
  } catch {
    throw new SpeechError("decode");
  } finally {
    void ctx.close().catch(() => undefined);
  }
  const off = new OfflineAudioContext(1, Math.max(1, Math.ceil(buffer.duration * SR)), SR);
  const src = off.createBufferSource();
  src.buffer = buffer;
  src.connect(off.destination);
  src.start();
  const rendered = await off.startRendering();
  return { data: rendered.getChannelData(0), duration: buffer.duration };
}

/** Découpe aux silences : renvoie des intervalles [début, fin] en secondes (30 s maximum). */
export function segmentSpeech(x: Float32Array, sr = SR): [number, number][] {
  const hop = Math.round(sr * 0.03);
  const n = Math.floor(x.length / hop);
  if (n < 3) return [];
  const rms = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    let s = 0;
    for (let k = i * hop; k < (i + 1) * hop; k++) s += x[k] * x[k];
    rms[i] = Math.sqrt(s / hop);
  }
  const sorted = Array.from(rms).sort((a, b) => a - b);
  const p95 = sorted[Math.floor(n * 0.95)] || 0;
  const floor = sorted[Math.floor(n * 0.1)] || 0;
  const thr = Math.max(Math.min(floor * 3, p95 * 0.3), p95 * 0.08, 0.004);
  const fs = hop / sr;

  const regions: [number, number][] = [];
  let st = -1;
  for (let i = 0; i <= n; i++) {
    const on = i < n && rms[i] > thr;
    if (on && st < 0) st = i;
    if (!on && st >= 0) { regions.push([st, i]); st = -1; }
  }
  const merged: [number, number][] = [];
  for (const r of regions) {
    const last = merged[merged.length - 1];
    if (last && (r[0] - last[1]) * fs < 0.6) last[1] = r[1];
    else merged.push([r[0], r[1]]);
  }
  const dur = x.length / sr;
  const out: [number, number][] = [];
  for (const [a, b] of merged) {
    if ((b - a) * fs < 0.25) continue;
    let s = Math.max(0, a * fs - 0.15);
    const e = Math.min(dur, b * fs + 0.15);
    while (e - s > 25) { // coupe au point le plus calme entre 12 s et 24 s
      const lo = Math.floor((s + 12) / fs);
      const hi = Math.floor((s + 24) / fs);
      let mi = lo;
      for (let i = lo; i < Math.min(hi, n); i++) if (rms[i] < rms[mi]) mi = i;
      out.push([s, mi * fs]);
      s = mi * fs;
    }
    out.push([s, e]);
  }
  return out;
}

export async function transcribeBlob(
  blob: Blob,
  onStatus: (s: Status) => void,
  onProgress: (ratio: number) => void,
): Promise<TranscriptItem[]> {
  onStatus({ kind: "analyzing" });
  const { data, duration } = await decodeMono16k(blob);
  if (duration > MAX_SECONDS) throw new SpeechError("tooLong");
  const regions = segmentSpeech(data);
  if (!regions.length) throw new SpeechError("noSpeech");

  onStatus({ kind: "loading" });
  const recognize = await getRecognizer((r) => onProgress(r * 0.3));

  const items: TranscriptItem[] = [];
  for (let i = 0; i < regions.length; i++) {
    const [a, b] = regions[i];
    onStatus({ kind: "segment", i: i + 1, n: regions.length });
    onProgress(0.3 + (0.7 * i) / regions.length);
    const slice = data.slice(Math.floor(a * SR), Math.ceil(b * SR));
    const res = await recognize(slice, { task: "transcribe" }); // la langue est devinée par le modèle, segment par segment
    const text = (res.text ?? "").trim();
    if (text) items.push({ start: a, end: b, text, lang: dominantLang(text) });
  }
  onProgress(1);
  return items;
}
