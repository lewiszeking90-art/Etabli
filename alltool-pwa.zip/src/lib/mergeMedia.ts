"use client";

import { getFFmpeg } from "./ffmpeg";

export interface MergeProgressInfo {
  stepIndex: number;
  totalSteps: number;
  stepProgress: number;
}

export interface MergeVideoOptions {
  height: number;
  fps: number;
  videoKbps: number;
  audioKbps: number;
  signal?: AbortSignal;
  onProgress?: (info: MergeProgressInfo) => void;
}

/**
 * Fusionne plusieurs vidéos dans l'ordre fourni. Les différences de
 * résolution, fréquence d'images et codecs sont normalisées avant la
 * concaténation (requis pour un assemblage fiable).
 */
export async function mergeVideos(files: File[], options: MergeVideoOptions): Promise<Uint8Array> {
  const ffmpeg = await getFFmpeg();
  const totalSteps = files.length + 1;
  let stepIndex = 0;

  const progressHandler = ({ progress }: { progress: number }) => {
    options.onProgress?.({ stepIndex, totalSteps, stepProgress: Math.min(1, Math.max(0, progress)) });
  };
  ffmpeg.on("progress", progressHandler);

  const normalizedNames: string[] = [];
  try {
    for (let i = 0; i < files.length; i++) {
      stepIndex = i;
      const file = files[i];
      const inputName = `src_${i}${file.name.match(/\.\w+$/)?.[0] ?? ".mp4"}`;
      const normName = `norm_${i}.mp4`;
      await ffmpeg.writeFile(inputName, new Uint8Array(await file.arrayBuffer()));
      await ffmpeg.exec(
        [
          "-i",
          inputName,
          "-vf",
          `scale=-2:${options.height},fps=${options.fps}`,
          "-c:v",
          "libx264",
          "-preset",
          "veryfast",
          "-b:v",
          `${options.videoKbps}k`,
          "-c:a",
          "aac",
          "-b:a",
          `${options.audioKbps}k`,
          "-ar",
          "44100",
          normName,
        ],
        undefined,
        { signal: options.signal },
      );
      await ffmpeg.deleteFile(inputName);
      normalizedNames.push(normName);
    }

    stepIndex = files.length;
    const listContent = normalizedNames.map((n) => `file '${n}'`).join("\n");
    await ffmpeg.writeFile("concat_list.txt", new TextEncoder().encode(listContent));
    await ffmpeg.exec(
      ["-f", "concat", "-safe", "0", "-i", "concat_list.txt", "-c", "copy", "output.mp4"],
      undefined,
      { signal: options.signal },
    );
    const data = await ffmpeg.readFile("output.mp4");
    return data as Uint8Array;
  } finally {
    ffmpeg.off("progress", progressHandler);
    for (const n of normalizedNames) {
      try {
        await ffmpeg.deleteFile(n);
      } catch {
        /* noop */
      }
    }
    try {
      await ffmpeg.deleteFile("concat_list.txt");
    } catch {
      /* noop */
    }
    try {
      await ffmpeg.deleteFile("output.mp4");
    } catch {
      /* noop */
    }
  }
}

export interface MergeAudioOptions {
  format: "mp3" | "m4a";
  bitrateKbps: number;
  signal?: AbortSignal;
  onProgress?: (info: MergeProgressInfo) => void;
}

export async function mergeAudios(files: File[], options: MergeAudioOptions): Promise<Uint8Array> {
  const ffmpeg = await getFFmpeg();
  const totalSteps = files.length + 1;
  let stepIndex = 0;
  const codec = options.format === "mp3" ? "libmp3lame" : "aac";
  const ext = options.format === "mp3" ? "mp3" : "m4a";

  const progressHandler = ({ progress }: { progress: number }) => {
    options.onProgress?.({ stepIndex, totalSteps, stepProgress: Math.min(1, Math.max(0, progress)) });
  };
  ffmpeg.on("progress", progressHandler);

  const normalizedNames: string[] = [];
  try {
    for (let i = 0; i < files.length; i++) {
      stepIndex = i;
      const file = files[i];
      const inputName = `src_${i}${file.name.match(/\.\w+$/)?.[0] ?? ".mp3"}`;
      const normName = `norm_${i}.${ext}`;
      await ffmpeg.writeFile(inputName, new Uint8Array(await file.arrayBuffer()));
      await ffmpeg.exec(
        ["-i", inputName, "-ar", "44100", "-ac", "2", "-c:a", codec, "-b:a", `${options.bitrateKbps}k`, normName],
        undefined,
        { signal: options.signal },
      );
      await ffmpeg.deleteFile(inputName);
      normalizedNames.push(normName);
    }

    stepIndex = files.length;
    const listContent = normalizedNames.map((n) => `file '${n}'`).join("\n");
    await ffmpeg.writeFile("concat_list.txt", new TextEncoder().encode(listContent));
    await ffmpeg.exec(
      ["-f", "concat", "-safe", "0", "-i", "concat_list.txt", "-c", "copy", `output.${ext}`],
      undefined,
      { signal: options.signal },
    );
    const data = await ffmpeg.readFile(`output.${ext}`);
    return data as Uint8Array;
  } finally {
    ffmpeg.off("progress", progressHandler);
    for (const n of normalizedNames) {
      try {
        await ffmpeg.deleteFile(n);
      } catch {
        /* noop */
      }
    }
    try {
      await ffmpeg.deleteFile("concat_list.txt");
    } catch {
      /* noop */
    }
    try {
      await ffmpeg.deleteFile(`output.${ext}`);
    } catch {
      /* noop */
    }
  }
}
