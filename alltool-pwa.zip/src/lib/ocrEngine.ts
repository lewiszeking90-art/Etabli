"use client";

import type { Worker } from "tesseract.js";
import { assetExists, withBase } from "./base";

// Langues dont les données sont intégrées à l'application (voir scripts/prepare-vendor.mjs).
const BUNDLED_LANGS = ["fra", "eng", "spa", "deu", "por", "ita", "ara", "chi_sim", "swa", "nld", "rus"];

async function localOptions(langs: string) {
  const wanted = langs.split("+");
  const allBundled = wanted.every((l) => BUNDLED_LANGS.includes(l));
  if (!allBundled || !(await assetExists("/vendor/tesseract/worker.min.js"))) return {};
  if (!(await assetExists(`/vendor/tesseract/lang/${wanted[0]}.traineddata.gz`))) return {};
  return {
    workerPath: withBase("/vendor/tesseract/worker.min.js"),
    corePath: withBase("/vendor/tesseract"),
    langPath: withBase("/vendor/tesseract/lang"),
    gzip: true,
  };
}

let workerPromise: Promise<Worker> | null = null;
let currentLangs = "";

export async function getOcrWorker(langs: string, onProgress?: (p: number) => void): Promise<Worker> {
  if (workerPromise && currentLangs === langs) return workerPromise;
  if (workerPromise) {
    const prev = await workerPromise;
    await prev.terminate();
  }
  currentLangs = langs;
  workerPromise = (async () => {
    const { createWorker } = await import("tesseract.js");
    const local = await localOptions(langs);
    const worker = await createWorker(langs, 1, {
      ...local,
      logger: (m) => {
        if (m.status === "recognizing text" && onProgress) onProgress(m.progress);
      },
    });
    return worker;
  })();
  return workerPromise;
}

export async function terminateOcrWorker() {
  if (workerPromise) {
    const worker = await workerPromise;
    await worker.terminate();
    workerPromise = null;
    currentLangs = "";
  }
}
