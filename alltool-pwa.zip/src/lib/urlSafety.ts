// Garde-fous basiques contre les URL dangereuses (SSRF, protocoles non http,
// cibles internes) pour le navigateur intégré et le téléchargeur vidéo.
const PRIVATE_HOST_PATTERNS = [
  /^localhost$/i,
  /^127\./,
  /^0\.0\.0\.0$/,
  /^10\./,
  /^192\.168\./,
  /^169\.254\./,
  /^172\.(1[6-9]|2\d|3[0-1])\./,
  /^::1$/,
  /\.local$/i,
  /^\[::1\]$/,
];

export function isSafePublicUrl(raw: string): { ok: boolean; url?: URL; reason?: string } {
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    return { ok: false, reason: "invalid_url" };
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") {
    return { ok: false, reason: "unsupported_protocol" };
  }
  if (PRIVATE_HOST_PATTERNS.some((re) => re.test(url.hostname))) {
    return { ok: false, reason: "private_host" };
  }
  return { ok: true, url };
}

export function normalizeAddressBarInput(input: string): string {
  const trimmed = input.trim();
  if (!trimmed) return trimmed;
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  // Ressemble à un domaine (ex: "example.com" ou "example.com/page")
  if (/^[\w-]+(\.[\w-]+)+(\/.*)?$/i.test(trimmed) && !trimmed.includes(" ")) {
    return `https://${trimmed}`;
  }
  // Sinon on traite l'entrée comme une recherche.
  return `https://duckduckgo.com/?q=${encodeURIComponent(trimmed)}`;
}
