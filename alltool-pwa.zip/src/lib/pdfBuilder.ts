import { PDFDocument, StandardFonts, rgb, type PDFFont } from "pdf-lib";

export type PageFormat = "a4" | "letter" | "a5";
export type Orientation = "portrait" | "landscape";

const PAGE_SIZES: Record<PageFormat, [number, number]> = {
  a4: [595.28, 841.89],
  letter: [612, 792],
  a5: [419.53, 595.28],
};

export function getPageSize(format: PageFormat, orientation: Orientation): [number, number] {
  const [w, h] = PAGE_SIZES[format];
  return orientation === "landscape" ? [h, w] : [w, h];
}

export interface TextToPagesOptions {
  format: PageFormat;
  orientation: Orientation;
  margin: number;
  fontSize: number;
  lineHeightFactor?: number;
}

/** Génère un PDF (une ou plusieurs pages) à partir d'un texte brut, avec
 * retour à la ligne automatique et pagination selon l'espace disponible. */
export async function buildTextPdf(text: string, options: TextToPagesOptions): Promise<Uint8Array> {
  const { format, orientation, margin, fontSize } = options;
  const lineHeight = fontSize * (options.lineHeightFactor ?? 1.4);
  const [pageWidth, pageHeight] = getPageSize(format, orientation);
  const maxWidth = pageWidth - margin * 2;

  const doc = await PDFDocument.create();
  const font = await doc.embedFont(StandardFonts.Helvetica);

  const paragraphs = text.split(/\r?\n/);
  const lines: string[] = [];
  for (const paragraph of paragraphs) {
    if (paragraph.trim() === "") {
      lines.push("");
      continue;
    }
    lines.push(...wrapLine(paragraph, font, fontSize, maxWidth));
  }

  let page = doc.addPage([pageWidth, pageHeight]);
  let y = pageHeight - margin;

  for (const line of lines) {
    if (y < margin + lineHeight) {
      page = doc.addPage([pageWidth, pageHeight]);
      y = pageHeight - margin;
    }
    if (line) {
      page.drawText(line, { x: margin, y: y - fontSize, size: fontSize, font, color: rgb(0.1, 0.1, 0.12) });
    }
    y -= lineHeight;
  }

  return doc.save();
}

function wrapLine(text: string, font: PDFFont, fontSize: number, maxWidth: number): string[] {
  const words = text.split(/\s+/).filter(Boolean);
  if (words.length === 0) return [""];
  const lines: string[] = [];
  let current = "";
  for (const word of words) {
    const candidate = current ? `${current} ${word}` : word;
    if (font.widthOfTextAtSize(candidate, fontSize) > maxWidth && current) {
      lines.push(current);
      current = word;
    } else {
      current = candidate;
    }
  }
  if (current) lines.push(current);
  return lines;
}

export interface ImagePageInput {
  /** Bytes déjà pivotés côté client (canvas) — toujours orientation finale. */
  bytes: Uint8Array;
  isPng: boolean;
}

export interface ImagesToPdfOptions {
  format: PageFormat | "auto";
  orientation: Orientation;
  margin: number;
}

export async function buildImagesPdf(images: ImagePageInput[], options: ImagesToPdfOptions): Promise<Uint8Array> {
  const doc = await PDFDocument.create();

  for (const img of images) {
    const embedded = img.isPng ? await doc.embedPng(img.bytes) : await doc.embedJpg(img.bytes);
    const naturalWidth = embedded.width;
    const naturalHeight = embedded.height;

    let pageWidth: number;
    let pageHeight: number;
    if (options.format === "auto") {
      pageWidth = naturalWidth + options.margin * 2;
      pageHeight = naturalHeight + options.margin * 2;
    } else {
      [pageWidth, pageHeight] = getPageSize(options.format, options.orientation);
    }

    const page = doc.addPage([pageWidth, pageHeight]);
    const maxW = pageWidth - options.margin * 2;
    const maxH = pageHeight - options.margin * 2;
    const scale = Math.min(maxW / naturalWidth, maxH / naturalHeight, 1);
    const drawWidth = embedded.width * scale;
    const drawHeight = embedded.height * scale;

    const centerX = pageWidth / 2;
    const centerY = pageHeight / 2;

    page.drawImage(embedded, {
      x: centerX - drawWidth / 2,
      y: centerY - drawHeight / 2,
      width: drawWidth,
      height: drawHeight,
    });
  }

  return doc.save();
}
