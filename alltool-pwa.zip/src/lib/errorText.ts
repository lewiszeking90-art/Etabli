// Ajoute un court détail technique après le message d'erreur général.
export function errorWithDetail(base: string, err: unknown): string {
  let detail = "";
  if (err instanceof Error) detail = err.message;
  else if (typeof err === "string") detail = err;
  else if (err && typeof err === "object" && "message" in err) detail = String((err as { message: unknown }).message);
  detail = detail.replace(/\s+/g, " ").trim().slice(0, 160);
  return detail ? `${base} (${detail})` : base;
}
