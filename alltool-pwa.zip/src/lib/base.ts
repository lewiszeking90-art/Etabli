// Préfixe de chemin quand le site est publié dans un sous-dossier (GitHub Pages : "/nom-du-depot").
export const BASE = process.env.NEXT_PUBLIC_BASE_PATH ?? "";

export function withBase(path: string): string {
  return BASE + (path.startsWith("/") ? path : `/${path}`);
}

/** Vérifie rapidement qu'un fichier intégré à l'application est bien présent. */
export async function assetExists(path: string): Promise<boolean> {
  try {
    const res = await fetch(withBase(path), { method: "HEAD" });
    return res.ok;
  } catch {
    return false;
  }
}
