"use client";

import { useEffect, useState } from "react";
import { useLocale } from "@/i18n/LocaleProvider";
import { nativeText, type SavedDetail } from "@/lib/native";

/** Fenêtre « Terminé » affichée après chaque enregistrement de fichier. */
export function SaveNotice() {
  const { locale } = useLocale();
  const [detail, setDetail] = useState<SavedDetail | null>(null);

  useEffect(() => {
    const onSaved = (e: Event) => setDetail((e as CustomEvent<SavedDetail>).detail);
    window.addEventListener("alltool:saved", onSaved);
    return () => window.removeEventListener("alltool:saved", onSaved);
  }, []);

  if (!detail) return null;
  const tx = nativeText(locale);
  const failed = Boolean(detail.error);

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 p-4" onClick={() => setDetail(null)}>
      <div
        className="w-full max-w-sm rounded-2xl bg-white p-5 shadow-2xl dark:bg-[#141a29]"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
      >
        <p className={`text-base font-bold ${failed ? "text-rose-600" : "text-emerald-600 dark:text-emerald-400"}`}>
          {failed ? tx.failed : `✓ ${detail.where ? tx.doneTitle : tx.started.replace(":", "")}`}
        </p>
        <p className="mt-2 break-all text-sm text-slate-700 dark:text-slate-200">{detail.name}</p>
        {detail.where && <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">{tx.savedIn} {detail.where}</p>}
        {failed && <p className="mt-1 break-words text-xs text-slate-500">{detail.error}</p>}
        <button
          onClick={() => setDetail(null)}
          className="mt-4 w-full rounded-xl bg-indigo-600 py-2.5 text-sm font-semibold text-white"
        >
          {tx.ok}
        </button>
      </div>
    </div>
  );
}
