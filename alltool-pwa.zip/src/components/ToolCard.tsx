"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Icon } from "./Icon";
import { useLocale } from "@/i18n/LocaleProvider";
import type { ToolDef } from "@/lib/tools";
import { toggleFavorite } from "@/lib/useHistory";

const BADGE_LABELS: Record<string, "common.localBadge" | "common.internetBadge" | "common.apiKeyBadge"> = {
  local: "common.localBadge",
  internet: "common.internetBadge",
  apikey: "common.apiKeyBadge",
};

const BADGE_STYLES: Record<string, string> = {
  local: "bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300",
  internet: "bg-sky-50 text-sky-700 dark:bg-sky-500/10 dark:text-sky-300",
  apikey: "bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300",
};

export function ToolCard({
  tool,
  favoriteIds,
  onFavoriteChange,
}: {
  tool: ToolDef;
  favoriteIds: Set<string>;
  onFavoriteChange?: () => void;
}) {
  const { t } = useLocale();
  const [isFav, setIsFav] = useState(favoriteIds.has(tool.id));

  useEffect(() => setIsFav(favoriteIds.has(tool.id)), [favoriteIds, tool.id]);

  return (
    <div className="group relative flex flex-col gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md dark:border-slate-800 dark:bg-[#121826]">
      <button
        aria-label={isFav ? t("common.removeFavorite") : t("common.addFavorite")}
        onClick={async (e) => {
          e.preventDefault();
          const next = !isFav;
          setIsFav(next);
          await toggleFavorite(tool.id, isFav);
          onFavoriteChange?.();
        }}
        className="absolute right-3 top-3 text-slate-300 transition hover:text-amber-400"
      >
        <Icon name="Star" size={18} className={isFav ? "fill-amber-400 text-amber-400" : ""} />
      </button>
      <Link href={tool.href} className="flex flex-1 flex-col gap-3">
        <span className="grid h-11 w-11 place-items-center rounded-xl bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-300">
          <Icon name={tool.icon} size={22} />
        </span>
        <div>
          <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">{t(tool.nameKey)}</h3>
          <p className="mt-1 text-xs leading-relaxed text-slate-500 dark:text-slate-400">{t(tool.descKey)}</p>
        </div>
        <div className="mt-auto flex flex-wrap gap-1.5 pt-1">
          {tool.badges.map((badge) => (
            <span
              key={badge}
              className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${BADGE_STYLES[badge]}`}
            >
              {t(BADGE_LABELS[badge])}
            </span>
          ))}
        </div>
      </Link>
    </div>
  );
}
