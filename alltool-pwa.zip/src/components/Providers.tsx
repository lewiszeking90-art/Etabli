"use client";

import type { ReactNode } from "react";
import { ThemeProvider } from "./ThemeProvider";
import { LocaleProvider } from "@/i18n/LocaleProvider";
import { PwaRegister } from "./PwaRegister";

export function Providers({ children }: { children: ReactNode }) {
  return (
    <ThemeProvider>
      <LocaleProvider>
        {children}
        <PwaRegister />
      </LocaleProvider>
    </ThemeProvider>
  );
}
