"use client";

import { Logo } from "./Logo";
import Link from "next/link";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useState, type ReactNode, type FormEvent } from "react";
import { useLocale } from "@/i18n/LocaleProvider";
import { useTheme } from "./ThemeProvider";
import { Icon } from "./Icon";
import { LOCALES, type LocaleCode } from "@/i18n/locales";

const NAV_ITEMS: { href: string; key: "nav.home" | "nav.browser" | "nav.favorites" | "nav.history" | "nav.queue" | "nav.settings"; icon: string }[] = [
  { href: "/", key: "nav.home", icon: "Home" },
  { href: "/browser", key: "nav.browser", icon: "Compass" },
  { href: "/favorites", key: "nav.favorites", icon: "Star" },
  { href: "/history", key: "nav.history", icon: "History" },
  { href: "/queue", key: "nav.queue", icon: "ListChecks" },
  { href: "/settings", key: "nav.settings", icon: "Settings" },
];

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const { t, locale, setLocale } = useLocale();
  const { resolvedTheme, setTheme } = useTheme();
  const router = useRouter();
  const searchParams = useSearchParams();
  const [query, setQuery] = useState(searchParams?.get("q") ?? "");
  const [langOpen, setLangOpen] = useState(false);

  function handleSearch(e: FormEvent) {
    e.preventDefault();
    const params = new URLSearchParams();
    if (query.trim()) params.set("q", query.trim());
    router.push(`/?${params.toString()}`);
  }

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-900 dark:bg-[#0b0f17] dark:text-slate-100">
      {/* Sidebar (desktop) */}
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r border-slate-200 bg-white px-4 py-6 md:flex dark:border-slate-800 dark:bg-[#0f1420]">
        <Link href="/" className="mb-8 flex items-center gap-2 px-2">
          <Logo size={36} />
          <div>
            <p className="text-base font-semibold leading-tight">{t("app.name")}</p>
            <p className="text-[11px] leading-tight text-slate-500 dark:text-slate-400">{t("app.tagline")}</p>
          </div>
        </Link>
        <nav className="flex flex-col gap-1">
          {NAV_ITEMS.map((item) => {
            const active = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors ${
                  active
                    ? "bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300"
                    : "text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800/60"
                }`}
              >
                <Icon name={item.icon} size={18} />
                {t(item.key)}
              </Link>
            );
          })}
        </nav>
        <div className="mt-auto px-2 text-[11px] text-slate-400 dark:text-slate-500">
          <Link href="/privacy" className="hover:underline">
            {t("nav.privacy")}
          </Link>
        </div>
      </aside>

      <div className="flex min-h-screen flex-1 flex-col">
        {/* Top bar */}
        <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-slate-200 bg-white/80 px-4 py-3 backdrop-blur md:px-6 dark:border-slate-800 dark:bg-[#0f1420]/80">
          <Link href="/" className="flex items-center gap-2 md:hidden">
            <Logo size={32} />
          </Link>
          <form onSubmit={handleSearch} className="relative flex-1">
            <Icon
              name="Search"
              size={16}
              className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t("common.searchPlaceholder")}
              className="w-full rounded-full border border-slate-200 bg-slate-50 py-2 pl-9 pr-3 text-sm outline-none ring-indigo-500/30 transition focus:ring-2 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
            />
          </form>

          <div className="relative">
            <button
              onClick={() => setLangOpen((v) => !v)}
              className="flex items-center gap-1 rounded-full border border-slate-200 px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
            >
              {locale.toUpperCase()}
              <Icon name="ChevronDown" size={14} />
            </button>
            {langOpen && (
              <div className="absolute right-0 z-30 mt-2 max-h-72 w-48 overflow-auto rounded-xl border border-slate-200 bg-white p-1 shadow-xl dark:border-slate-700 dark:bg-slate-900">
                {LOCALES.map((l) => (
                  <button
                    key={l.code}
                    onClick={() => {
                      setLocale(l.code as LocaleCode);
                      setLangOpen(false);
                    }}
                    className={`block w-full rounded-lg px-3 py-2 text-left text-sm hover:bg-slate-100 dark:hover:bg-slate-800 ${
                      locale === l.code ? "font-semibold text-indigo-600 dark:text-indigo-300" : ""
                    }`}
                  >
                    {l.nativeName}
                  </button>
                ))}
              </div>
            )}
          </div>

          <button
            onClick={() => setTheme(resolvedTheme === "dark" ? "light" : "dark")}
            aria-label={t("common.theme")}
            className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-slate-200 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
          >
            <Icon name={resolvedTheme === "dark" ? "Sun" : "Moon"} size={16} />
          </button>
        </header>

        <main className="flex-1 pb-20 md:pb-8">{children}</main>

        {/* Bottom nav (mobile) */}
        <nav className="fixed inset-x-0 bottom-0 z-20 grid grid-cols-5 border-t border-slate-200 bg-white/95 backdrop-blur md:hidden dark:border-slate-800 dark:bg-[#0f1420]/95">
          {NAV_ITEMS.map((item) => {
            const active = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`flex flex-col items-center gap-0.5 py-2 text-[10px] font-medium ${
                  active ? "text-indigo-600 dark:text-indigo-300" : "text-slate-500 dark:text-slate-400"
                }`}
              >
                <Icon name={item.icon} size={18} />
                {t(item.key)}
              </Link>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
