"use client";

import { useRef, useState, type DragEvent } from "react";
import { Icon } from "@/components/Icon";
import { useLocale } from "@/i18n/LocaleProvider";

export function FileDrop({
  accept,
  multiple,
  onFiles,
  hint,
}: {
  accept?: string;
  multiple?: boolean;
  onFiles: (files: File[]) => void;
  hint?: string;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);
  const [picked, setPicked] = useState<string[]>([]);
  const remember = (files: File[]) => setPicked(files.map((f) => `${f.name} (${f.size >= 1048576 ? (f.size / 1048576).toFixed(1) + " Mo" : Math.max(1, Math.round(f.size / 1024)) + " Ko"})`));
  const { t } = useLocale();

  function handleDrop(e: DragEvent<HTMLDivElement>) {
    e.preventDefault();
    setDragOver(false);
    const files = Array.from(e.dataTransfer.files ?? []);
    if (files.length) { remember(files); onFiles(files); }
  }

  return (
    <div
      onClick={() => inputRef.current?.click()}
      onDragOver={(e) => {
        e.preventDefault();
        setDragOver(true);
      }}
      onDragLeave={() => setDragOver(false)}
      onDrop={handleDrop}
      className={`flex cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed p-8 text-center transition ${
        dragOver
          ? "border-indigo-500 bg-indigo-50 dark:bg-indigo-500/10"
          : "border-slate-300 bg-slate-50 hover:border-indigo-400 dark:border-slate-700 dark:bg-slate-900"
      }`}
    >
      <Icon name="UploadCloud" size={28} className="text-indigo-500" />
      <p className="text-sm font-medium">{multiple ? t("common.selectFiles") : t("common.selectFile")}</p>
      {picked.length === 0 && hint && <p className="text-xs text-slate-500 dark:text-slate-400">{hint}</p>}
      {picked.length > 0 && (
        <p className="max-w-full break-words text-xs font-semibold text-emerald-600 dark:text-emerald-400">
          ✓ {picked.length > 3 ? `${picked.length} fichiers` : picked.join(" · ")}
        </p>
      )}
      <input
        ref={inputRef}
        type="file"
        accept={accept}
        multiple={multiple}
        className="hidden"
        onChange={(e) => {
          const files = Array.from(e.target.files ?? []);
          if (files.length) { remember(files); onFiles(files); }
          e.target.value = "";
        }}
      />
    </div>
  );
}
