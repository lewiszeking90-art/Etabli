"use client";

import { useEffect, type ReactNode } from "react";
import { useLocale } from "@/i18n/LocaleProvider";
import { recordToolUsage } from "@/lib/useHistory";
import { Icon } from "@/components/Icon";
import type { TranslationKey } from "@/i18n/dictionary";
import type { ToolBadge } from "@/lib/tools";

const BADGE_LABELS: Record<ToolBadge, TranslationKey> = {
  local: "common.localBadge",
  internet: "common.internetBadge",
  apikey: "common.apiKeyBadge",
};

const BADGE_STYLES: Record<ToolBadge, string> = {
  local: "bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300",
  internet: "bg-sky-50 text-sky-700 dark:bg-sky-500/10 dark:text-sky-300",
  apikey: "bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300",
};

export function ToolShell({
  toolId,
  icon,
  titleKey,
  descKey,
  badges = [],
  children,
}: {
  toolId: string;
  icon: string;
  titleKey: TranslationKey;
  descKey: TranslationKey;
  badges?: ToolBadge[];
  note?: ReactNode;
  children: ReactNode;
}) {
  const { t } = useLocale();

  useEffect(() => {
    recordToolUsage(toolId, t(titleKey));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [toolId]);

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 md:px-6">
      <div className="flex items-start gap-3">
        <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-300">
          <Icon name={icon} size={24} />
        </span>
        <div>
          <h1 className="text-xl font-bold md:text-2xl">{t(titleKey)}</h1>
          <p className="mt-1 text-sm text-slate-500 dark:text-slate-400">{t(descKey)}</p>
          <div className="mt-2 flex flex-wrap gap-1.5">
            {badges.map((badge) => (
              <span key={badge} className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${BADGE_STYLES[badge]}`}>
                {t(BADGE_LABELS[badge])}
              </span>
            ))}
          </div>
        </div>
      </div>


      <div className="mt-6">{children}</div>
    </div>
  );
}
