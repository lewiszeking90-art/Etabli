"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useLocale } from "@/i18n/LocaleProvider";
import { withBase } from "@/lib/base";
import { Logo } from "./Logo";

interface PackFile { path: string; size: number; group: string }
interface PrecacheManifest { version: string; shell: { path: string; size: number }[]; pack: PackFile[] }
interface InstallEvent extends Event { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> }

const PACK_CACHE = "alltool-pack-v1";
const ASKED_KEY = "alltool.packAsked";
const formatMb = (bytes: number) => `${Math.max(1, Math.round(bytes / 1048576))} Mo`;

export function PwaRegister() {
  const { t } = useLocale();
  const [installEvent, setInstallEvent] = useState<InstallEvent | null>(null);
  const [manifest, setManifest] = useState<PrecacheManifest | null>(null);
  const [state, setState] = useState<"idle" | "ask" | "running" | "done" | "error">("idle");
  const [pct, setPct] = useState(0);
  const cancelled = useRef(false);

  // 1) Service worker + bouton « Installer »
  useEffect(() => {
    if ("serviceWorker" in navigator && (window.location.protocol === "https:" || window.location.hostname === "localhost")) {
      navigator.serviceWorker.register(withBase("/sw.js"), { scope: withBase("/") }).catch(() => null);
    }
    const onPrompt = (e: Event) => { e.preventDefault(); setInstallEvent(e as InstallEvent); };
    window.addEventListener("beforeinstallprompt", onPrompt);
    return () => window.removeEventListener("beforeinstallprompt", onPrompt);
  }, []);

  // 2) Les outils intégrés sont-ils déjà dans l'appareil ?
  const refreshState = useCallback(async () => {
    try {
      const res = await fetch(withBase("/precache.json"), { cache: "no-store" });
      if (!res.ok) return;
      const m = (await res.json()) as PrecacheManifest;
      setManifest(m);
      if (m.pack.length === 0) return;
      const cache = await caches.open(PACK_CACHE);
      const missing: PackFile[] = [];
      for (const f of m.pack) if (!(await cache.match(withBase("/" + f.path)))) missing.push(f);
      if (missing.length === 0) { setState("done"); return; }
      setState(window.localStorage.getItem(ASKED_KEY) === "later" ? "idle" : "ask");
    } catch {
      // hors ligne ou en développement : rien à faire
    }
  }, []);

  useEffect(() => { void refreshState(); }, [refreshState]);

  const startDownload = useCallback(async () => {
    if (!manifest) return;
    cancelled.current = false;
    setState("running");
    try {
      const cache = await caches.open(PACK_CACHE);
      const todo: PackFile[] = [];
      for (const f of manifest.pack) if (!(await cache.match(withBase("/" + f.path)))) todo.push(f);
      const total = todo.reduce((s, f) => s + f.size, 0) || 1;
      let done = 0;
      let index = 0;
      const worker = async () => {
        while (index < todo.length && !cancelled.current) {
          const f = todo[index++];
          const res = await fetch(withBase("/" + f.path), { cache: "reload" });
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          await cache.put(withBase("/" + f.path), res);
          done += f.size;
          setPct(Math.min(100, Math.round((done / total) * 100)));
        }
      };
      await Promise.all([worker(), worker(), worker()]);
      if (cancelled.current) { setState("idle"); return; }
      try { await navigator.storage?.persist?.(); } catch { /* facultatif */ }
      window.localStorage.removeItem(ASKED_KEY);
      setState("done");
      setTimeout(() => setState("idle"), 6000);
    } catch {
      setState("error");
    }
  }, [manifest]);

  const later = () => { window.localStorage.setItem(ASKED_KEY, "later"); cancelled.current = true; setState("idle"); };
  const packSize = manifest ? manifest.pack.reduce((s, f) => s + f.size, 0) : 0;

  if (state === "idle" && !installEvent) return null;

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-20 z-50 flex justify-center px-3 md:bottom-4">
      <div className="pointer-events-auto w-full max-w-md space-y-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-xl dark:border-slate-700 dark:bg-[#141a29]">
        {(state === "ask" || state === "running" || state === "error" || state === "done") && (
          <div className="flex gap-3">
            <Logo size={40} />
            <div className="min-w-0 flex-1 text-sm">
              {state === "done" ? (
                <p className="font-medium text-emerald-600 dark:text-emerald-400">{t("x.pack.done")}</p>
              ) : (
                <>
                  <p className="font-semibold">{t("x.pack.title")}</p>
                  <p className="mt-1 text-slate-600 dark:text-slate-300">
                    {state === "error" ? t("x.pack.error") : t("x.pack.text").replace("{size}", formatMb(packSize))}
                  </p>
                </>
              )}
              {state === "running" && (
                <div className="mt-3">
                  <div className="h-2 overflow-hidden rounded-full bg-slate-200 dark:bg-slate-700">
                    <div className="h-full rounded-full bg-indigo-600 transition-all" style={{ width: `${pct}%` }} />
                  </div>
                  <p className="mt-1 text-xs text-slate-500">{t("x.pack.progress").replace("{pct}", String(pct))}</p>
                </div>
              )}
              {(state === "ask" || state === "error") && (
                <div className="mt-3 flex gap-2">
                  <button onClick={() => void startDownload()} className="rounded-lg bg-indigo-600 px-3 py-2 text-xs font-semibold text-white">
                    {state === "error" ? t("x.pack.retry") : t("x.pack.start")}
                  </button>
                  <button onClick={later} className="rounded-lg border border-slate-300 px-3 py-2 text-xs dark:border-slate-600">
                    {t("x.pack.later")}
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
        {installEvent && state !== "running" && (
          <button
            onClick={async () => { await installEvent.prompt(); setInstallEvent(null); }}
            className="w-full rounded-lg bg-slate-900 px-3 py-2 text-xs font-semibold text-white dark:bg-white dark:text-slate-900"
          >
            {t("x.install.button")}
          </button>
        )}
      </div>
    </div>
  );
}
