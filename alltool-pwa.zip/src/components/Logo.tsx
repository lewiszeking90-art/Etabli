import { useId } from "react";

/** Logo AllTool : carré indigo → violet avec quatre tuiles blanches. */
export function Logo({ size = 36, className }: { size?: number; className?: string }) {
  const id = useId().replace(/:/g, "");
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 512 512"
      role="img"
      aria-label="AllTool"
      className={className}
    >
      <defs>
        <linearGradient id={`g${id}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#5b6cf6" />
          <stop offset="0.5" stopColor="#4338ca" />
          <stop offset="1" stopColor="#8b5cf6" />
        </linearGradient>
      </defs>
      <rect width="512" height="512" rx="112" fill={`url(#g${id})`} />
      <g fill="#fff">
        <rect x="76" y="76" width="168" height="168" rx="40" />
        <rect x="268" y="76" width="168" height="168" rx="40" />
        <rect x="76" y="268" width="168" height="168" rx="40" />
        <path
          d="M308 268h88a40 40 0 0 1 40 40v64l-84 62-84-62v-64a40 40 0 0 1 40-40z"
          stroke="#fff"
          strokeWidth="10"
          strokeLinejoin="round"
        />
      </g>
    </svg>
  );
}
