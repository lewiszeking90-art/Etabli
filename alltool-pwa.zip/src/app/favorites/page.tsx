"use client";

import { useEffect, useMemo, useState } from "react";
import { useLocale } from "@/i18n/LocaleProvider";
import { TOOLS } from "@/lib/tools";
import { ToolCard } from "@/components/ToolCard";
import { useFavoriteIds } from "@/lib/useHistory";

export default function FavoritesPage() {
  const { t } = useLocale();
  const ids = useFavoriteIds();
  const favoriteIds = useMemo(() => new Set(ids), [ids]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => setLoaded(true), []);

  const tools = TOOLS.filter((tool) => favoriteIds.has(tool.id));

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 md:px-6">
      <h1 className="text-2xl font-bold">{t("favorites.title")}</h1>
      {loaded && tools.length === 0 && (
        <p className="mt-6 rounded-2xl border border-dashed border-slate-300 p-6 text-sm text-slate-500 dark:border-slate-700 dark:text-slate-400">
          {t("favorites.empty")}
        </p>
      )}
      <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {tools.map((tool) => (
          <ToolCard key={tool.id} tool={tool} favoriteIds={favoriteIds} />
        ))}
      </div>
    </div>
  );
}
