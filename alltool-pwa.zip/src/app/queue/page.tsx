"use client";

import { useLocale } from "@/i18n/LocaleProvider";
import { useQueue, queueStore } from "@/lib/queueStore";
import { Icon } from "@/components/Icon";

const STATUS_STYLES: Record<string, string> = {
  pending: "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300",
  running: "bg-sky-50 text-sky-700 dark:bg-sky-500/10 dark:text-sky-300",
  done: "bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300",
  error: "bg-red-50 text-red-700 dark:bg-red-500/10 dark:text-red-300",
  canceled: "bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300",
};

export default function QueuePage() {
  const { t } = useLocale();
  const tasks = useQueue();

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 md:px-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">{t("queue.title")}</h1>
        {tasks.length > 0 && (
          <button
            onClick={() => queueStore.clearFinished()}
            className="flex items-center gap-1.5 rounded-full border border-slate-200 px-3 py-1.5 text-xs font-medium hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800"
          >
            <Icon name="Trash2" size={14} />
            {t("queue.clear")}
          </button>
        )}
      </div>

      {tasks.length === 0 && (
        <p className="mt-6 rounded-2xl border border-dashed border-slate-300 p-6 text-sm text-slate-500 dark:border-slate-700 dark:text-slate-400">
          {t("queue.empty")}
        </p>
      )}

      <div className="mt-6 flex flex-col gap-3">
        {tasks.map((task) => (
          <div
            key={task.id}
            className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-[#121826]"
          >
            <div className="flex items-center justify-between">
              <p className="text-sm font-semibold">{task.label}</p>
              <span className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${STATUS_STYLES[task.status]}`}>
                {task.status}
              </span>
            </div>
            <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-slate-800">
              <div
                className="h-full rounded-full bg-indigo-500 transition-all"
                style={{ width: `${task.progress}%` }}
              />
            </div>
            <div className="mt-2 flex items-center justify-between">
              <p className="text-xs text-slate-500 dark:text-slate-400">{task.message ?? `${task.progress}%`}</p>
              {(task.status === "pending" || task.status === "running") && task.onCancel && (
                <button
                  onClick={() => queueStore.cancel(task.id)}
                  className="text-xs font-medium text-red-600 hover:underline dark:text-red-400"
                >
                  {t("common.cancel")}
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
