import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Suspense } from "react";
import "./globals.css";
import { Providers } from "@/components/Providers";
import { AppShell } from "@/components/AppShell";
import { withBase } from "@/lib/base";

export const metadata: Metadata = {
  title: "AllTool — Boîte à outils tout-en-un",
  description:
    "AllTool regroupe navigateur, outils vidéo, audio, image, PDF et texte dans une seule application rapide, sécurisée et respectueuse de la vie privée.",
  applicationName: "AllTool",
  manifest: withBase("/manifest.webmanifest"),
  icons: {
    icon: [
      { url: withBase("/icons/icon.svg"), type: "image/svg+xml" },
      { url: withBase("/icons/favicon-32.png"), sizes: "32x32", type: "image/png" },
      { url: withBase("/icons/favicon-48.png"), sizes: "48x48", type: "image/png" },
    ],
    apple: [{ url: withBase("/icons/apple-touch-icon.png"), sizes: "180x180" }],
  },
  appleWebApp: { capable: true, title: "AllTool", statusBarStyle: "black-translucent" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#4f46e5",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fr" suppressHydrationWarning>
      <body className="antialiased">
        <Providers>
          <Suspense fallback={null}>
            <AppShell>{children}</AppShell>
          </Suspense>
        </Providers>
      </body>
    </html>
  );
}
