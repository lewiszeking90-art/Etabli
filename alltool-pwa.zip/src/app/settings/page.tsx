"use client";

import Link from "next/link";
import { useLocale } from "@/i18n/LocaleProvider";
import { LOCALES, type LocaleCode } from "@/i18n/locales";
import { useTheme } from "@/components/ThemeProvider";
import { Icon } from "@/components/Icon";
import { clearFavorites, clearHistory } from "@/lib/useHistory";

export default function SettingsPage() {
  const { t, locale, setLocale } = useLocale();
  const { theme, setTheme } = useTheme();

  return (
    <div className="mx-auto max-w-3xl px-4 py-8 md:px-6">
      <h1 className="text-2xl font-bold">{t("settings.title")}</h1>

      <section className="mt-6 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#121826]">
        <h2 className="text-sm font-semibold text-slate-500 dark:text-slate-400">{t("settings.appearance")}</h2>
        <div className="mt-3 flex gap-2">
          {(["light", "dark", "system"] as const).map((opt) => (
            <button
              key={opt}
              onClick={() => setTheme(opt)}
              className={`flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition ${
                theme === opt
                  ? "border-indigo-500 bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300"
                  : "border-slate-200 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
              }`}
            >
              <Icon name={opt === "light" ? "Sun" : opt === "dark" ? "Moon" : "Monitor"} size={14} />
              {t(opt === "light" ? "common.themeLight" : opt === "dark" ? "common.themeDark" : "common.themeSystem")}
            </button>
          ))}
        </div>
      </section>

      <section className="mt-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#121826]">
        <h2 className="text-sm font-semibold text-slate-500 dark:text-slate-400">{t("settings.language")}</h2>
        <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
          {LOCALES.map((l) => (
            <button
              key={l.code}
              onClick={() => setLocale(l.code as LocaleCode)}
              className={`rounded-xl border px-3 py-2 text-left text-sm font-medium transition ${
                locale === l.code
                  ? "border-indigo-500 bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300"
                  : "border-slate-200 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
              }`}
            >
              {l.nativeName}
            </button>
          ))}
        </div>
      </section>

      <section className="mt-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#121826]">
        <h2 className="text-sm font-semibold text-slate-500 dark:text-slate-400">{t("settings.dataPrivacy")}</h2>
        <div className="mt-3 flex flex-wrap gap-2">
          <button
            onClick={() => clearHistory()}
            className="rounded-full border border-slate-200 px-3 py-1.5 text-xs font-medium hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800"
          >
            {t("settings.clearHistory")}
          </button>
          <button
            onClick={() => clearFavorites()}
            className="rounded-full border border-slate-200 px-3 py-1.5 text-xs font-medium hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800"
          >
            {t("settings.clearFavorites")}
          </button>
        </div>
        <Link href="/privacy" className="mt-3 inline-block text-xs font-medium text-indigo-600 hover:underline dark:text-indigo-300">
          {t("settings.privacyPolicyLink")}
        </Link>
      </section>

      <section className="mt-4 rounded-2xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-[#121826]">
        <h2 className="text-sm font-semibold text-slate-500 dark:text-slate-400">{t("settings.about")}</h2>
        <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">AllTool — {t("settings.version")} 1.0.0</p>
      </section>
    </div>
  );
}
