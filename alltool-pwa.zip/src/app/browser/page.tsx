"use client";

import { useEffect, useState, type FormEvent } from "react";
import Link from "next/link";
import { useLocale } from "@/i18n/LocaleProvider";
import { ToolShell } from "@/components/tool/ToolShell";
import { Icon } from "@/components/Icon";
import { isSafePublicUrl } from "@/lib/urlSafety";
import { isNativeApp, nativeText, openVideoBrowser } from "@/lib/native";

interface Bookmark { label: string; url: string }
const BOOKMARKS_KEY = "alltool.browserBookmarks";
const START: Bookmark[] = [
  { label: "Wikipédia", url: "https://fr.wikipedia.org/" },
  { label: "OpenStreetMap", url: "https://www.openstreetmap.org/" },
];

function toUrl(raw: string): string | null {
  const text = raw.trim();
  if (!text || /\s/.test(text)) return null;
  const candidate = /^https?:\/\//i.test(text) ? text : `https://${text}`;
  const check = isSafePublicUrl(candidate);
  return check.ok && check.url && check.url.hostname.includes(".") ? check.url.toString() : null;
}

export default function BrowserPage() {
  const { t, locale } = useLocale();
  const [native, setNative] = useState(false);
  useEffect(() => { setNative(isNativeApp()); }, []);
  const [input, setInput] = useState("");
  const [current, setCurrent] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [marks, setMarks] = useState<Bookmark[]>([]);

  useEffect(() => {
    try {
      const saved = JSON.parse(window.localStorage.getItem(BOOKMARKS_KEY) ?? "[]") as Bookmark[];
      setMarks(Array.isArray(saved) ? saved.slice(0, 12) : []);
    } catch {
      setMarks([]);
    }
  }, []);

  function open(raw: string) {
    const url = toUrl(raw);
    if (!url) {
      // Pas une adresse : recherche dans un onglet (les moteurs de recherche refusent l'affichage intégré).
      if (raw.trim() && /\s|^[^.]+$/.test(raw.trim())) {
        if (isNativeApp()) { void openVideoBrowser(`https://duckduckgo.com/?q=${encodeURIComponent(raw.trim())}`).catch(() => null); return; }
        window.open(`https://duckduckgo.com/?q=${encodeURIComponent(raw.trim())}`, "_blank", "noopener");
        return;
      }
      setError(t("x.browser.invalid"));
      return;
    }
    setError(null);
    setInput(url);
    if (isNativeApp()) { void openVideoBrowser(url).catch(() => setError(t("x.browser.invalid"))); return; }
    setCurrent(url);
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    open(input);
  }

  function addBookmark() {
    if (!current) return;
    let label = current;
    try { label = new URL(current).hostname.replace(/^www\./, ""); } catch { /* garde l'adresse */ }
    const next = [{ label, url: current }, ...marks.filter((m) => m.url !== current)].slice(0, 12);
    setMarks(next);
    try { window.localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(next)); } catch { /* ignoré */ }
  }

  const chip = "rounded-full border border-slate-200 px-3 py-1.5 text-xs hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800";

  return (
    <ToolShell
      toolId="browser"
      icon="Compass"
      titleKey="tool.browser.name"
      descKey="tool.browser.desc"
      badges={["internet"]}
      note={<span>{native ? nativeText(locale).browserNote : t("x.browser.blocked")}</span>}
    >
      <form onSubmit={onSubmit} className="flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          inputMode="url"
          autoCapitalize="none"
          placeholder={t("x.browser.placeholder")}
          className="min-w-0 flex-1 rounded-xl border border-slate-200 bg-white p-3 text-sm dark:border-slate-700 dark:bg-slate-900"
        />
        <button type="submit" className="rounded-xl bg-indigo-600 px-4 text-sm font-semibold text-white hover:bg-indigo-700">
          {t("x.browser.go")}
        </button>
      </form>
      {error && <p className="mt-2 text-sm text-amber-700 dark:text-amber-300">{error}</p>}

      <div className="mt-3 flex flex-wrap gap-2">
        {[...START, ...marks].map((b) => (
          <button key={b.url} onClick={() => open(b.url)} className={chip}>{b.label}</button>
        ))}
      </div>

      {current && (
        <div className="mt-3 flex flex-wrap gap-2">
          <button onClick={addBookmark} className={`${chip} flex items-center gap-1`}>
            <Icon name="Star" size={12} /> {t("x.browser.bookmark")}
          </button>
          <a href={current} target="_blank" rel="noopener noreferrer" className={`${chip} flex items-center gap-1`}>
            <Icon name="ExternalLink" size={12} /> {t("x.browser.openTab")}
          </a>
          <Link href={`/outils/video/telecharger/?url=${encodeURIComponent(current)}`} className={`${chip} flex items-center gap-1`}>
            <Icon name="Download" size={12} /> {t("x.browser.download")}
          </Link>
        </div>
      )}

      {current && (
        <iframe
          key={current}
          src={current}
          title={current}
          referrerPolicy="no-referrer"
          sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox"
          className="mt-3 h-[60vh] w-full rounded-xl border border-slate-200 bg-white dark:border-slate-700"
        />
      )}
    </ToolShell>
  );
}
