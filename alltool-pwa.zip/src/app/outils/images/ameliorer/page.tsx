"use client";

import { useState } from "react";
import { useLocale } from "@/i18n/LocaleProvider";
import { ToolShell } from "@/components/tool/ToolShell";
import { FileDrop } from "@/components/tool/FileDrop";
import { Icon } from "@/components/Icon";
import { canvasToBlob, downloadBlob, loadImageFromFile } from "@/lib/imageUtils";
import { DEFAULT_ENHANCE, enhanceCanvas, type EnhanceOptions } from "@/lib/enhance";

const MAX_SIDE = 3000; // image de départ limitée pour rester fluide sur téléphone
const MAX_OUTPUT = 6000;

export default function ImageEnhancePage() {
  const { t } = useLocale();
  const [file, setFile] = useState<File | null>(null);
  const [sourceUrl, setSourceUrl] = useState<string | null>(null);
  const [resultUrl, setResultUrl] = useState<string | null>(null);
  const [resultBlob, setResultBlob] = useState<Blob | null>(null);
  const [opts, setOpts] = useState<EnhanceOptions>(DEFAULT_ENHANCE);
  const [working, setWorking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [split, setSplit] = useState(50);

  function set<K extends keyof EnhanceOptions>(key: K, value: EnhanceOptions[K]) {
    setOpts((o) => ({ ...o, [key]: value }));
  }

  function onFiles(files: File[]) {
    const f = files[0];
    setFile(f);
    setSourceUrl(URL.createObjectURL(f));
    setResultUrl(null);
    setResultBlob(null);
    setError(null);
  }

  async function run() {
    if (!file) return;
    setWorking(true);
    setError(null);
    try {
      await new Promise((r) => setTimeout(r, 30)); // laisse l'écran se mettre à jour
      const img = await loadImageFromFile(file);
      const k = Math.min(1, MAX_SIDE / Math.max(img.naturalWidth, img.naturalHeight));
      const base = document.createElement("canvas");
      base.width = Math.round(img.naturalWidth * k);
      base.height = Math.round(img.naturalHeight * k);
      base.getContext("2d")?.drawImage(img, 0, 0, base.width, base.height);
      const scale = Math.max(1, Math.min(opts.scale, MAX_OUTPUT / Math.max(base.width, base.height)));
      const out = enhanceCanvas(base, { ...opts, scale });
      const blob = await canvasToBlob(out, "image/jpeg", 0.93);
      setResultBlob(blob);
      setResultUrl(URL.createObjectURL(blob));
      setSplit(50);
    } catch {
      setError(t("common.errorGeneric"));
    } finally {
      setWorking(false);
    }
  }

  const sliders: { key: keyof EnhanceOptions; label: string; min: number; max: number; step?: number }[] = [
    { key: "sharpen", label: t("x.en.sharpen"), min: 0, max: 100 },
    { key: "denoise", label: t("x.en.denoise"), min: 0, max: 100 },
    { key: "contrast", label: t("x.en.contrast"), min: -50, max: 50 },
    { key: "brightness", label: t("x.en.brightness"), min: -50, max: 50 },
    { key: "saturation", label: t("x.en.saturation"), min: -50, max: 50 },
    { key: "scale", label: t("x.en.scale"), min: 1, max: 3, step: 0.5 },
  ];

  return (
    <ToolShell
      toolId="image-enhance"
      icon="Sparkles"
      titleKey="tool.imageEnhance.name"
      descKey="tool.imageEnhance.desc"
      badges={["local"]}
      note={<span>{t("x.en.note")}</span>}
    >
      <FileDrop accept="image/*" onFiles={onFiles} />

      {sourceUrl && (
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          {sliders.map((s) => (
            <label key={s.key} className="text-xs font-medium text-slate-500 dark:text-slate-400">
              {s.label} : {opts[s.key]}
              <input
                type="range"
                min={s.min}
                max={s.max}
                step={s.step ?? 1}
                value={opts[s.key]}
                onChange={(e) => set(s.key, Number(e.target.value))}
                className="mt-1 w-full accent-indigo-600"
              />
            </label>
          ))}
        </div>
      )}

      {error && (
        <p className="mt-3 rounded-xl bg-amber-50 p-3 text-sm text-amber-800 dark:bg-amber-500/10 dark:text-amber-200">{error}</p>
      )}

      <div className="mt-4 flex flex-wrap gap-2">
        <button
          onClick={() => void run()}
          disabled={!file || working}
          className="flex items-center gap-2 rounded-full bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow hover:bg-indigo-700 disabled:opacity-40"
        >
          {working ? <Icon name="Loader2" size={16} className="animate-spin" /> : <Icon name="Sparkles" size={16} />}
          {t("x.en.apply")}
        </button>
        {resultBlob && file && (
          <button
            onClick={() => downloadBlob(resultBlob, file.name.replace(/\.[^.]+$/, "") + "-ameliore.jpg")}
            className="flex items-center gap-2 rounded-full border border-slate-300 px-5 py-2.5 text-sm font-semibold hover:bg-slate-100 dark:border-slate-600 dark:hover:bg-slate-800"
          >
            <Icon name="Download" size={16} /> {t("common.download")}
          </button>
        )}
      </div>

      {sourceUrl && resultUrl && (
        <div className="mt-6">
          <div className="relative mx-auto max-w-2xl select-none overflow-hidden rounded-xl bg-slate-100 dark:bg-slate-800">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={sourceUrl} alt={t("x.en.before")} className="block w-full" />
            <div className="absolute inset-0" style={{ clipPath: `inset(0 0 0 ${split}%)` }}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={resultUrl} alt={t("x.en.after")} className="h-full w-full object-contain" />
            </div>
            <div className="pointer-events-none absolute inset-y-0 w-0.5 bg-white shadow" style={{ left: `${split}%` }} />
            <input
              type="range"
              min={0}
              max={100}
              value={split}
              onChange={(e) => setSplit(Number(e.target.value))}
              aria-label={t("x.en.compare")}
              className="absolute inset-0 h-full w-full cursor-ew-resize opacity-0"
            />
            <span className="absolute left-2 top-2 rounded bg-black/50 px-1.5 py-0.5 text-[10px] text-white">{t("x.en.before")}</span>
            <span className="absolute right-2 top-2 rounded bg-black/50 px-1.5 py-0.5 text-[10px] text-white">{t("x.en.after")}</span>
          </div>
          <p className="mt-2 text-center text-xs text-slate-500">{t("x.en.compare")}</p>
        </div>
      )}
    </ToolShell>
  );
}
