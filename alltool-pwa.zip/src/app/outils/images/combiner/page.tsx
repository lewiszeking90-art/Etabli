"use client";

import { useState } from "react";
import { useLocale } from "@/i18n/LocaleProvider";
import { ToolShell } from "@/components/tool/ToolShell";
import { FileDrop } from "@/components/tool/FileDrop";
import { Icon } from "@/components/Icon";
import { loadImageFromFile, canvasToBlob, shareOrDownload } from "@/lib/imageUtils";
import { combineImagesToCanvas } from "@/lib/combineImages";

interface ImgItem {
  id: string;
  file: File;
  previewUrl: string;
}

export default function CombineImagesPage() {
  const { t } = useLocale();
  const [items, setItems] = useState<ImgItem[]>([]);
  const [direction, setDirection] = useState<"horizontal" | "vertical">("horizontal");
  const [spacing, setSpacing] = useState(12);
  const [background, setBackground] = useState("#ffffff");
  const [format, setFormat] = useState<"png" | "jpeg">("png");
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [resultBlob, setResultBlob] = useState<Blob | null>(null);
  const [working, setWorking] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function addFiles(files: File[]) {
    const next = files
      .filter((f) => f.type.startsWith("image/"))
      .map((file) => ({ id: crypto.randomUUID(), file, previewUrl: URL.createObjectURL(file) }));
    setItems((prev) => [...prev, ...next]);
  }

  function move(id: string, dir: -1 | 1) {
    setItems((prev) => {
      const idx = prev.findIndex((i) => i.id === id);
      const newIdx = idx + dir;
      if (newIdx < 0 || newIdx >= prev.length) return prev;
      const copy = [...prev];
      [copy[idx], copy[newIdx]] = [copy[newIdx], copy[idx]];
      return copy;
    });
  }

  function remove(id: string) {
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  async function generate() {
    if (items.length < 2) {
      setError("Sélectionnez au moins 2 images.");
      return;
    }
    setWorking(true);
    setError(null);
    try {
      const imgs = await Promise.all(items.map((i) => loadImageFromFile(i.file)));
      const canvas = combineImagesToCanvas(imgs, { direction, spacing, background });
      const mime = format === "png" ? "image/png" : "image/jpeg";
      const blob = await canvasToBlob(canvas, mime, format === "jpeg" ? 0.92 : undefined);
      setResultBlob(blob);
      setPreviewUrl(URL.createObjectURL(blob));
    } catch (err) {
      console.error(err);
      setError(t("common.errorGeneric"));
    } finally {
      setWorking(false);
    }
  }

  return (
    <ToolShell toolId="images-combine" icon="GalleryHorizontalEnd" titleKey="tool.imagesCombine.name" descKey="tool.imagesCombine.desc" badges={["local"]}>
      <FileDrop accept="image/*" multiple onFiles={addFiles} hint="JPG, PNG, WEBP" />

      {items.length > 0 && (
        <div className="mt-5 flex flex-wrap gap-3">
          {items.map((item, idx) => (
            <div key={item.id} className="relative w-28 overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-[#121826]">
              <img src={item.previewUrl} alt="" className="h-20 w-full object-cover" />
              <div className="flex items-center justify-between p-1">
                <span className="pl-1 text-[10px] text-slate-400">#{idx + 1}</span>
                <div className="flex">
                  <button onClick={() => move(item.id, -1)} className="rounded p-1 hover:bg-slate-100 dark:hover:bg-slate-800">
                    <Icon name="ArrowLeft" size={12} />
                  </button>
                  <button onClick={() => move(item.id, 1)} className="rounded p-1 hover:bg-slate-100 dark:hover:bg-slate-800">
                    <Icon name="ArrowRight" size={12} />
                  </button>
                  <button onClick={() => remove(item.id)} className="rounded p-1 text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10">
                    <Icon name="X" size={12} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-6 grid grid-cols-1 gap-4 rounded-2xl border border-slate-200 bg-white p-4 sm:grid-cols-2 lg:grid-cols-4 dark:border-slate-800 dark:bg-[#121826]">
        <div>
          <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Direction</label>
          <select value={direction} onChange={(e) => setDirection(e.target.value as "horizontal" | "vertical")} className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-900">
            <option value="horizontal">Horizontale</option>
            <option value="vertical">Verticale</option>
          </select>
        </div>
        <div>
          <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Espacement ({spacing}px)</label>
          <input type="range" min={0} max={80} value={spacing} onChange={(e) => setSpacing(Number(e.target.value))} className="mt-2 w-full" />
        </div>
        <div>
          <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Couleur de fond</label>
          <input type="color" value={background} onChange={(e) => setBackground(e.target.value)} className="mt-1 h-10 w-full rounded-lg border border-slate-200 dark:border-slate-700" />
        </div>
        <div>
          <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Format d&apos;export</label>
          <select value={format} onChange={(e) => setFormat(e.target.value as "png" | "jpeg")} className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-900">
            <option value="png">PNG</option>
            <option value="jpeg">JPEG</option>
          </select>
        </div>
      </div>

      <div className="mt-5 flex flex-wrap items-center gap-3">
        <button onClick={generate} disabled={items.length < 2 || working} className="flex items-center gap-2 rounded-full bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow hover:bg-indigo-700 disabled:opacity-40">
          {working ? <Icon name="Loader2" size={16} className="animate-spin" /> : <Icon name="Combine" size={16} />}
          {t("common.start")}
        </button>
        {resultBlob && (
          <button onClick={() => shareOrDownload(resultBlob, `combinaison.${format}`)} className="flex items-center gap-2 rounded-full border border-indigo-200 px-5 py-2.5 text-sm font-semibold text-indigo-700 hover:bg-indigo-50 dark:border-indigo-500/40 dark:text-indigo-300 dark:hover:bg-indigo-500/10">
            <Icon name="Download" size={16} />
            {t("common.download")}
          </button>
        )}
      </div>
      {error && <p className="mt-3 text-sm text-red-600 dark:text-red-400">{error}</p>}

      {previewUrl && (
        <div className="mt-6">
          <p className="mb-2 text-xs font-medium text-slate-500 dark:text-slate-400">{t("common.preview")}</p>
          <img src={previewUrl} alt="" className="max-h-96 w-auto rounded-xl border border-slate-200 dark:border-slate-800" />
        </div>
      )}
    </ToolShell>
  );
}
