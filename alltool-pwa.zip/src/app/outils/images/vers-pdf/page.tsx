"use client";

import { useState } from "react";
import { useLocale } from "@/i18n/LocaleProvider";
import { ToolShell } from "@/components/tool/ToolShell";
import { FileDrop } from "@/components/tool/FileDrop";
import { Icon } from "@/components/Icon";
import { loadImageFromFile, rotateImageToCanvas, canvasToBlob, blobToBytes, shareOrDownload } from "@/lib/imageUtils";
import { buildImagesPdf, type PageFormat, type Orientation } from "@/lib/pdfBuilder";

interface ImageItem {
  id: string;
  file: File;
  rotation: 0 | 90 | 180 | 270;
  previewUrl: string;
}

export default function ImagesToPdfPage() {
  const { t } = useLocale();
  const [items, setItems] = useState<ImageItem[]>([]);
  const [format, setFormat] = useState<PageFormat | "auto">("a4");
  const [orientation, setOrientation] = useState<Orientation>("portrait");
  const [margin, setMargin] = useState(24);
  const [quality, setQuality] = useState(0.85);
  const [filename, setFilename] = useState("document");
  const [working, setWorking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resultBlob, setResultBlob] = useState<Blob | null>(null);

  function addFiles(files: File[]) {
    const next = files
      .filter((f) => f.type.startsWith("image/"))
      .map((file) => ({ id: crypto.randomUUID(), file, rotation: 0 as const, previewUrl: URL.createObjectURL(file) }));
    setItems((prev) => [...prev, ...next]);
    setResultBlob(null);
  }

  function move(id: string, dir: -1 | 1) {
    setItems((prev) => {
      const idx = prev.findIndex((i) => i.id === id);
      const newIdx = idx + dir;
      if (newIdx < 0 || newIdx >= prev.length) return prev;
      const copy = [...prev];
      [copy[idx], copy[newIdx]] = [copy[newIdx], copy[idx]];
      return copy;
    });
  }

  function rotate(id: string) {
    setItems((prev) =>
      prev.map((i) => (i.id === id ? { ...i, rotation: (((i.rotation + 90) % 360) as 0 | 90 | 180 | 270) } : i)),
    );
  }

  function remove(id: string) {
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  async function generate() {
    if (items.length === 0) return;
    setWorking(true);
    setError(null);
    setResultBlob(null);
    try {
      const prepared = [];
      for (const item of items) {
        const img = await loadImageFromFile(item.file);
        const canvas = rotateImageToCanvas(img, item.rotation);
        const blob = await canvasToBlob(canvas, "image/jpeg", quality);
        const bytes = await blobToBytes(blob);
        prepared.push({ bytes, isPng: false });
      }
      const pdfBytes = await buildImagesPdf(prepared, { format, orientation, margin });
      const blob = new Blob([pdfBytes.slice()], { type: "application/pdf" });
      setResultBlob(blob);
    } catch (err) {
      console.error(err);
      setError(t("common.errorGeneric"));
    } finally {
      setWorking(false);
    }
  }

  return (
    <ToolShell toolId="images-to-pdf" icon="FileImage" titleKey="tool.imagesToPdf.name" descKey="tool.imagesToPdf.desc" badges={["local"]}>
      <FileDrop accept="image/*" multiple onFiles={addFiles} hint="JPG, PNG, WEBP" />

      {items.length > 0 && (
        <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
          {items.map((item, idx) => (
            <div key={item.id} className="group relative overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-[#121826]">
              <img
                src={item.previewUrl}
                alt=""
                style={{ transform: `rotate(${item.rotation}deg)` }}
                className="h-32 w-full object-contain p-2 transition-transform"
              />
              <div className="flex items-center justify-between gap-1 border-t border-slate-100 p-1.5 dark:border-slate-800">
                <span className="pl-1 text-[10px] text-slate-400">#{idx + 1}</span>
                <div className="flex gap-1">
                  <button onClick={() => move(item.id, -1)} className="rounded p-1 hover:bg-slate-100 dark:hover:bg-slate-800">
                    <Icon name="ArrowLeft" size={13} />
                  </button>
                  <button onClick={() => move(item.id, 1)} className="rounded p-1 hover:bg-slate-100 dark:hover:bg-slate-800">
                    <Icon name="ArrowRight" size={13} />
                  </button>
                  <button onClick={() => rotate(item.id)} className="rounded p-1 hover:bg-slate-100 dark:hover:bg-slate-800">
                    <Icon name="RotateCw" size={13} />
                  </button>
                  <button onClick={() => remove(item.id)} className="rounded p-1 text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10">
                    <Icon name="X" size={13} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-6 grid grid-cols-1 gap-4 rounded-2xl border border-slate-200 bg-white p-4 sm:grid-cols-2 dark:border-slate-800 dark:bg-[#121826]">
        <div>
          <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Format de page</label>
          <select
            value={format}
            onChange={(e) => setFormat(e.target.value as PageFormat | "auto")}
            className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-900"
          >
            <option value="a4">A4</option>
            <option value="letter">Letter</option>
            <option value="a5">A5</option>
            <option value="auto">Taille originale (auto)</option>
          </select>
        </div>
        <div>
          <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Orientation</label>
          <select
            value={orientation}
            disabled={format === "auto"}
            onChange={(e) => setOrientation(e.target.value as Orientation)}
            className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm disabled:opacity-40 dark:border-slate-700 dark:bg-slate-900"
          >
            <option value="portrait">Portrait</option>
            <option value="landscape">Paysage</option>
          </select>
        </div>
        <div>
          <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Marges ({margin}pt)</label>
          <input type="range" min={0} max={60} value={margin} onChange={(e) => setMargin(Number(e.target.value))} className="mt-2 w-full" />
        </div>
        <div>
          <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Qualité image ({Math.round(quality * 100)}%)</label>
          <input type="range" min={0.3} max={1} step={0.05} value={quality} onChange={(e) => setQuality(Number(e.target.value))} className="mt-2 w-full" />
        </div>
        <div className="sm:col-span-2">
          <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Nom du fichier</label>
          <input
            value={filename}
            onChange={(e) => setFilename(e.target.value)}
            className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-900"
          />
        </div>
      </div>

      <div className="mt-5 flex flex-wrap items-center gap-3">
        <button
          onClick={generate}
          disabled={items.length === 0 || working}
          className="flex items-center gap-2 rounded-full bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow hover:bg-indigo-700 disabled:opacity-40"
        >
          {working ? <Icon name="Loader2" size={16} className="animate-spin" /> : <Icon name="FileOutput" size={16} />}
          {t("common.start")}
        </button>
        {resultBlob && (
          <button
            onClick={() => shareOrDownload(resultBlob, `${filename || "document"}.pdf`)}
            className="flex items-center gap-2 rounded-full border border-indigo-200 px-5 py-2.5 text-sm font-semibold text-indigo-700 hover:bg-indigo-50 dark:border-indigo-500/40 dark:text-indigo-300 dark:hover:bg-indigo-500/10"
          >
            <Icon name="Download" size={16} />
            {t("common.download")}
          </button>
        )}
      </div>
      {error && <p className="mt-3 text-sm text-red-600 dark:text-red-400">{error}</p>}
    </ToolShell>
  );
}
