"use client";

import { useState } from "react";
import { useLocale } from "@/i18n/LocaleProvider";
import { ToolShell } from "@/components/tool/ToolShell";
import { Icon } from "@/components/Icon";
import { TRANSLATE_LANGUAGES, TranslateError, translateText } from "@/lib/translateText";

export default function TranslatePage() {
  const { t, locale } = useLocale();
  const [text, setText] = useState("");
  const [source, setSource] = useState("auto");
  const [target, setTarget] = useState(locale === "en" ? "fr" : "en");
  const [translation, setTranslation] = useState("");
  const [working, setWorking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState("");
  const [copied, setCopied] = useState(false);

  async function run() {
    if (!text.trim()) return;
    setWorking(true);
    setError(null);
    setTranslation("");
    try {
      const out = await translateText(text, source, target, (i, n) =>
        setProgress(t("x.tl.progress").replace("{i}", String(Math.min(i + 1, n))).replace("{n}", String(n))),
      );
      setTranslation(out);
    } catch (e) {
      setError(e instanceof TranslateError && e.code === "same" ? t("x.tl.same") : t("x.tl.error"));
    } finally {
      setWorking(false);
      setProgress("");
    }
  }

  async function copy() {
    await navigator.clipboard.writeText(translation);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  const select = "w-full rounded-xl border border-slate-200 bg-white p-2.5 text-sm dark:border-slate-700 dark:bg-slate-900";

  return (
    <ToolShell
      toolId="translate"
      icon="Languages"
      titleKey="tool.translate.name"
      descKey="tool.translate.desc"
      badges={["internet"]}
      note={<span>{t("x.tl.note")}</span>}
    >
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="text-xs font-medium text-slate-500 dark:text-slate-400">
          {t("x.tl.source")}
          <select value={source} onChange={(e) => setSource(e.target.value)} className={`${select} mt-1`}>
            <option value="auto">{t("x.tl.auto")}</option>
            {TRANSLATE_LANGUAGES.map(([code, name]) => <option key={code} value={code}>{name}</option>)}
          </select>
        </label>
        <label className="text-xs font-medium text-slate-500 dark:text-slate-400">
          {t("x.tl.target")}
          <select value={target} onChange={(e) => setTarget(e.target.value)} className={`${select} mt-1`}>
            {TRANSLATE_LANGUAGES.map(([code, name]) => <option key={code} value={code}>{name}</option>)}
          </select>
        </label>
      </div>

      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={8}
        placeholder={t("x.tl.placeholder")}
        className="mt-3 w-full rounded-xl border border-slate-200 bg-white p-3 text-sm dark:border-slate-700 dark:bg-slate-900"
      />

      {error && (
        <p className="mt-3 rounded-xl bg-amber-50 p-3 text-sm text-amber-800 dark:bg-amber-500/10 dark:text-amber-200">{error}</p>
      )}

      <div className="mt-3 flex items-center gap-3">
        <button
          onClick={() => void run()}
          disabled={!text.trim() || working}
          className="flex items-center gap-2 rounded-full bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow hover:bg-indigo-700 disabled:opacity-40"
        >
          {working ? <Icon name="Loader2" size={16} className="animate-spin" /> : <Icon name="Languages" size={16} />}
          {t("x.tl.translate")}
        </button>
        {working && <span className="text-xs text-slate-500">{progress}</span>}
      </div>

      {translation && (
        <div className="mt-6">
          <div className="mb-2 flex justify-end">
            <button onClick={() => void copy()} className="flex items-center gap-1 rounded-full border border-slate-200 px-2.5 py-1 text-xs hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800">
              <Icon name={copied ? "Check" : "Copy"} size={12} /> {copied ? t("common.copied") : t("common.copy")}
            </button>
          </div>
          <textarea value={translation} onChange={(e) => setTranslation(e.target.value)} rows={8} className="w-full rounded-xl border border-slate-200 bg-white p-3 text-sm dark:border-slate-700 dark:bg-slate-900" />
        </div>
      )}
    </ToolShell>
  );
}
