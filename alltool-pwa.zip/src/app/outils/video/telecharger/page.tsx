"use client";

import { Suspense, useEffect, useState, type FormEvent } from "react";
import { useSearchParams } from "next/navigation";
import { useLocale } from "@/i18n/LocaleProvider";
import { ToolShell } from "@/components/tool/ToolShell";
import { ProgressBar } from "@/components/tool/ProgressBar";
import { Icon } from "@/components/Icon";
import { isNativeApp, nativeText, openVideoBrowser } from "@/lib/native";
import { downloadVideo, findVideo, safeFileName, VideoError, type FoundVideo } from "@/lib/videoFetch";

function DownloaderInner() {
  const { t, locale } = useLocale();
  const [native, setNative] = useState(false);
  useEffect(() => { setNative(isNativeApp()); }, []);
  const params = useSearchParams();
  const [link, setLink] = useState("");
  const [video, setVideo] = useState<FoundVideo | null>(null);
  const [searching, setSearching] = useState(false);
  const [progress, setProgress] = useState<number | null>(null);
  const [message, setMessage] = useState<{ tone: "error" | "info" | "ok"; text: string } | null>(null);

  async function search(raw: string) {
    if (!raw.trim()) return;
    if (isNativeApp()) {
      const u = raw.trim();
      try { await openVideoBrowser(/^https?:\/\//i.test(u) ? u : `https://${u}`); } catch { setMessage({ tone: "error", text: t("x.dl.network") }); }
      return;
    }
    setSearching(true);
    setVideo(null);
    setMessage(null);
    try {
      setVideo(await findVideo(raw));
    } catch (e) {
      const code = e instanceof VideoError ? e.code : "network";
      const text =
        code === "facebook" ? t("x.dl.facebook")
        : code === "unsupported" ? t("x.dl.unsupported")
        : code === "notFound" ? t("x.dl.notFound")
        : code === "invalid" ? t("x.dl.unsupported")
        : t("x.dl.network");
      setMessage({ tone: "error", text });
    } finally {
      setSearching(false);
    }
  }

  // Arrivée depuis le navigateur intégré : le lien est déjà rempli et la recherche démarre.
  useEffect(() => {
    const fromBrowser = params.get("url");
    if (fromBrowser) {
      setLink(fromBrowser);
      void search(fromBrowser);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    void search(link);
  }

  async function save() {
    if (!video) return;
    setMessage(null);
    setProgress(0);
    const result = await downloadVideo(video.url, safeFileName(video.title), (r) => setProgress(Math.round(r * 100)));
    setProgress(null);
    setMessage(result === "saved" ? { tone: "ok", text: t("x.dl.saved") } : { tone: "info", text: t("x.dl.corsFallback") });
  }

  const tone = {
    error: "bg-amber-50 text-amber-800 dark:bg-amber-500/10 dark:text-amber-200",
    info: "bg-sky-50 text-sky-800 dark:bg-sky-500/10 dark:text-sky-200",
    ok: "bg-emerald-50 text-emerald-800 dark:bg-emerald-500/10 dark:text-emerald-200",
  };

  return (
    <ToolShell
      toolId="video-download"
      icon="Download"
      titleKey="tool.videoDownload.name"
      descKey="tool.videoDownload.desc"
      badges={["internet"]}
      note={
        <div className="flex flex-col gap-1">
          <span>{t("x.dl.rights")}</span>
          <span className="text-[11px] opacity-80">{native ? nativeText(locale).downloadNote : t("x.dl.privacy")}</span>
        </div>
      }
    >
      <form onSubmit={onSubmit} className="flex gap-2">
        <input
          value={link}
          onChange={(e) => setLink(e.target.value)}
          inputMode="url"
          autoCapitalize="none"
          placeholder={t("x.dl.placeholder")}
          className="min-w-0 flex-1 rounded-xl border border-slate-200 bg-white p-3 text-sm dark:border-slate-700 dark:bg-slate-900"
        />
        <button
          type="submit"
          disabled={!link.trim() || searching}
          className="flex items-center gap-2 rounded-xl bg-indigo-600 px-4 text-sm font-semibold text-white hover:bg-indigo-700 disabled:opacity-40"
        >
          {searching ? <Icon name="Loader2" size={16} className="animate-spin" /> : <Icon name="Search" size={16} />}
          <span className="hidden sm:inline">{t("x.dl.search")}</span>
        </button>
      </form>

      {searching && <p className="mt-3 text-sm text-slate-500">{t("x.dl.searching")}</p>}
      {message && <p className={`mt-3 rounded-xl p-3 text-sm ${tone[message.tone]}`}>{message.text}</p>}

      {video && (
        <div className="mt-4 rounded-2xl border border-slate-200 p-3 dark:border-slate-700">
          <p className="mb-2 text-sm font-medium text-emerald-700 dark:text-emerald-300">
            {t("x.dl.found")}{video.title ? ` — ${video.title}` : ""}
          </p>
          <video src={video.url} poster={video.cover} controls playsInline className="max-h-96 w-full rounded-xl bg-black" />
          {progress !== null && <div className="mt-3"><ProgressBar value={progress} label={t("x.dl.downloading").replace("{pct}", String(progress))} /></div>}
          <button
            onClick={() => void save()}
            disabled={progress !== null}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-full bg-indigo-600 px-5 py-3 text-sm font-semibold text-white shadow hover:bg-indigo-700 disabled:opacity-40 sm:w-auto"
          >
            <Icon name="Download" size={16} /> {t("x.dl.download")}
          </button>
        </div>
      )}
    </ToolShell>
  );
}

export default function VideoDownloadPage() {
  return (
    <Suspense fallback={null}>
      <DownloaderInner />
    </Suspense>
  );
}
