"use client";

import { useRef, useState } from "react";
import { useLocale } from "@/i18n/LocaleProvider";
import { ToolShell } from "@/components/tool/ToolShell";
import { FileDrop } from "@/components/tool/FileDrop";
import { ProgressBar } from "@/components/tool/ProgressBar";
import { Icon } from "@/components/Icon";
import { runFFmpegJob, bytesToSize } from "@/lib/ffmpeg";
import { downloadBlob } from "@/lib/imageUtils";
import { queueStore } from "@/lib/queueStore";

type ProfileKey = "economy" | "low" | "standard" | "high" | "custom";

const PROFILES: Record<Exclude<ProfileKey, "custom">, { height: number; videoKbps: number; audioKbps: number; label: string }> = {
  economy: { height: 480, videoKbps: 500, audioKbps: 96, label: "Économie d'espace" },
  low: { height: 576, videoKbps: 800, audioKbps: 96, label: "Basse qualité" },
  standard: { height: 720, videoKbps: 1500, audioKbps: 128, label: "Qualité standard" },
  high: { height: 1080, videoKbps: 3500, audioKbps: 192, label: "Haute qualité" },
};

function getVideoDuration(file: File): Promise<number> {
  return new Promise((resolve) => {
    const video = document.createElement("video");
    video.preload = "metadata";
    video.onloadedmetadata = () => {
      resolve(video.duration || 0);
      URL.revokeObjectURL(video.src);
    };
    video.onerror = () => resolve(0);
    video.src = URL.createObjectURL(file);
  });
}

export default function VideoCompressPage() {
  const { t } = useLocale();
  const [file, setFile] = useState<File | null>(null);
  const [duration, setDuration] = useState(0);
  const [profile, setProfile] = useState<ProfileKey>("standard");
  const [customHeight, setCustomHeight] = useState(720);
  const [customVideoKbps, setCustomVideoKbps] = useState(1500);
  const [customAudioKbps, setCustomAudioKbps] = useState(128);
  const [outputFormat, setOutputFormat] = useState<"mp4" | "webm">("mp4");
  const [fps, setFps] = useState<"original" | "24" | "30">("original");
  const [progress, setProgress] = useState(0);
  const [working, setWorking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resultBlob, setResultBlob] = useState<Blob | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const settings = profile === "custom"
    ? { height: customHeight, videoKbps: customVideoKbps, audioKbps: customAudioKbps }
    : PROFILES[profile];

  const estimatedSize = duration > 0 ? ((settings.videoKbps + settings.audioKbps) * 1000 * duration) / 8 : 0;

  async function onFiles(files: File[]) {
    const f = files[0];
    setFile(f);
    setResultBlob(null);
    setError(null);
    const d = await getVideoDuration(f);
    setDuration(d);
  }

  async function run() {
    if (!file) return;
    setWorking(true);
    setError(null);
    setProgress(0);
    const controller = new AbortController();
    abortRef.current = controller;
    const taskId = crypto.randomUUID();
    queueStore.add({ id: taskId, toolId: "video-compress", label: `Compression — ${file.name}`, onCancel: () => controller.abort() });
    queueStore.update(taskId, { status: "running" });
    try {
      const inputName = "input" + (file.name.match(/\.\w+$/)?.[0] ?? ".mp4");
      const outputName = `output.${outputFormat}`;
      const args = [
        "-i",
        inputName,
        "-vf",
        `scale=-2:${settings.height}`,
        ...(fps !== "original" ? ["-r", fps] : []),
        "-b:v",
        `${settings.videoKbps}k`,
        "-maxrate",
        `${Math.round(settings.videoKbps * 1.3)}k`,
        "-bufsize",
        `${settings.videoKbps * 2}k`,
        "-c:v",
        outputFormat === "mp4" ? "libx264" : "libvpx-vp9",
        "-preset",
        "veryfast",
        "-c:a",
        outputFormat === "mp4" ? "aac" : "libopus",
        "-b:a",
        `${settings.audioKbps}k`,
        outputName,
      ];
      const data = await runFFmpegJob({
        inputs: [{ name: inputName, data: new Uint8Array(await file.arrayBuffer()) }],
        args,
        outputName,
        signal: controller.signal,
        onProgress: (ratio) => {
          setProgress(Math.round(ratio * 100));
          queueStore.update(taskId, { progress: Math.round(ratio * 100) });
        },
      });
      const blob = new Blob([data.slice()], { type: outputFormat === "mp4" ? "video/mp4" : "video/webm" });
      setResultBlob(blob);
      queueStore.update(taskId, { status: "done", progress: 100, message: bytesToSize(blob.size) });
    } catch (err) {
      console.error(err);
      setError(t("common.errorGeneric"));
      queueStore.update(taskId, { status: "error", message: String(err) });
    } finally {
      setWorking(false);
    }
  }

  return (
    <ToolShell toolId="video-compress" icon="Shrink" titleKey="tool.videoCompress.name" descKey="tool.videoCompress.desc" badges={["local"]}>
      <FileDrop accept="video/*" onFiles={onFiles} hint="MP4, WEBM, MOV…" />

      {file && (
        <div className="mt-4 flex flex-wrap gap-2">
          {(Object.keys(PROFILES) as Array<Exclude<ProfileKey, "custom">>).map((key) => (
            <button
              key={key}
              onClick={() => setProfile(key)}
              className={`rounded-full border px-3 py-1.5 text-xs font-medium transition ${
                profile === key
                  ? "border-indigo-500 bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300"
                  : "border-slate-200 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
              }`}
            >
              {PROFILES[key].label}
            </button>
          ))}
          <button
            onClick={() => setProfile("custom")}
            className={`rounded-full border px-3 py-1.5 text-xs font-medium transition ${
              profile === "custom"
                ? "border-indigo-500 bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300"
                : "border-slate-200 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
            }`}
          >
            Personnalisée
          </button>
        </div>
      )}

      {file && profile === "custom" && (
        <div className="mt-4 grid grid-cols-1 gap-4 rounded-2xl border border-slate-200 bg-white p-4 sm:grid-cols-2 lg:grid-cols-4 dark:border-slate-800 dark:bg-[#121826]">
          <div>
            <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Résolution (hauteur px)</label>
            <select value={customHeight} onChange={(e) => setCustomHeight(Number(e.target.value))} className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-900">
              {[360, 480, 576, 720, 1080, 1440].map((h) => (
                <option key={h} value={h}>{h}p</option>
              ))}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Débit vidéo ({customVideoKbps} kbps)</label>
            <input type="range" min={200} max={6000} step={100} value={customVideoKbps} onChange={(e) => setCustomVideoKbps(Number(e.target.value))} className="mt-2 w-full" />
          </div>
          <div>
            <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Débit audio ({customAudioKbps} kbps)</label>
            <input type="range" min={64} max={256} step={16} value={customAudioKbps} onChange={(e) => setCustomAudioKbps(Number(e.target.value))} className="mt-2 w-full" />
          </div>
          <div>
            <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Images/seconde</label>
            <select value={fps} onChange={(e) => setFps(e.target.value as "original" | "24" | "30")} className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-900">
              <option value="original">Originale</option>
              <option value="24">24</option>
              <option value="30">30</option>
            </select>
          </div>
        </div>
      )}

      {file && (
        <div className="mt-4 flex flex-wrap items-center gap-4 text-xs text-slate-500 dark:text-slate-400">
          <span>Format de sortie :</span>
          <select value={outputFormat} onChange={(e) => setOutputFormat(e.target.value as "mp4" | "webm")} className="rounded-lg border border-slate-200 bg-white px-2 py-1 dark:border-slate-700 dark:bg-slate-900">
            <option value="mp4">MP4 (H.264)</option>
            <option value="webm">WEBM (VP9)</option>
          </select>
          {estimatedSize > 0 && <span>Taille estimée : ~{bytesToSize(estimatedSize)}</span>}
        </div>
      )}

      {working && <div className="mt-4"><ProgressBar value={progress} label={t("common.progress")} /></div>}
      {error && <p className="mt-3 text-sm text-red-600 dark:text-red-400">{error}</p>}

      <div className="mt-5 flex flex-wrap items-center gap-3">
        <button onClick={run} disabled={!file || working} className="flex items-center gap-2 rounded-full bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow hover:bg-indigo-700 disabled:opacity-40">
          {working ? <Icon name="Loader2" size={16} className="animate-spin" /> : <Icon name="Shrink" size={16} />}
          {t("common.start")}
        </button>
        {working && (
          <button onClick={() => abortRef.current?.abort()} className="rounded-full border border-red-200 px-4 py-2.5 text-sm font-medium text-red-600 hover:bg-red-50 dark:border-red-500/30 dark:text-red-400 dark:hover:bg-red-500/10">
            {t("common.cancel")}
          </button>
        )}
        {resultBlob && (
          <button onClick={() => downloadBlob(resultBlob, `video-compressee.${outputFormat}`)} className="flex items-center gap-2 rounded-full border border-indigo-200 px-5 py-2.5 text-sm font-semibold text-indigo-700 hover:bg-indigo-50 dark:border-indigo-500/40 dark:text-indigo-300 dark:hover:bg-indigo-500/10">
            <Icon name="Download" size={16} />
            {t("common.download")} ({bytesToSize(resultBlob.size)})
          </button>
        )}
      </div>
    </ToolShell>
  );
}
