"use client";

import { useRef, useState } from "react";
import { errorWithDetail } from "@/lib/errorText";
import { useLocale } from "@/i18n/LocaleProvider";
import { ToolShell } from "@/components/tool/ToolShell";
import { FileDrop } from "@/components/tool/FileDrop";
import { ProgressBar } from "@/components/tool/ProgressBar";
import { Icon } from "@/components/Icon";
import { mergeVideos } from "@/lib/mergeMedia";
import { bytesToSize } from "@/lib/ffmpeg";
import { downloadBlob } from "@/lib/imageUtils";
import { queueStore } from "@/lib/queueStore";

interface Item {
  id: string;
  file: File;
}

export default function VideoMergePage() {
  const { t } = useLocale();
  const [items, setItems] = useState<Item[]>([]);
  const [height, setHeight] = useState(720);
  const [fps, setFps] = useState(30);
  const [progress, setProgress] = useState(0);
  const [stepLabel, setStepLabel] = useState("");
  const [working, setWorking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resultBlob, setResultBlob] = useState<Blob | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  function addFiles(files: File[]) {
    setItems((prev) => [...prev, ...files.map((file) => ({ id: crypto.randomUUID(), file }))]);
    setResultBlob(null);
  }

  function move(id: string, dir: -1 | 1) {
    setItems((prev) => {
      const idx = prev.findIndex((i) => i.id === id);
      const newIdx = idx + dir;
      if (newIdx < 0 || newIdx >= prev.length) return prev;
      const copy = [...prev];
      [copy[idx], copy[newIdx]] = [copy[newIdx], copy[idx]];
      return copy;
    });
  }

  function remove(id: string) {
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  async function run() {
    if (items.length < 2) {
      setError("Sélectionnez au moins 2 vidéos.");
      return;
    }
    setWorking(true);
    setError(null);
    setProgress(0);
    const controller = new AbortController();
    abortRef.current = controller;
    const taskId = crypto.randomUUID();
    queueStore.add({ id: taskId, toolId: "video-merge", label: `Fusion de ${items.length} vidéos`, onCancel: () => controller.abort() });
    queueStore.update(taskId, { status: "running" });
    try {
      setStepLabel("Normalisation des vidéos (résolution, fréquence, codecs)…");
      const data = await mergeVideos(items.map((i) => i.file), {
        height,
        fps,
        videoKbps: 1800,
        audioKbps: 128,
        signal: controller.signal,
        onProgress: ({ stepIndex, totalSteps, stepProgress }) => {
          const overall = Math.round(((stepIndex + stepProgress) / totalSteps) * 100);
          setProgress(overall);
          queueStore.update(taskId, { progress: overall });
          setStepLabel(stepIndex < items.length ? `Normalisation ${stepIndex + 1}/${items.length}…` : "Assemblage final…");
        },
      });
      const blob = new Blob([data.slice()], { type: "video/mp4" });
      setResultBlob(blob);
      queueStore.update(taskId, { status: "done", progress: 100, message: bytesToSize(blob.size) });
    } catch (err) {
      console.error(err);
      setError(errorWithDetail(t("common.errorGeneric"), err));
      queueStore.update(taskId, { status: "error" });
    } finally {
      setWorking(false);
    }
  }

  return (
    <ToolShell
      toolId="video-merge"
      icon="Combine"
      titleKey="tool.videoMerge.name"
      descKey="tool.videoMerge.desc"
      badges={["local"]}
      note={<span>Les vidéos sont automatiquement normalisées (même résolution, même fréquence d&apos;images, mêmes codecs) avant d&apos;être assemblées, afin d&apos;éviter tout problème de compatibilité.</span>}
    >
      <FileDrop accept="video/*" multiple onFiles={addFiles} hint="Sélectionnez au moins 2 vidéos" />

      {items.length > 0 && (
        <div className="mt-4 flex flex-col gap-2">
          {items.map((item, idx) => (
            <div key={item.id} className="flex items-center justify-between gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-800 dark:bg-[#121826]">
              <span className="truncate">#{idx + 1} — {item.file.name}</span>
              <div className="flex shrink-0 gap-1">
                <button onClick={() => move(item.id, -1)} className="rounded p-1 hover:bg-slate-100 dark:hover:bg-slate-800"><Icon name="ArrowUp" size={14} /></button>
                <button onClick={() => move(item.id, 1)} className="rounded p-1 hover:bg-slate-100 dark:hover:bg-slate-800"><Icon name="ArrowDown" size={14} /></button>
                <button onClick={() => remove(item.id)} className="rounded p-1 text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10"><Icon name="X" size={14} /></button>
              </div>
            </div>
          ))}
        </div>
      )}

      {items.length > 0 && (
        <div className="mt-4 grid grid-cols-2 gap-4 rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-[#121826]">
          <div>
            <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Résolution commune</label>
            <select value={height} onChange={(e) => setHeight(Number(e.target.value))} className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-900">
              {[480, 720, 1080].map((h) => <option key={h} value={h}>{h}p</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Fréquence d&apos;images</label>
            <select value={fps} onChange={(e) => setFps(Number(e.target.value))} className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-900">
              {[24, 30, 60].map((f) => <option key={f} value={f}>{f} fps</option>)}
            </select>
          </div>
        </div>
      )}

      {working && <div className="mt-4"><ProgressBar value={progress} label={stepLabel} /></div>}
      {error && <p className="mt-3 text-sm text-red-600 dark:text-red-400">{error}</p>}

      <div className="mt-5 flex flex-wrap items-center gap-3">
        <button onClick={run} disabled={items.length < 2 || working} className="flex items-center gap-2 rounded-full bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow hover:bg-indigo-700 disabled:opacity-40">
          {working ? <Icon name="Loader2" size={16} className="animate-spin" /> : <Icon name="Combine" size={16} />}
          {t("common.start")}
        </button>
        {working && (
          <button onClick={() => abortRef.current?.abort()} className="rounded-full border border-red-200 px-4 py-2.5 text-sm font-medium text-red-600 hover:bg-red-50 dark:border-red-500/30 dark:text-red-400 dark:hover:bg-red-500/10">
            {t("common.cancel")}
          </button>
        )}
        {resultBlob && (
          <button onClick={() => downloadBlob(resultBlob, "video-fusionnee.mp4")} className="flex items-center gap-2 rounded-full border border-indigo-200 px-5 py-2.5 text-sm font-semibold text-indigo-700 hover:bg-indigo-50 dark:border-indigo-500/40 dark:text-indigo-300 dark:hover:bg-indigo-500/10">
            <Icon name="Download" size={16} />
            {t("common.download")} ({bytesToSize(resultBlob.size)})
          </button>
        )}
      </div>
    </ToolShell>
  );
}
