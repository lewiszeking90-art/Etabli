"use client";

import { useRef, useState } from "react";
import { errorWithDetail } from "@/lib/errorText";
import { useLocale } from "@/i18n/LocaleProvider";
import { ToolShell } from "@/components/tool/ToolShell";
import { FileDrop } from "@/components/tool/FileDrop";
import { ProgressBar } from "@/components/tool/ProgressBar";
import { Icon } from "@/components/Icon";
import { runFFmpegJob, bytesToSize } from "@/lib/ffmpeg";
import { downloadBlob } from "@/lib/imageUtils";
import { queueStore } from "@/lib/queueStore";

const FORMATS: Record<string, { codec: string; ext: string; mime: string; label: string }> = {
  mp3: { codec: "libmp3lame", ext: "mp3", mime: "audio/mpeg", label: "MP3" },
  m4a: { codec: "aac", ext: "m4a", mime: "audio/mp4", label: "M4A (AAC)" },
  wav: { codec: "pcm_s16le", ext: "wav", mime: "audio/wav", label: "WAV (non compressé)" },
};

export default function ExtractAudioPage() {
  const { t } = useLocale();
  const [file, setFile] = useState<File | null>(null);
  const [format, setFormat] = useState<"mp3" | "m4a" | "wav">("mp3");
  const [bitrate, setBitrate] = useState(192);
  const [progress, setProgress] = useState(0);
  const [working, setWorking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [resultBlob, setResultBlob] = useState<Blob | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [filename, setFilename] = useState("audio-extrait");
  const abortRef = useRef<AbortController | null>(null);

  function onFiles(files: File[]) {
    const f = files[0];
    setFile(f);
    setResultBlob(null);
    setPreviewUrl(null);
    setError(null);
  }

  async function run() {
    if (!file) return;
    setWorking(true);
    setError(null);
    setProgress(0);
    const controller = new AbortController();
    abortRef.current = controller;
    const info = FORMATS[format];
    const taskId = crypto.randomUUID();
    queueStore.add({ id: taskId, toolId: "video-extract-audio", label: `Extraction audio — ${file.name}`, onCancel: () => controller.abort() });
    queueStore.update(taskId, { status: "running" });
    try {
      const inputName = "input" + (file.name.match(/\.\w+$/)?.[0] ?? ".mp4");
      const outputName = `output.${info.ext}`;
      const args = [
        "-i",
        inputName,
        "-vn",
        "-c:a",
        info.codec,
        ...(format !== "wav" ? ["-b:a", `${bitrate}k`] : []),
        outputName,
      ];
      const data = await runFFmpegJob({
        inputs: [{ name: inputName, data: new Uint8Array(await file.arrayBuffer()) }],
        args,
        outputName,
        signal: controller.signal,
        onProgress: (ratio) => {
          setProgress(Math.round(ratio * 100));
          queueStore.update(taskId, { progress: Math.round(ratio * 100) });
        },
      });
      const blob = new Blob([data.slice()], { type: info.mime });
      setResultBlob(blob);
      setPreviewUrl(URL.createObjectURL(blob));
      queueStore.update(taskId, { status: "done", progress: 100, message: bytesToSize(blob.size) });
    } catch (err) {
      console.error(err);
      setError(errorWithDetail(t("common.errorGeneric"), err));
      queueStore.update(taskId, { status: "error" });
    } finally {
      setWorking(false);
    }
  }

  return (
    <ToolShell toolId="video-extract-audio" icon="AudioWaveform" titleKey="tool.videoExtractAudio.name" descKey="tool.videoExtractAudio.desc" badges={["local"]}>
      <FileDrop accept="video/*" onFiles={onFiles} hint="MP4, WEBM, MOV…" />

      {file && (
        <div className="mt-5 grid grid-cols-1 gap-4 rounded-2xl border border-slate-200 bg-white p-4 sm:grid-cols-3 dark:border-slate-800 dark:bg-[#121826]">
          <div>
            <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Format</label>
            <select value={format} onChange={(e) => setFormat(e.target.value as "mp3" | "m4a" | "wav")} className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-900">
              {Object.entries(FORMATS).map(([key, f]) => (
                <option key={key} value={key}>{f.label}</option>
              ))}
            </select>
          </div>
          {format !== "wav" && (
            <div>
              <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Qualité ({bitrate} kbps)</label>
              <input type="range" min={96} max={320} step={32} value={bitrate} onChange={(e) => setBitrate(Number(e.target.value))} className="mt-2 w-full" />
            </div>
          )}
          <div>
            <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Nom du fichier</label>
            <input value={filename} onChange={(e) => setFilename(e.target.value)} className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-900" />
          </div>
        </div>
      )}

      {working && <div className="mt-4"><ProgressBar value={progress} label={t("common.progress")} /></div>}
      {error && <p className="mt-3 text-sm text-red-600 dark:text-red-400">{error}</p>}

      <div className="mt-5 flex flex-wrap items-center gap-3">
        <button onClick={run} disabled={!file || working} className="flex items-center gap-2 rounded-full bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow hover:bg-indigo-700 disabled:opacity-40">
          {working ? <Icon name="Loader2" size={16} className="animate-spin" /> : <Icon name="AudioWaveform" size={16} />}
          {t("common.start")}
        </button>
        {working && (
          <button onClick={() => abortRef.current?.abort()} className="rounded-full border border-red-200 px-4 py-2.5 text-sm font-medium text-red-600 hover:bg-red-50 dark:border-red-500/30 dark:text-red-400 dark:hover:bg-red-500/10">
            {t("common.cancel")}
          </button>
        )}
        {resultBlob && (
          <button onClick={() => downloadBlob(resultBlob, `${filename || "audio"}.${FORMATS[format].ext}`)} className="flex items-center gap-2 rounded-full border border-indigo-200 px-5 py-2.5 text-sm font-semibold text-indigo-700 hover:bg-indigo-50 dark:border-indigo-500/40 dark:text-indigo-300 dark:hover:bg-indigo-500/10">
            <Icon name="Download" size={16} />
            {t("common.download")} ({bytesToSize(resultBlob.size)})
          </button>
        )}
      </div>

      {previewUrl && <audio controls src={previewUrl} className="mt-4 w-full" />}
    </ToolShell>
  );
}
