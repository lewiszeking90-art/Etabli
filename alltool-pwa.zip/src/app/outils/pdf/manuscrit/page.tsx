"use client";

import { useState } from "react";
import { useLocale } from "@/i18n/LocaleProvider";
import { ToolShell } from "@/components/tool/ToolShell";
import { FileDrop } from "@/components/tool/FileDrop";
import { ProgressBar } from "@/components/tool/ProgressBar";
import { Icon } from "@/components/Icon";
import { OCR_LANGUAGES } from "@/lib/langMap";
import { getOcrWorker } from "@/lib/ocrEngine";
import { buildTextPdf } from "@/lib/pdfBuilder";
import { downloadBlob } from "@/lib/imageUtils";

export default function HandwritingPage() {
  const { t } = useLocale();
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [langs, setLangs] = useState<string[]>(["fra"]);
  const [text, setText] = useState("");
  const [progress, setProgress] = useState(0);
  const [working, setWorking] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function toggleLang(code: string) {
    setLangs((prev) => (prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]));
  }

  function onFiles(files: File[]) {
    const f = files[0];
    setFile(f);
    setPreviewUrl(URL.createObjectURL(f));
    setText("");
    setError(null);
  }

  async function analyze() {
    if (!file) return;
    setWorking(true);
    setProgress(0);
    setError(null);
    try {
      const worker = await getOcrWorker(langs.join("+") || "fra", (p) => setProgress(Math.round(p * 100)));
      const { data } = await worker.recognize(file);
      setText(data.text.trim());
    } catch (err) {
      console.error(err);
      setError(t("common.errorGeneric"));
    } finally {
      setWorking(false);
    }
  }

  async function generatePdf() {
    if (!text.trim()) return;
    const bytes = await buildTextPdf(text, { format: "a4", orientation: "portrait", margin: 56, fontSize: 12 });
    downloadBlob(new Blob([bytes.slice()], { type: "application/pdf" }), "texte-reecrit.pdf");
  }

  return (
    <ToolShell
      toolId="handwriting"
      icon="PenLine"
      titleKey="tool.handwriting.name"
      descKey="tool.handwriting.desc"
      badges={["local"]}
      note={
        <span>
          La reconnaissance d&apos;écriture manuscrite est plus difficile que le texte imprimé : relisez et corrigez le
          résultat avant de générer la page propre. Pour de meilleurs résultats, prenez une photo bien éclairée et nette.
        </span>
      }
    >
      <div className="mb-4 flex flex-wrap gap-2">
        {OCR_LANGUAGES.slice(0, 6).map((l) => (
          <button
            key={l.code}
            onClick={() => toggleLang(l.code)}
            className={`rounded-full border px-3 py-1.5 text-xs font-medium transition ${
              langs.includes(l.code)
                ? "border-indigo-500 bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300"
                : "border-slate-200 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
            }`}
          >
            {l.label}
          </button>
        ))}
      </div>

      <FileDrop accept="image/*" onFiles={onFiles} hint="Photo d'un texte manuscrit" />

      {previewUrl && (
        <img src={previewUrl} alt="" className="mt-4 max-h-64 rounded-xl border border-slate-200 dark:border-slate-800" />
      )}

      {working && <div className="mt-4"><ProgressBar value={progress} label={t("common.progress")} /></div>}
      {error && <p className="mt-3 text-sm text-red-600 dark:text-red-400">{error}</p>}

      <button onClick={analyze} disabled={!file || working} className="mt-4 flex items-center gap-2 rounded-full bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow hover:bg-indigo-700 disabled:opacity-40">
        {working ? <Icon name="Loader2" size={16} className="animate-spin" /> : <Icon name="ScanText" size={16} />}
        Analyser l&apos;écriture
      </button>

      {text && (
        <div className="mt-6">
          <p className="mb-2 text-xs font-medium text-slate-500 dark:text-slate-400">Texte reconnu (modifiable)</p>
          <textarea value={text} onChange={(e) => setText(e.target.value)} rows={8} className="w-full rounded-xl border border-slate-200 bg-white p-3 text-sm dark:border-slate-700 dark:bg-slate-900" />
          <button onClick={generatePdf} className="mt-3 flex items-center gap-2 rounded-full border border-indigo-200 px-5 py-2.5 text-sm font-semibold text-indigo-700 hover:bg-indigo-50 dark:border-indigo-500/40 dark:text-indigo-300 dark:hover:bg-indigo-500/10">
            <Icon name="FileDown" size={16} />
            Générer la page propre (PDF)
          </button>
        </div>
      )}
    </ToolShell>
  );
}
