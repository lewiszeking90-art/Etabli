"use client";

import { useMemo, useState } from "react";
import { useLocale } from "@/i18n/LocaleProvider";
import { ToolShell } from "@/components/tool/ToolShell";
import { Icon } from "@/components/Icon";
import { buildTextPdf, type PageFormat, type Orientation } from "@/lib/pdfBuilder";
import { downloadBlob } from "@/lib/imageUtils";

export default function TextToPagesPage() {
  const { t } = useLocale();
  const [text, setText] = useState("");
  const [format, setFormat] = useState<PageFormat>("a4");
  const [orientation, setOrientation] = useState<Orientation>("portrait");
  const [fontSize, setFontSize] = useState(12);
  const [margin, setMargin] = useState(48);
  const [filename, setFilename] = useState("mon-document");
  const [working, setWorking] = useState(false);

  const estimatedPages = useMemo(() => {
    const charsPerPage = 1800 * (12 / fontSize);
    return Math.max(1, Math.ceil(text.length / charsPerPage));
  }, [text, fontSize]);

  function onImportFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    file.text().then(setText);
  }

  async function generate() {
    if (!text.trim()) return;
    setWorking(true);
    try {
      const bytes = await buildTextPdf(text, { format, orientation, margin, fontSize });
      downloadBlob(new Blob([bytes.slice()], { type: "application/pdf" }), `${filename || "document"}.pdf`);
    } finally {
      setWorking(false);
    }
  }

  return (
    <ToolShell toolId="text-to-pages" icon="FileOutput" titleKey="tool.textToPages.name" descKey="tool.textToPages.desc" badges={["local"]}>
      <div className="flex items-center justify-between">
        <label className="flex cursor-pointer items-center gap-1.5 text-xs font-medium text-indigo-600 hover:underline dark:text-indigo-300">
          <Icon name="UploadCloud" size={14} />
          Importer un fichier .txt
          <input type="file" accept=".txt,text/plain" className="hidden" onChange={onImportFile} />
        </label>
        <span className="text-xs text-slate-400">~{estimatedPages} page(s) estimée(s)</span>
      </div>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={10}
        placeholder="Collez ou saisissez votre texte ici…"
        className="mt-2 w-full rounded-xl border border-slate-200 bg-white p-3 text-sm dark:border-slate-700 dark:bg-slate-900"
      />

      <div className="mt-6 grid grid-cols-1 gap-4 rounded-2xl border border-slate-200 bg-white p-4 sm:grid-cols-2 lg:grid-cols-4 dark:border-slate-800 dark:bg-[#121826]">
        <div>
          <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Format</label>
          <select value={format} onChange={(e) => setFormat(e.target.value as PageFormat)} className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-900">
            <option value="a4">A4</option>
            <option value="letter">Letter</option>
            <option value="a5">A5</option>
          </select>
        </div>
        <div>
          <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Orientation</label>
          <select value={orientation} onChange={(e) => setOrientation(e.target.value as Orientation)} className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-900">
            <option value="portrait">Portrait</option>
            <option value="landscape">Paysage</option>
          </select>
        </div>
        <div>
          <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Taille police ({fontSize}pt)</label>
          <input type="range" min={9} max={20} value={fontSize} onChange={(e) => setFontSize(Number(e.target.value))} className="mt-2 w-full" />
        </div>
        <div>
          <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Marges ({margin}pt)</label>
          <input type="range" min={20} max={90} value={margin} onChange={(e) => setMargin(Number(e.target.value))} className="mt-2 w-full" />
        </div>
        <div className="sm:col-span-2 lg:col-span-4">
          <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Nom du fichier</label>
          <input value={filename} onChange={(e) => setFilename(e.target.value)} className="mt-1 w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm dark:border-slate-700 dark:bg-slate-900" />
        </div>
      </div>

      <button onClick={generate} disabled={!text.trim() || working} className="mt-5 flex items-center gap-2 rounded-full bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow hover:bg-indigo-700 disabled:opacity-40">
        {working ? <Icon name="Loader2" size={16} className="animate-spin" /> : <Icon name="FileDown" size={16} />}
        {t("common.download")} PDF
      </button>
    </ToolShell>
  );
}
