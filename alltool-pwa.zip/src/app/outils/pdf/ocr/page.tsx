"use client";

import { useState } from "react";
import { useLocale } from "@/i18n/LocaleProvider";
import { ToolShell } from "@/components/tool/ToolShell";
import { FileDrop } from "@/components/tool/FileDrop";
import { ProgressBar } from "@/components/tool/ProgressBar";
import { Icon } from "@/components/Icon";
import { OCR_LANGUAGES } from "@/lib/langMap";
import { getOcrWorker } from "@/lib/ocrEngine";
import { getPdfPageCount, renderPdfPageToCanvas } from "@/lib/pdfRender";
import { downloadBlob } from "@/lib/imageUtils";
import { buildTextPdf } from "@/lib/pdfBuilder";

interface PageResult {
  id: string;
  sourceName: string;
  pageLabel: string;
  text: string;
  hasText: boolean;
  imageUrl?: string;
}

export default function OcrPage() {
  const { t } = useLocale();
  const [langs, setLangs] = useState<string[]>(["fra", "eng"]);
  const [results, setResults] = useState<PageResult[]>([]);
  const [progress, setProgress] = useState(0);
  const [working, setWorking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copiedAll, setCopiedAll] = useState(false);

  function toggleLang(code: string) {
    setLangs((prev) => (prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code]));
  }

  async function processFiles(files: File[]) {
    setWorking(true);
    setError(null);
    setProgress(0);
    const newResults: PageResult[] = [];
    try {
      const jobs: { file: File; pageNumber?: number; totalPages?: number }[] = [];
      for (const file of files) {
        if (file.type === "application/pdf") {
          const count = await getPdfPageCount(file);
          for (let p = 1; p <= count; p++) jobs.push({ file, pageNumber: p, totalPages: count });
        } else if (file.type.startsWith("image/")) {
          jobs.push({ file });
        }
      }

      let done = 0;
      const langString = langs.length ? langs.join("+") : "fra+eng";

      for (const job of jobs) {
        let target: HTMLCanvasElement | File = job.file;
        if (job.pageNumber) {
          target = await renderPdfPageToCanvas(job.file, job.pageNumber, 2.2);
        }
        const worker = await getOcrWorker(langString, (p) => {
          setProgress(Math.round(((done + p) / jobs.length) * 100));
        });
        const { data } = await worker.recognize(target);
        const text = data.text.trim();
        done += 1;
        setProgress(Math.round((done / jobs.length) * 100));
        newResults.push({
          id: crypto.randomUUID(),
          sourceName: job.file.name,
          pageLabel: job.pageNumber ? `${job.file.name} — page ${job.pageNumber}/${job.totalPages}` : job.file.name,
          text,
          hasText: text.length > 0,
          imageUrl: target instanceof HTMLCanvasElement ? target.toDataURL("image/jpeg", 0.6) : URL.createObjectURL(job.file),
        });
      }
      setResults((prev) => [...prev, ...newResults]);
    } catch (err) {
      console.error(err);
      setError(t("common.errorGeneric"));
    } finally {
      setWorking(false);
    }
  }

  function updateText(id: string, text: string) {
    setResults((prev) => prev.map((r) => (r.id === id ? { ...r, text, hasText: text.trim().length > 0 } : r)));
  }

  async function copyAll() {
    const full = results.map((r) => `--- ${r.pageLabel} ---\n${r.text}`).join("\n\n");
    await navigator.clipboard.writeText(full);
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 1500);
  }

  function exportTxt() {
    const full = results.map((r) => `--- ${r.pageLabel} ---\n${r.text}`).join("\n\n");
    downloadBlob(new Blob([full], { type: "text/plain;charset=utf-8" }), "ocr-resultat.txt");
  }

  async function exportPdf() {
    const full = results.map((r) => `${r.pageLabel}\n\n${r.text}`).join("\n\n\n");
    const bytes = await buildTextPdf(full, { format: "a4", orientation: "portrait", margin: 40, fontSize: 11 });
    downloadBlob(new Blob([bytes.slice()], { type: "application/pdf" }), "ocr-resultat.pdf");
  }

  return (
    <ToolShell
      toolId="ocr"
      icon="ScanText"
      titleKey="tool.ocr.name"
      descKey="tool.ocr.desc"
      badges={["local"]}
      note={<span>Le moteur OCR (Tesseract) télécharge les données de langue nécessaires la première fois (quelques Mo par langue).</span>}
    >
      <div className="mb-4 flex flex-wrap gap-2">
        {OCR_LANGUAGES.map((l) => (
          <button
            key={l.code}
            onClick={() => toggleLang(l.code)}
            className={`rounded-full border px-3 py-1.5 text-xs font-medium transition ${
              langs.includes(l.code)
                ? "border-indigo-500 bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300"
                : "border-slate-200 text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
            }`}
          >
            {l.label}
          </button>
        ))}
      </div>

      <FileDrop accept="image/*,application/pdf" multiple onFiles={processFiles} hint="Images (JPG, PNG) ou PDF multi-pages" />

      {working && <div className="mt-4"><ProgressBar value={progress} label={t("common.progress")} /></div>}
      {error && <p className="mt-3 text-sm text-red-600 dark:text-red-400">{error}</p>}

      {results.length > 0 && (
        <>
          <div className="mt-6 flex flex-wrap gap-2">
            <button onClick={copyAll} className="flex items-center gap-1.5 rounded-full border border-slate-200 px-3 py-1.5 text-xs font-medium hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800">
              <Icon name={copiedAll ? "Check" : "Copy"} size={13} />
              {copiedAll ? t("common.copied") : t("common.copy")}
            </button>
            <button onClick={exportTxt} className="flex items-center gap-1.5 rounded-full border border-slate-200 px-3 py-1.5 text-xs font-medium hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800">
              <Icon name="FileDown" size={13} /> TXT
            </button>
            <button onClick={exportPdf} className="flex items-center gap-1.5 rounded-full border border-slate-200 px-3 py-1.5 text-xs font-medium hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800">
              <Icon name="FileDown" size={13} /> PDF
            </button>
          </div>

          <div className="mt-4 flex flex-col gap-4">
            {results.map((r) => (
              <div key={r.id} className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-[#121826]">
                <div className="mb-2 flex items-center justify-between">
                  <p className="text-xs font-semibold text-slate-500 dark:text-slate-400">{r.pageLabel}</p>
                  {!r.hasText && (
                    <span className="flex items-center gap-1 rounded-full bg-amber-50 px-2 py-0.5 text-[10px] font-medium text-amber-700 dark:bg-amber-500/10 dark:text-amber-300">
                      <Icon name="AlertTriangle" size={11} /> Aucun texte détecté
                    </span>
                  )}
                </div>
                <textarea
                  value={r.text}
                  onChange={(e) => updateText(r.id, e.target.value)}
                  rows={5}
                  className="w-full rounded-lg border border-slate-200 bg-slate-50 p-2 text-sm dark:border-slate-700 dark:bg-slate-900"
                  placeholder="(vide)"
                />
              </div>
            ))}
          </div>
        </>
      )}
    </ToolShell>
  );
}
