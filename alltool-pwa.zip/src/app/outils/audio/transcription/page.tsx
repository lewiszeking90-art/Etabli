"use client";

import { useRef, useState } from "react";
import { errorWithDetail } from "@/lib/errorText";
import { useLocale } from "@/i18n/LocaleProvider";
import { ToolShell } from "@/components/tool/ToolShell";
import { FileDrop } from "@/components/tool/FileDrop";
import { ProgressBar } from "@/components/tool/ProgressBar";
import { Icon } from "@/components/Icon";
import { downloadBlob } from "@/lib/imageUtils";
import { buildSrt } from "@/lib/srt";
import { SpeechError, transcribeBlob, type Status, type TranscriptItem } from "@/lib/speechToText";

const LANG_NAMES: Record<string, string> = {
  fr: "Français", en: "English", es: "Español", de: "Deutsch", it: "Italiano", pt: "Português", nl: "Nederlands",
  tr: "Türkçe", ru: "Русский", ar: "العربية", zh: "中文", ja: "日本語", ko: "한국어", sw: "Kiswahili", und: "?",
};

function clock(seconds: number) {
  const s = Math.floor(seconds);
  return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
}

export default function TranscribePage() {
  const { t } = useLocale();
  const [file, setFile] = useState<File | null>(null);
  const [items, setItems] = useState<TranscriptItem[]>([]);
  const [text, setText] = useState("");
  const [progress, setProgress] = useState(0);
  const [statusLabel, setStatusLabel] = useState("");
  const [working, setWorking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [recording, setRecording] = useState(false);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  function onFiles(files: File[]) {
    setFile(files[0]);
    setItems([]);
    setText("");
    setError(null);
  }

  function statusText(s: Status): string {
    if (s.kind === "analyzing") return t("x.tr.analyzing");
    if (s.kind === "loading") return t("x.tr.loading");
    return t("x.tr.segment").replace("{i}", String(s.i)).replace("{n}", String(s.n));
  }

  async function run(blob: Blob) {
    setWorking(true);
    setError(null);
    setItems([]);
    setText("");
    setProgress(0);
    try {
      const result = await transcribeBlob(blob, (s) => setStatusLabel(statusText(s)), (r) => setProgress(Math.round(r * 100)));
      setItems(result);
      setText(result.map((r) => `[${clock(r.start)}] ${r.text}`).join("\n"));
    } catch (e) {
      if (e instanceof SpeechError && e.code === "noSpeech") setError(t("x.tr.noSpeech"));
      else if (e instanceof SpeechError && e.code === "tooLong") setError(t("x.tr.tooLong"));
      else setError(errorWithDetail(t("common.errorGeneric"), e));
    } finally {
      setWorking(false);
    }
  }

  async function toggleRecording() {
    if (recording) {
      recorderRef.current?.stop();
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const rec = new MediaRecorder(stream);
      chunksRef.current = [];
      rec.ondataavailable = (e) => { if (e.data.size) chunksRef.current.push(e.data); };
      rec.onstop = () => {
        stream.getTracks().forEach((tr) => tr.stop());
        setRecording(false);
        void run(new Blob(chunksRef.current, { type: rec.mimeType || "audio/webm" }));
      };
      recorderRef.current = rec;
      rec.start();
      setRecording(true);
      setError(null);
    } catch {
      setError(t("x.tr.micBlocked"));
    }
  }

  async function copy() {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  const langs = Array.from(new Set(items.map((i) => LANG_NAMES[i.lang] ?? i.lang)));
  const btn = "flex items-center gap-1 rounded-full border border-slate-200 px-2.5 py-1 text-xs hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800";

  return (
    <ToolShell
      toolId="transcribe"
      icon="Captions"
      titleKey="tool.transcribe.name"
      descKey="tool.transcribe.desc"
      badges={["local"]}
      note={
        <div className="flex flex-col gap-1">
          <span>{t("x.tr.model")}</span>
          <span className="text-[11px] opacity-80">{t("x.tr.limits")}</span>
        </div>
      }
    >
      <FileDrop accept="audio/*,video/*" onFiles={onFiles} hint="MP3, WAV, M4A, MP4…" />
      {file && <p className="mt-3 text-xs text-slate-500 dark:text-slate-400">{file.name}</p>}

      {working && <div className="mt-4"><ProgressBar value={progress} label={statusLabel} /></div>}
      {error && (
        <p className="mt-3 rounded-xl bg-amber-50 p-3 text-sm text-amber-800 dark:bg-amber-500/10 dark:text-amber-200">{error}</p>
      )}

      <div className="mt-4 flex flex-wrap gap-2">
        <button
          onClick={() => file && void run(file)}
          disabled={!file || working || recording}
          className="flex items-center gap-2 rounded-full bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow hover:bg-indigo-700 disabled:opacity-40"
        >
          {working ? <Icon name="Loader2" size={16} className="animate-spin" /> : <Icon name="Captions" size={16} />}
          {t("common.start")}
        </button>
        <button
          onClick={() => void toggleRecording()}
          disabled={working}
          className="flex items-center gap-2 rounded-full border border-slate-300 px-5 py-2.5 text-sm font-semibold hover:bg-slate-100 disabled:opacity-40 dark:border-slate-600 dark:hover:bg-slate-800"
        >
          <Icon name={recording ? "Pause" : "AudioLines"} size={16} />
          {recording ? t("x.tr.stop") : t("x.tr.record")}
        </button>
      </div>
      {recording && <p className="mt-2 text-xs text-rose-600 dark:text-rose-400">{t("x.tr.recording")}</p>}

      {text && (
        <div className="mt-6">
          <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
              {t("x.tr.result")} — {t("x.tr.langs").replace("{langs}", langs.join(", "))}
            </p>
            <div className="flex gap-2">
              <button onClick={() => void copy()} className={btn}>
                <Icon name={copied ? "Check" : "Copy"} size={12} /> {copied ? t("common.copied") : t("common.copy")}
              </button>
              <button onClick={() => downloadBlob(new Blob([text], { type: "text/plain;charset=utf-8" }), "transcription.txt")} className={btn}>
                <Icon name="FileDown" size={12} /> TXT
              </button>
              <button
                onClick={() => downloadBlob(new Blob([buildSrt(items.map((i) => ({ start: i.start, end: i.end, text: i.text })))], { type: "text/plain;charset=utf-8" }), "transcription.srt")}
                className={btn}
              >
                <Icon name="FileDown" size={12} /> SRT
              </button>
            </div>
          </div>
          <div className="mb-2 flex flex-wrap gap-1.5">
            {items.map((i, idx) => (
              <span key={idx} className="rounded-full bg-indigo-50 px-2 py-0.5 text-[10px] font-medium text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300">
                {clock(i.start)} · {LANG_NAMES[i.lang] ?? i.lang}
              </span>
            ))}
          </div>
          <textarea value={text} onChange={(e) => setText(e.target.value)} rows={10} className="w-full rounded-xl border border-slate-200 bg-white p-3 text-sm dark:border-slate-700 dark:bg-slate-900" />
        </div>
      )}
    </ToolShell>
  );
}
