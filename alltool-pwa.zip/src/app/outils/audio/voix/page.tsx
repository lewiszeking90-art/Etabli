"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useLocale } from "@/i18n/LocaleProvider";
import { ToolShell } from "@/components/tool/ToolShell";
import { Icon } from "@/components/Icon";
import { segmentTextByLanguage, type TextSegment } from "@/lib/textSegments";

export default function TtsPage() {
  const { t } = useLocale();
  const [text, setText] = useState(
    "Bonjour ! Welcome to AllTool. Ceci est un exemple de texte qui mélange le français et l'anglais automatiquement détecté.",
  );
  const [rate, setRate] = useState(1);
  const [pitch, setPitch] = useState(1);
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [speaking, setSpeaking] = useState(false);
  const [paused, setPaused] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);
  const [unsupported, setUnsupported] = useState(false);
  const segmentsRef = useRef<TextSegment[]>([]);

  useEffect(() => {
    if (typeof window === "undefined" || !window.speechSynthesis) {
      setUnsupported(true);
      return;
    }
    function loadVoices() {
      setVoices(window.speechSynthesis.getVoices());
    }
    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;
  }, []);

  const segments = useMemo(() => segmentTextByLanguage(text), [text]);

  function pickVoice(lang: string): SpeechSynthesisVoice | undefined {
    const exact = voices.find((v) => v.lang.toLowerCase() === lang.toLowerCase());
    if (exact) return exact;
    const prefix = lang.split("-")[0];
    return voices.find((v) => v.lang.toLowerCase().startsWith(prefix));
  }

  function play() {
    if (unsupported || segments.length === 0) return;
    window.speechSynthesis.cancel();
    segmentsRef.current = segments;
    setActiveIndex(0);
    segments.forEach((segment, index) => {
      const utterance = new SpeechSynthesisUtterance(segment.text);
      utterance.lang = segment.lang;
      utterance.rate = rate;
      utterance.pitch = pitch;
      const voice = pickVoice(segment.lang);
      if (voice) utterance.voice = voice;
      utterance.onstart = () => setActiveIndex(index);
      if (index === segments.length - 1) {
        utterance.onend = () => {
          setSpeaking(false);
          setActiveIndex(-1);
        };
      }
      window.speechSynthesis.speak(utterance);
    });
    setSpeaking(true);
    setPaused(false);
  }

  function pause() {
    window.speechSynthesis.pause();
    setPaused(true);
  }

  function resume() {
    window.speechSynthesis.resume();
    setPaused(false);
  }

  function stop() {
    window.speechSynthesis.cancel();
    setSpeaking(false);
    setPaused(false);
    setActiveIndex(-1);
  }

  return (
    <ToolShell
      toolId="tts"
      icon="Volume2"
      titleKey="tool.tts.name"
      descKey="tool.tts.desc"
      badges={["local"]}
      note={
        <span>
          Le texte est analysé phrase par phrase pour détecter automatiquement la langue (français, anglais, espagnol,
          allemand, chinois, swahili…) et utiliser la bonne voix à chaque changement, même au sein d&apos;un même
          paragraphe. Les voix disponibles dépendent de votre appareil/navigateur.
        </span>
      }
    >
      {unsupported && (
        <p className="rounded-xl bg-red-50 p-3 text-sm text-red-700 dark:bg-red-500/10 dark:text-red-300">
          La synthèse vocale (Web Speech API) n&apos;est pas prise en charge par ce navigateur.
        </p>
      )}

      <label className="flex cursor-pointer items-center gap-1.5 text-xs font-medium text-indigo-600 hover:underline dark:text-indigo-300">
        <Icon name="UploadCloud" size={14} />
        Importer un fichier .txt
        <input
          type="file"
          accept=".txt,text/plain"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) file.text().then(setText);
          }}
        />
      </label>

      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        rows={6}
        className="mt-2 w-full rounded-xl border border-slate-200 bg-white p-3 text-sm dark:border-slate-700 dark:bg-slate-900"
      />

      <div className="mt-4 grid grid-cols-2 gap-4">
        <div>
          <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Vitesse ({rate.toFixed(1)}x)</label>
          <input type="range" min={0.5} max={2} step={0.1} value={rate} onChange={(e) => setRate(Number(e.target.value))} className="mt-2 w-full" />
        </div>
        <div>
          <label className="text-xs font-medium text-slate-500 dark:text-slate-400">Hauteur ({pitch.toFixed(1)})</label>
          <input type="range" min={0} max={2} step={0.1} value={pitch} onChange={(e) => setPitch(Number(e.target.value))} className="mt-2 w-full" />
        </div>
      </div>

      <div className="mt-5 flex flex-wrap gap-3">
        {!speaking && (
          <button onClick={play} disabled={unsupported || !text.trim()} className="flex items-center gap-2 rounded-full bg-indigo-600 px-5 py-2.5 text-sm font-semibold text-white shadow hover:bg-indigo-700 disabled:opacity-40">
            <Icon name="Play" size={16} />
            {t("common.start")}
          </button>
        )}
        {speaking && !paused && (
          <button onClick={pause} className="flex items-center gap-2 rounded-full border border-slate-200 px-5 py-2.5 text-sm font-semibold hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800">
            <Icon name="Pause" size={16} />
            {t("common.pause")}
          </button>
        )}
        {speaking && paused && (
          <button onClick={resume} className="flex items-center gap-2 rounded-full border border-slate-200 px-5 py-2.5 text-sm font-semibold hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800">
            <Icon name="Play" size={16} />
            {t("common.resume")}
          </button>
        )}
        {speaking && (
          <button onClick={stop} className="flex items-center gap-2 rounded-full border border-red-200 px-5 py-2.5 text-sm font-semibold text-red-600 hover:bg-red-50 dark:border-red-500/30 dark:text-red-400 dark:hover:bg-red-500/10">
            <Icon name="X" size={16} />
            {t("common.stop")}
          </button>
        )}
      </div>

      {segments.length > 0 && (
        <div className="mt-6 flex flex-col gap-2">
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Segments détectés ({segments.length})</p>
          {segments.map((segment, idx) => (
            <div
              key={idx}
              className={`rounded-xl border p-3 text-sm transition ${
                activeIndex === idx
                  ? "border-indigo-400 bg-indigo-50 dark:border-indigo-500/50 dark:bg-indigo-500/10"
                  : "border-slate-200 bg-white dark:border-slate-800 dark:bg-[#121826]"
              }`}
            >
              <span className="mb-1 inline-block rounded-full bg-slate-100 px-2 py-0.5 text-[10px] font-medium text-slate-500 dark:bg-slate-800 dark:text-slate-400">
                {segment.lang}
              </span>
              <p>{segment.text}</p>
            </div>
          ))}
        </div>
      )}
    </ToolShell>
  );
}
