"use client";

import { useLocale } from "@/i18n/LocaleProvider";

export default function PrivacyPage() {
  const { t } = useLocale();
  return (
    <div className="mx-auto max-w-3xl px-4 py-8 md:px-6">
      <h1 className="text-2xl font-bold">{t("privacy.title")}</h1>
      <div className="mt-6 flex flex-col gap-4 text-sm leading-relaxed text-slate-700 dark:text-slate-300">
        <p>{t("privacy.intro")}</p>
        <p>{t("privacy.dataCollection")}</p>
        <p>{t("privacy.externalServices")}</p>
        <p>{t("privacy.storage")}</p>
        <p className="font-medium">{t("privacy.contact")}</p>
      </div>
    </div>
  );
}
