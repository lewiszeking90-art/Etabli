"use client";

import { Suspense, useMemo } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { useLocale } from "@/i18n/LocaleProvider";
import { CATEGORIES, TOOLS, getToolById } from "@/lib/tools";
import { ToolCard } from "@/components/ToolCard";
import { Icon } from "@/components/Icon";
import { useFavoriteIds, useHistoryItems } from "@/lib/useHistory";

function HomeContent() {
  const { t } = useLocale();
  const searchParams = useSearchParams();
  const query = (searchParams?.get("q") ?? "").trim().toLowerCase();

  const favIds = useFavoriteIds();
  const favoriteIds = useMemo(() => new Set(favIds), [favIds]);
  const recents = useHistoryItems();

  const filteredTools = useMemo(() => {
    if (!query) return null;
    return TOOLS.filter((tool) => {
      const name = t(tool.nameKey).toLowerCase();
      const desc = t(tool.descKey).toLowerCase();
      return name.includes(query) || desc.includes(query) || tool.id.includes(query);
    });
  }, [query, t]);

  const uniqueRecents = useMemo(() => {
    const seen = new Set<string>();
    const result: typeof recents = [];
    for (const item of recents) {
      if (seen.has(item.toolId)) continue;
      seen.add(item.toolId);
      result.push(item);
      if (result.length >= 6) break;
    }
    return result;
  }, [recents]);

  const favoriteTools = TOOLS.filter((tool) => favoriteIds.has(tool.id));

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 md:px-6">
      <section className="animate-fade-in rounded-3xl bg-gradient-to-br from-indigo-600 via-violet-600 to-fuchsia-600 p-8 text-white shadow-lg md:p-12">
        <p className="text-xs font-semibold uppercase tracking-widest text-white/70">AllTool</p>
        <h1 className="mt-3 max-w-2xl text-2xl font-bold leading-tight md:text-4xl">{t("home.heroTitle")}</h1>
        <p className="mt-3 max-w-xl text-sm text-white/85 md:text-base">{t("home.heroSubtitle")}</p>
      </section>

      {filteredTools ? (
        <section className="mt-8">
          <h2 className="mb-3 text-lg font-semibold">{t("common.search")}</h2>
          {filteredTools.length === 0 ? (
            <p className="text-sm text-slate-500 dark:text-slate-400">{t("home.noResults")}</p>
          ) : (
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {filteredTools.map((tool) => (
                <ToolCard key={tool.id} tool={tool} favoriteIds={favoriteIds} />
              ))}
            </div>
          )}
        </section>
      ) : (
        <>
          <section className="mt-8">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-lg font-semibold">{t("home.recentsTitle")}</h2>
            </div>
            {uniqueRecents.length === 0 ? (
              <p className="rounded-2xl border border-dashed border-slate-300 p-4 text-sm text-slate-500 dark:border-slate-700 dark:text-slate-400">
                {t("home.recentsEmpty")}
              </p>
            ) : (
              <div className="flex gap-3 overflow-x-auto pb-2">
                {uniqueRecents.map((item) => {
                  const tool = getToolById(item.toolId);
                  if (!tool) return null;
                  return (
                    <Link
                      key={item.id}
                      href={tool.href}
                      className="flex min-w-[160px] items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm font-medium shadow-sm hover:-translate-y-0.5 hover:shadow-md dark:border-slate-800 dark:bg-[#121826]"
                    >
                      <Icon name={tool.icon} size={16} className="text-indigo-600 dark:text-indigo-300" />
                      {t(tool.nameKey)}
                    </Link>
                  );
                })}
              </div>
            )}
          </section>

          <section className="mt-8">
            <h2 className="mb-3 text-lg font-semibold">{t("home.favoritesTitle")}</h2>
            {favoriteTools.length === 0 ? (
              <p className="rounded-2xl border border-dashed border-slate-300 p-4 text-sm text-slate-500 dark:border-slate-700 dark:text-slate-400">
                {t("home.favoritesEmptyText")}
              </p>
            ) : (
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {favoriteTools.map((tool) => (
                  <ToolCard key={tool.id} tool={tool} favoriteIds={favoriteIds} />
                ))}
              </div>
            )}
          </section>

          <section className="mt-10">
            <h2 className="mb-3 text-lg font-semibold">{t("home.categoriesTitle")}</h2>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-6">
              {CATEGORIES.map((cat) => (
                <a
                  key={cat.id}
                  href={`#cat-${cat.id}`}
                  className="flex flex-col items-center gap-2 rounded-2xl border border-slate-200 bg-white p-4 text-center shadow-sm hover:-translate-y-0.5 hover:shadow-md dark:border-slate-800 dark:bg-[#121826]"
                >
                  <span className="grid h-10 w-10 place-items-center rounded-xl bg-violet-50 text-violet-600 dark:bg-violet-500/10 dark:text-violet-300">
                    <Icon name={cat.icon} size={20} />
                  </span>
                  <span className="text-xs font-semibold">{t(cat.titleKey)}</span>
                </a>
              ))}
            </div>
          </section>

          {CATEGORIES.map((cat) => (
            <section key={cat.id} id={`cat-${cat.id}`} className="mt-10 scroll-mt-20">
              <div className="mb-3">
                <h2 className="text-lg font-semibold">{t(cat.titleKey)}</h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">{t(cat.descKey)}</p>
              </div>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {TOOLS.filter((tool) => tool.category === cat.id).map((tool) => (
                  <ToolCard key={tool.id} tool={tool} favoriteIds={favoriteIds} />
                ))}
              </div>
            </section>
          ))}
        </>
      )}
    </div>
  );
}

export default function HomePage() {
  return (
    <Suspense fallback={null}>
      <HomeContent />
    </Suspense>
  );
}
