"use client";

import { useEffect, useState } from "react";
import { clearHistory, useHistoryItems } from "@/lib/useHistory";
import Link from "next/link";
import { useLocale } from "@/i18n/LocaleProvider";
import { getToolById } from "@/lib/tools";
import { Icon } from "@/components/Icon";

export default function HistoryPage() {
  const { t, locale } = useLocale();
  const items = useHistoryItems();
  const [loaded, setLoaded] = useState(false);

  useEffect(() => setLoaded(true), []);

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 md:px-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">{t("history.title")}</h1>
        {items.length > 0 && (
          <button
            onClick={() => clearHistory()}
            className="flex items-center gap-1.5 rounded-full border border-red-200 px-3 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50 dark:border-red-500/30 dark:text-red-400 dark:hover:bg-red-500/10"
          >
            <Icon name="Trash2" size={14} />
            {t("history.clear")}
          </button>
        )}
      </div>

      {loaded && items.length === 0 && (
        <p className="mt-6 rounded-2xl border border-dashed border-slate-300 p-6 text-sm text-slate-500 dark:border-slate-700 dark:text-slate-400">
          {t("history.empty")}
        </p>
      )}

      <div className="mt-6 flex flex-col gap-2">
        {items.map((item) => {
          const tool = getToolById(item.toolId);
          return (
            <Link
              key={item.id}
              href={tool?.href ?? "/"}
              className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm shadow-sm hover:bg-slate-50 dark:border-slate-800 dark:bg-[#121826] dark:hover:bg-slate-800/60"
            >
              <span className="flex items-center gap-2">
                {tool && <Icon name={tool.icon} size={16} className="text-indigo-600 dark:text-indigo-300" />}
                {item.label}
              </span>
              <span className="text-xs text-slate-400">
                {new Date(item.createdAt).toLocaleString(locale)}
              </span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
