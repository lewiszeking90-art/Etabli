"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { DEFAULT_LOCALE, DICTIONARIES, LOCALES, isLocaleCode, type LocaleCode } from "./locales";
import type { TranslationKey } from "./dictionary";
import { EXTRA, type ExtraKey } from "./extra";

interface LocaleContextValue {
  locale: LocaleCode;
  setLocale: (locale: LocaleCode) => void;
  t: (key: TranslationKey | ExtraKey) => string;
  dir: "ltr" | "rtl";
}

const LocaleContext = createContext<LocaleContextValue | null>(null);

const STORAGE_KEY = "alltool.locale";

export function LocaleProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<LocaleCode>(DEFAULT_LOCALE);

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (stored && isLocaleCode(stored)) {
        setLocaleState(stored);
        return;
      }
      const browserLang = window.navigator.language.slice(0, 2);
      if (isLocaleCode(browserLang)) {
        setLocaleState(browserLang);
      }
    } catch {
      // ignore (SSR / privacy mode)
    }
  }, []);

  const setLocale = useCallback((next: LocaleCode) => {
    setLocaleState(next);
    try {
      window.localStorage.setItem(STORAGE_KEY, next);
    } catch {
      // ignore
    }
  }, []);

  const meta = LOCALES.find((l) => l.code === locale) ?? LOCALES[0];

  useEffect(() => {
    document.documentElement.lang = locale;
    document.documentElement.dir = meta.dir;
  }, [locale, meta.dir]);

  const t = useCallback(
    (key: TranslationKey | ExtraKey) => {
      if (key.startsWith("x.")) {
        const k = key as ExtraKey;
        return EXTRA[locale]?.[k] ?? EXTRA[DEFAULT_LOCALE][k] ?? key;
      }
      const k = key as TranslationKey;
      return DICTIONARIES[locale]?.[k] ?? DICTIONARIES[DEFAULT_LOCALE][k] ?? key;
    },
    [locale],
  );

  const value = useMemo(
    () => ({ locale, setLocale, t, dir: meta.dir }),
    [locale, setLocale, t, meta.dir],
  );

  return <LocaleContext.Provider value={value}>{children}</LocaleContext.Provider>;
}

export function useLocale() {
  const ctx = useContext(LocaleContext);
  if (!ctx) throw new Error("useLocale must be used within LocaleProvider");
  return ctx;
}
