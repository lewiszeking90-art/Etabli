import fr from "../dictionary";
import en from "./en";
import es from "./es";
import de from "./de";
import pt from "./pt";
import it from "./it";
import ar from "./ar";
import zh from "./zh";
import sw from "./sw";
import ln from "./ln";
import type { Dictionary } from "../dictionary";

export type LocaleCode = "fr" | "en" | "es" | "de" | "pt" | "it" | "ar" | "zh" | "sw" | "ln";

export interface LocaleMeta {
  code: LocaleCode;
  nativeName: string;
  dir: "ltr" | "rtl";
}

export const LOCALES: LocaleMeta[] = [
  { code: "fr", nativeName: "Français", dir: "ltr" },
  { code: "en", nativeName: "English", dir: "ltr" },
  { code: "es", nativeName: "Español", dir: "ltr" },
  { code: "de", nativeName: "Deutsch", dir: "ltr" },
  { code: "pt", nativeName: "Português", dir: "ltr" },
  { code: "it", nativeName: "Italiano", dir: "ltr" },
  { code: "ar", nativeName: "العربية", dir: "rtl" },
  { code: "zh", nativeName: "中文", dir: "ltr" },
  { code: "sw", nativeName: "Kiswahili", dir: "ltr" },
  { code: "ln", nativeName: "Lingála", dir: "ltr" },
];

export const DICTIONARIES: Record<LocaleCode, Dictionary> = {
  fr,
  en,
  es,
  de,
  pt,
  it,
  ar,
  zh,
  sw,
  ln,
};

export const DEFAULT_LOCALE: LocaleCode = "fr";

export function isLocaleCode(value: string): value is LocaleCode {
  return Object.prototype.hasOwnProperty.call(DICTIONARIES, value);
}
