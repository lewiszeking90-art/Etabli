/* AllTool — service worker : l'application fonctionne ensuite sans connexion.
   - "coque" (pages, scripts, styles) : mise en cache à l'installation ;
   - "pack" (moteurs vidéo/OCR/IA, modèles) : téléchargé une seule fois par l'application. */
const PACK_CACHE = "alltool-pack-v1";
const SHELL_PREFIX = "alltool-shell-";
const scope = new URL(self.registration.scope);
const BASE = scope.pathname.replace(/\/$/, "");

self.addEventListener("install", (event) => {
  event.waitUntil((async () => {
    try {
      const res = await fetch(BASE + "/precache.json", { cache: "no-store" });
      const manifest = await res.json();
      const cache = await caches.open(SHELL_PREFIX + manifest.version);
      const urls = manifest.shell.map((f) => BASE + "/" + f.path);
      // Les fichiers sont ajoutés un par un : un échec isolé n'empêche pas l'installation.
      await Promise.all(urls.map((u) => cache.add(new Request(u, { cache: "reload" })).catch(() => null)));
      self.__shellName = SHELL_PREFIX + manifest.version;
    } catch (e) { /* hors ligne ou premier lancement sans precache.json : on continue */ }
    await self.skipWaiting();
  })());
});

self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    let newest = null;
    for (const k of keys) if (k.startsWith(SHELL_PREFIX)) newest = newest && newest > k ? newest : k;
    await Promise.all(keys.filter((k) => k.startsWith(SHELL_PREFIX) && k !== newest).map((k) => caches.delete(k)));
    await self.clients.claim();
  })());
});

async function matchAny(request) {
  const keys = await caches.keys();
  for (const k of keys) {
    if (k !== PACK_CACHE && !k.startsWith(SHELL_PREFIX)) continue;
    const cache = await caches.open(k);
    const hit = (await cache.match(request, { ignoreSearch: true })) || null;
    if (hit) return hit;
  }
  return null;
}

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;
  const path = url.pathname;
  const isPack = path.startsWith(BASE + "/vendor/") || path.startsWith(BASE + "/models/");

  if (isPack) { // cache d'abord (gros fichiers), réseau en secours puis mémorisation
    event.respondWith((async () => {
      const hit = await matchAny(req);
      if (hit) return hit;
      const res = await fetch(req);
      if (res.ok && res.status === 200) { const c = await caches.open(PACK_CACHE); c.put(req, res.clone()).catch(() => null); }
      return res;
    })());
    return;
  }

  event.respondWith((async () => {
    const hit = await matchAny(req);
    if (hit) {
      // mise à jour discrète en arrière-plan quand on est en ligne
      event.waitUntil(fetch(req).then(async (res) => {
        if (res.ok) { const keys = (await caches.keys()).filter((k) => k.startsWith(SHELL_PREFIX)).sort(); if (keys.length) (await caches.open(keys[keys.length - 1])).put(req, res); }
      }).catch(() => null));
      return hit;
    }
    try { return await fetch(req); }
    catch (e) {
      if (req.mode === "navigate") { const home = await matchAny(new Request(BASE + "/")); if (home) return home; }
      throw e;
    }
  })());
});
