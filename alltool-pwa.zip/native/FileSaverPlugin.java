package com.lewistech.alltool;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Enregistre les fichiers produits par les outils dans Téléchargements/AllTool. */
@CapacitorPlugin(name = "FileSaver")
public class FileSaverPlugin extends Plugin {

    private static class Sink {
        OutputStream out;
        Uri uri;
        File file;
        String name;
        String mime;
    }

    private final Map<String, Sink> sinks = new HashMap<>();

    private boolean french() {
        return "fr".equals(Locale.getDefault().getLanguage());
    }

    private String clean(String name) {
        String n = name == null ? "fichier" : name.replaceAll("[\\\\/:*?\"<>|]", "_").trim();
        return n.isEmpty() ? "fichier" : n;
    }

    @PluginMethod
    public void begin(PluginCall call) {
        String name = clean(call.getString("name", "fichier"));
        String mime = call.getString("mime", "application/octet-stream");
        try {
            Context ctx = getContext();
            Sink s = new Sink();
            s.name = name;
            s.mime = mime;
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AllTool");
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                s.uri = ctx.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (s.uri == null) throw new IOException("MediaStore indisponible");
                s.out = ctx.getContentResolver().openOutputStream(s.uri);
            } else {
                File dir = new File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "AllTool");
                dir.mkdirs();
                s.file = new File(dir, name);
                s.out = new FileOutputStream(s.file);
            }
            if (s.out == null) throw new IOException("Flux de sortie indisponible");
            String id = UUID.randomUUID().toString();
            sinks.put(id, s);
            JSObject r = new JSObject();
            r.put("id", id);
            call.resolve(r);
        } catch (Exception e) {
            call.reject("begin : " + e.getMessage());
        }
    }

    @PluginMethod
    public void append(PluginCall call) {
        Sink s = sinks.get(call.getString("id", ""));
        String data = call.getString("data", "");
        if (s == null) { call.reject("fichier inconnu"); return; }
        try {
            byte[] bytes = Base64.decode(data, Base64.DEFAULT);
            s.out.write(bytes);
            call.resolve();
        } catch (Exception e) {
            call.reject("append : " + e.getMessage());
        }
    }

    @PluginMethod
    public void finish(PluginCall call) {
        String id = call.getString("id", "");
        Sink s = sinks.remove(id);
        if (s == null) { call.reject("fichier inconnu"); return; }
        try {
            s.out.flush();
            s.out.close();
            if (s.uri != null) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContext().getContentResolver().update(s.uri, v, null, null);
            }
            String where = (french() ? "Téléchargements/AllTool/" : "Downloads/AllTool/") + s.name;
            if (s.uri == null && s.file != null) where = s.file.getAbsolutePath();
            notifyDone(s, where);
            JSObject r = new JSObject();
            r.put("where", where);
            call.resolve(r);
        } catch (Exception e) {
            call.reject("finish : " + e.getMessage());
        }
    }

    @PluginMethod
    public void abort(PluginCall call) {
        Sink s = sinks.remove(call.getString("id", ""));
        if (s != null) {
            try { s.out.close(); } catch (Exception ignored) { }
            try {
                if (s.uri != null) getContext().getContentResolver().delete(s.uri, null, null);
                if (s.file != null) s.file.delete();
            } catch (Exception ignored) { }
        }
        call.resolve();
    }

    private void notifyDone(Sink s, String where) {
        try {
            Context ctx = getContext();
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(new NotificationChannel("alltool_done", "AllTool", NotificationManager.IMPORTANCE_DEFAULT));
            }
            Notification.Builder b = Build.VERSION.SDK_INT >= 26
                    ? new Notification.Builder(ctx, "alltool_done")
                    : new Notification.Builder(ctx);
            b.setSmallIcon(android.R.drawable.stat_sys_download_done)
                    .setContentTitle(french() ? "Terminé" : "Done")
                    .setContentText(s.name + " — " + where)
                    .setAutoCancel(true);
            if (s.uri != null) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setDataAndType(s.uri, s.mime);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                b.setContentIntent(PendingIntent.getActivity(ctx, 0, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
            }
            nm.notify((int) (System.currentTimeMillis() % Integer.MAX_VALUE), b.build());
        } catch (Exception ignored) {
            // notification refusée : la fenêtre « Terminé » dans l'application suffit
        }
    }
}
