package com.lewistech.alltool;

import android.app.DownloadManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;

import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.Locale;

/**
 * Navigateur plein écran (WebView) qui repère la vidéo de la page
 * et affiche un bouton « Télécharger la vidéo ».
 */
@CapacitorPlugin(name = "VideoBrowser")
public class VideoBrowserPlugin extends Plugin {

    private FrameLayout root;
    private WebView webView;
    private TextView titleView;
    private Button downloadButton;
    private OnBackPressedCallback backCallback;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private String candidate = null;
    private boolean polling = false;

    private final Runnable pollTask = new Runnable() {
        @Override
        public void run() {
            if (webView == null || !polling) return;
            String js = "(function(){var v=document.querySelector('video');if(!v)return '';"
                    + "var s=v.currentSrc||v.src||'';"
                    + "if(!s){var o=v.querySelector('source');if(o)s=o.src||'';}"
                    + "return s;})()";
            webView.evaluateJavascript(js, new ValueCallback<String>() {
                @Override
                public void onReceiveValue(String value) {
                    if (value == null || value.length() < 3) return;
                    String s = value.substring(1, value.length() - 1)
                            .replace("\\u0026", "&")
                            .replace("\\/", "/");
                    if (s.startsWith("http")) setCandidate(s);
                }
            });
            handler.postDelayed(this, 1500);
        }
    };

    private boolean french() {
        return "fr".equals(Locale.getDefault().getLanguage());
    }

    private int dp(int v) {
        float d = getActivity().getResources().getDisplayMetrics().density;
        return (int) (v * d + 0.5f);
    }

    @PluginMethod
    public void open(final PluginCall call) {
        final String url = call.getString("url");
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
            call.reject("Adresse invalide");
            return;
        }
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    closeInternal();
                    show(url);
                    call.resolve();
                } catch (Exception e) {
                    call.reject("Impossible d'ouvrir le navigateur : " + e.getMessage());
                }
            }
        });
    }

    private void show(String url) {
        Context ctx = getActivity();

        root = new FrameLayout(ctx);
        root.setBackgroundColor(Color.WHITE);
        root.setFitsSystemWindows(true);
        root.setClickable(true);

        LinearLayout column = new LinearLayout(ctx);
        column.setOrientation(LinearLayout.VERTICAL);

        // Barre du haut : fermer, retour, titre
        LinearLayout bar = new LinearLayout(ctx);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.parseColor("#111827"));
        bar.setPadding(dp(4), dp(2), dp(8), dp(2));

        Button close = new Button(ctx);
        close.setText("✕");
        close.setTextColor(Color.WHITE);
        close.setBackgroundColor(Color.TRANSPARENT);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { closeInternal(); }
        });
        bar.addView(close, new LinearLayout.LayoutParams(dp(56), dp(48)));

        Button back = new Button(ctx);
        back.setText("←");
        back.setTextColor(Color.WHITE);
        back.setBackgroundColor(Color.TRANSPARENT);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { if (webView != null && webView.canGoBack()) webView.goBack(); }
        });
        bar.addView(back, new LinearLayout.LayoutParams(dp(56), dp(48)));

        titleView = new TextView(ctx);
        titleView.setTextColor(Color.WHITE);
        titleView.setSingleLine(true);
        titleView.setText(Uri.parse(url).getHost());
        bar.addView(titleView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        column.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        webView = new WebView(ctx);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportMultipleWindows(false);
        // Retire « wv » pour que les sites se comportent comme dans un vrai navigateur mobile
        s.setUserAgentString(s.getUserAgentString().replace("; wv", ""));
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                // Les liens vers d'autres applications (tiktok://, intent://…) sont ignorés
                return !("http".equals(scheme) || "https".equals(scheme));
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                consider(request.getUrl().toString());
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onPageStarted(WebView view, String u, android.graphics.Bitmap favicon) {
                candidate = null;
                if (downloadButton != null) downloadButton.setVisibility(View.GONE);
            }

            @Override
            public void onPageFinished(WebView view, String u) {
                if (titleView != null) {
                    String t = view.getTitle();
                    titleView.setText(t != null && t.length() > 0 ? t : Uri.parse(u).getHost());
                }
            }
        });

        column.addView(webView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(column, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Bouton flottant « Télécharger la vidéo » (caché tant qu'aucune vidéo n'est trouvée)
        downloadButton = new Button(ctx);
        downloadButton.setText(french() ? "⬇  Télécharger la vidéo" : "⬇  Download video");
        downloadButton.setTextColor(Color.WHITE);
        downloadButton.setAllCaps(false);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.parseColor("#4F46E5"));
        bg.setCornerRadius(dp(28));
        downloadButton.setBackground(bg);
        downloadButton.setPadding(dp(24), dp(12), dp(24), dp(12));
        downloadButton.setVisibility(View.GONE);
        downloadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { download(); }
        });
        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(52));
        fp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        fp.bottomMargin = dp(28);
        root.addView(downloadButton, fp);

        getActivity().addContentView(root, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Bouton « retour » du téléphone : page précédente, puis fermeture
        backCallback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView != null && webView.canGoBack()) webView.goBack();
                else closeInternal();
            }
        };
        getActivity().getOnBackPressedDispatcher().addCallback(getActivity(), backCallback);

        polling = true;
        handler.postDelayed(pollTask, 1500);
        webView.loadUrl(url);
    }

    /** Repère les adresses qui ressemblent à un fichier vidéo. */
    private void consider(String url) {
        if (url == null) return;
        String lower = url.toLowerCase(Locale.ROOT);
        String path = lower;
        int q = path.indexOf('?');
        if (q >= 0) path = path.substring(0, q);
        boolean isVideo = path.endsWith(".mp4") || path.endsWith(".webm") || path.endsWith(".mov") || path.endsWith(".m4v")
                || lower.contains("mime_type=video") || lower.contains("video_mp4");
        if (isVideo && !path.endsWith(".m3u8") && !path.endsWith(".ts")) setCandidate(url);
    }

    private void setCandidate(final String url) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (root == null) return;
                candidate = url;
                if (downloadButton != null) downloadButton.setVisibility(View.VISIBLE);
            }
        });
    }

    private void download() {
        if (candidate == null || webView == null) return;
        String url = candidate;
        try {
            Uri uri = Uri.parse(url);
            String path = uri.getPath() == null ? "" : uri.getPath().toLowerCase(Locale.ROOT);
            String ext = path.endsWith(".webm") ? ".webm" : (path.endsWith(".mov") ? ".mov" : ".mp4");
            String mime = ".webm".equals(ext) ? "video/webm" : (".mov".equals(ext) ? "video/quicktime" : "video/mp4");
            String name = "AllTool_" + System.currentTimeMillis() + ext;

            DownloadManager.Request req = new DownloadManager.Request(uri);
            req.addRequestHeader("User-Agent", webView.getSettings().getUserAgentString());
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) req.addRequestHeader("Cookie", cookie);
            String referer = webView.getUrl();
            if (referer != null) req.addRequestHeader("Referer", referer);
            req.setTitle(name);
            req.setMimeType(mime);
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "AllTool/" + name);

            DownloadManager dm = (DownloadManager) getActivity().getSystemService(Context.DOWNLOAD_SERVICE);
            dm.enqueue(req);
            Toast.makeText(getActivity(),
                    french() ? "Téléchargement lancé (dossier Téléchargements/AllTool)" : "Download started (Downloads/AllTool)",
                    Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(getActivity(),
                    (french() ? "Échec du téléchargement : " : "Download failed: ") + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void closeInternal() {
        polling = false;
        handler.removeCallbacks(pollTask);
        if (backCallback != null) { backCallback.remove(); backCallback = null; }
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        if (root != null) {
            ViewGroup parent = (ViewGroup) root.getParent();
            if (parent != null) parent.removeView(root);
            root = null;
        }
        downloadButton = null;
        titleView = null;
        candidate = null;
    }

    @Override
    protected void handleOnDestroy() {
        closeInternal();
        super.handleOnDestroy();
    }
}
