# AllTool — PWA hors ligne

Boîte à outils tout-en-un (navigateur, téléchargeur de vidéos, vidéo, audio, images, PDF, OCR, transcription, traduction).
**Site 100 % statique** : pas de base de données, pas de serveur, pas de clé API, pas de compte.

## Ce qui a changé par rapport à la version d'Arena
- Logo : le nouveau logo (4 tuiles) remplace le « A » partout (en-tête, menu, favicon, manifeste, icônes PWA).
- PWA réelle : `manifest.webmanifest`, icônes 192/512/maskable/apple-touch, service worker, bouton « Installer », fonctionnement hors ligne.
- Pages manquantes créées : `/browser` (navigateur) et `/outils/video/telecharger` (téléchargeur).
- Plus de base de données ni de routes API : favoris et historique sont stockés sur l'appareil.
- Transcription : Whisper (modèle open source multilingue) tourne dans l'application, sans clé API. Audio découpé aux silences, langue de chaque segment affichée, export TXT/SRT.
- Traduction sans clé : traducteur du navigateur si disponible, sinon service gratuit MyMemory.
- Amélioration d'image : traitement local (canvas), sans serveur.
- Lecture vocale : détection de langue par passage (un groupe de mots anglais dans une phrase française devient son propre passage).
- Outils intégrés : `scripts/prepare-vendor.mjs` rassemble ffmpeg, OCR (moteur + 11 langues), lecteur PDF, moteur d'IA et modèle Whisper dans le site ; le service worker les garde pour un usage sans connexion.

## Publier (GitHub Pages)
1. Mettre ce projet (ou `alltool-pwa.zip`) dans un dépôt GitHub, avec `.github/workflows/deploy.yml`.
2. Réglages du dépôt → Pages → Source : « GitHub Actions ».
3. Chaque envoi sur `main` construit et publie le site (adresse : `https://<compte>.github.io/<dépôt>/`).

## Ce qui n'a pas pu être testé ici
Le projet n'a pas pu être compilé (pas d'accès à npm dans l'environnement de travail). Vérifié : syntaxe et types (avec bibliothèques simulées), imports, textes de traduction, et les modules de logique (détection de langue, découpage de l'audio, amélioration d'image, recherche de vidéo). **Non testés en conditions réelles** : le build Next.js, le téléchargement des moteurs/modèles, Whisper, ffmpeg, l'OCR, le service worker.

## Limites connues
- Facebook : impossible sans serveur ; l'application l'explique.
- TikTok : passe par le service tikwm.com ; peut cesser de fonctionner.
- Whisper « base » : bon en français/anglais/espagnol/allemand/chinois ; un changement de langue au milieu d'une phrase très courte peut passer inaperçu.
- Écriture manuscrite : reconnue par l'OCR (Tesseract) ; précision variable.
- Les lingala/swahili des nouveaux écrans ont été rédigés sans relecture par un locuteur natif.
