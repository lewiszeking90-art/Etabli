#!/usr/bin/env bash
# Fabrique l'APK à partir du site déjà construit (dossier out/).
set -euo pipefail

test -d out || { echo "Dossier out/ introuvable : lancez d'abord « npm run build »."; exit 1; }

rm -rf android
npx cap add android

APP=android/app/src/main
PKG_DIR="$APP/java/com/lewistech/alltool"
mkdir -p "$PKG_DIR"
cp native/MainActivity.java native/VideoBrowserPlugin.java "$PKG_DIR/"

# Icône de l'application = logo AllTool
rm -rf "$APP/res/mipmap-anydpi-v26"
for d in "$APP"/res/mipmap-*; do
  cp public/icons/icon-512.png "$d/ic_launcher.png"
  cp public/icons/icon-512.png "$d/ic_launcher_round.png"
done

# Android ignore par défaut les dossiers qui commencent par « _ » : or le site a un dossier « _next ».
cat >> android/app/build.gradle <<'GRADLE'

android {
    androidResources {
        ignoreAssetsPattern '!.svn:!.git:!.ds_store:!*.scc:.*:!CVS:!thumbs.db:!picasa.ini:!*~'
    }
}
GRADLE

# Beaucoup de gros fichiers (moteurs, modèles) : plus de mémoire pour Gradle
echo "org.gradle.jvmargs=-Xmx3g -Dfile.encoding=UTF-8" >> android/gradle.properties

npx cap sync android

# Contrôle : le dossier _next doit bien être dans l'APK
test -d android/app/src/main/assets/public/_next || { echo "ERREUR : _next absent des fichiers Android"; exit 1; }

cd android
chmod +x gradlew
./gradlew assembleDebug --no-daemon
ls -la app/build/outputs/apk/debug/
