// Avant `next build` : rassemble DANS l'application tous les moteurs et modèles,
// pour qu'aucun outil ne télécharge quoi que ce soit au moment de l'utiliser.
// Chaque étape est indépendante : si l'une échoue, un avertissement s'affiche et le build continue
// (l'application retombe alors sur un téléchargement à l'usage pour cette seule pièce).
import { copyFileSync, existsSync, mkdirSync, readdirSync, statSync, writeFileSync } from "node:fs";
import { join, dirname, resolve } from "node:path";

const PUBLIC = "public";
const results = [];
const note = (ok, label, detail = "") => { results.push({ ok, label }); console.log(`${ok ? "✔" : "⚠"} ${label}${detail ? " — " + detail : ""}`); };

function findPkg(name) {
  let dir = resolve(".");
  for (let i = 0; i < 6; i++) {
    const p = join(dir, "node_modules", name);
    if (existsSync(p)) return p;
    dir = dirname(dir);
  }
  const nested = join(resolve("."), "node_modules", "@huggingface", "transformers", "node_modules", name);
  return existsSync(nested) ? nested : null;
}
const ensure = (d) => mkdirSync(d, { recursive: true });
function copy(from, to) { ensure(dirname(to)); copyFileSync(from, to); return statSync(to).size; }
const mb = (n) => (n / 1048576).toFixed(1) + " Mo";
async function download(url, dest, { retries = 3 } = {}) {
  for (let i = 1; i <= retries; i++) {
    try {
      const res = await fetch(url, { redirect: "follow" });
      if (!res.ok) throw new Error("HTTP " + res.status);
      const buf = Buffer.from(await res.arrayBuffer());
      ensure(dirname(dest)); writeFileSync(dest, buf); return buf.length;
    } catch (e) { if (i === retries) throw e; await new Promise((r) => setTimeout(r, 1500 * i)); }
  }
}

// 1) Moteur vidéo/audio (ffmpeg)
try {
  const core = findPkg("@ffmpeg/core");
  if (!core) throw new Error("@ffmpeg/core absent");
  const esm = join(core, "dist", "esm");
  const s = copy(join(esm, "ffmpeg-core.js"), join(PUBLIC, "vendor/ffmpeg/ffmpeg-core.js")) + copy(join(esm, "ffmpeg-core.wasm"), join(PUBLIC, "vendor/ffmpeg/ffmpeg-core.wasm"));
  note(true, "Moteur vidéo (ffmpeg)", mb(s));
} catch (e) { note(false, "Moteur vidéo (ffmpeg)", e.message); }

// 2) Lecteur PDF
try {
  const pdf = findPkg("pdfjs-dist");
  if (!pdf) throw new Error("pdfjs-dist absent");
  const s = copy(join(pdf, "build", "pdf.worker.min.mjs"), join(PUBLIC, "vendor/pdf/pdf.worker.min.mjs"));
  note(true, "Lecteur PDF", mb(s));
} catch (e) { note(false, "Lecteur PDF", e.message); }

// 3) OCR : worker + noyaux (npm) + données de langue (téléchargées une fois pour toutes, au build)
try {
  const tess = findPkg("tesseract.js"), tcore = findPkg("tesseract.js-core");
  if (!tess || !tcore) throw new Error("tesseract.js / tesseract.js-core absents");
  let total = copy(join(tess, "dist", "worker.min.js"), join(PUBLIC, "vendor/tesseract/worker.min.js"));
  for (const f of readdirSync(tcore)) if (/^tesseract-core.*\.(js|wasm)$/.test(f)) total += copy(join(tcore, f), join(PUBLIC, "vendor/tesseract", f));
  note(true, "OCR (moteur)", mb(total));
} catch (e) { note(false, "OCR (moteur)", e.message); }
const OCR_LANGS = ["fra", "eng", "spa", "deu", "por", "ita", "ara", "chi_sim", "swa", "nld", "rus"];
let ocrTotal = 0, ocrOk = 0;
for (const l of OCR_LANGS) {
  try { ocrTotal += await download(`https://cdn.jsdelivr.net/npm/@tesseract.js-data/${l}/4.0.0_best_int/${l}.traineddata.gz`, join(PUBLIC, `vendor/tesseract/lang/${l}.traineddata.gz`)); ocrOk++; }
  catch (e) { console.log(`  ⚠ langue OCR ${l} : ${e.message}`); }
}
note(ocrOk === OCR_LANGS.length, `OCR (langues : ${ocrOk}/${OCR_LANGS.length})`, mb(ocrTotal));

// 4) IA dans le navigateur : bibliothèque + moteur ONNX
try {
  const tf = findPkg("@huggingface/transformers");
  if (!tf) throw new Error("@huggingface/transformers absent");
  const dist = join(tf, "dist");
  const candidates = ["transformers.min.js", "transformers.web.min.js"].filter((f) => existsSync(join(dist, f)));
  if (!candidates.length) throw new Error("bundle navigateur introuvable");
  let total = copy(join(dist, candidates[0]), join(PUBLIC, "vendor/transformers/transformers.min.js"));
  const ort = findPkg("onnxruntime-web");
  if (!ort) throw new Error("onnxruntime-web absent");
  for (const f of readdirSync(join(ort, "dist"))) if (/^ort-wasm.*\.(wasm|mjs)$/.test(f)) total += copy(join(ort, "dist", f), join(PUBLIC, "vendor/ort", f));
  note(true, "IA dans le navigateur (moteur)", mb(total));
} catch (e) { note(false, "IA dans le navigateur (moteur)", e.message); }

// 5) Modèle de transcription (Whisper « base », multilingue) — téléchargé au build depuis Hugging Face
const MODELS = ["onnx-community/whisper-base"];
for (const model of MODELS) {
  try {
    const meta = await (await fetch(`https://huggingface.co/api/models/${model}`)).json();
    const wanted = (meta.siblings ?? []).map((s) => s.rfilename).filter((f) =>
      /^(config|generation_config|preprocessor_config|tokenizer_config|special_tokens_map|added_tokens|normalizer|vocab|merges)\.(json|txt)$/.test(f) || f === "tokenizer.json" ||
      /^onnx\/(encoder_model_quantized|decoder_model_merged_quantized)\.onnx$/.test(f));
    if (!wanted.some((f) => f.includes("encoder_model_quantized")) || !wanted.some((f) => f.includes("decoder_model_merged_quantized"))) throw new Error("fichiers du modèle introuvables");
    let total = 0;
    for (const f of wanted) total += await download(`https://huggingface.co/${model}/resolve/main/${f}`, join(PUBLIC, "models", model, f));
    note(true, `Modèle de transcription (${model})`, mb(total));
  } catch (e) { note(false, `Modèle de transcription (${model})`, e.message); }
}

const bad = results.filter((r) => !r.ok).length;
console.log(bad ? `\n${bad} élément(s) manquant(s) : l'application les téléchargera à l'usage si nécessaire.` : "\nTous les outils sont intégrés à l'application.");
