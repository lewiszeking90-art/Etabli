// Après `next build` : liste les fichiers de out/ pour le service worker.
// "shell" = l'application elle-même ; "pack" = moteurs et modèles (gros fichiers, vendor/ et models/).
import { readdirSync, statSync, writeFileSync, existsSync } from "node:fs";
import { join, relative, sep } from "node:path";
import { createHash } from "node:crypto";

const OUT = "out";
if (!existsSync(OUT)) { console.error("[precache] dossier out/ introuvable"); process.exit(0); }

function walk(dir) {
  return readdirSync(dir).flatMap((name) => {
    const full = join(dir, name);
    return statSync(full).isDirectory() ? walk(full) : [full];
  });
}

const shell = [], pack = [];
for (const full of walk(OUT)) {
  const path = relative(OUT, full).split(sep).join("/");
  if (path === "sw.js" || path === "precache.json" || path.endsWith(".map") || path === ".nojekyll") continue;
  const size = statSync(full).size;
  if (path.startsWith("vendor/") || path.startsWith("models/")) {
    const group = path.startsWith("models/") ? "ia" : path.split("/")[1];
    pack.push({ path, size, group });
  } else {
    shell.push({ path, size });
    if (path.endsWith("/index.html")) shell.push({ path: path.slice(0, -"index.html".length), size });
  }
}
shell.push({ path: "", size: 0 });
const version = createHash("sha1").update(JSON.stringify([shell, pack])).digest("hex").slice(0, 10);
writeFileSync(join(OUT, "precache.json"), JSON.stringify({ version, shell, pack }));
const mb = (n) => (n / 1048576).toFixed(1);
console.log(`[precache] application : ${shell.length} fichiers (${mb(shell.reduce((s, f) => s + f.size, 0))} Mo) · outils intégrés : ${pack.length} fichiers (${mb(pack.reduce((s, f) => s + f.size, 0))} Mo)`);
